//
//  NHRequestManager+HOT.h
//  DQRead
//
//  Created by rimi on 2016/12/5.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "NHRequestManager.h"

@interface NHRequestManager (HOT)


/*!
 * @brief 获取热门列表
 * @param success 返回成功的信息
 * @param failure 热门的失败的信息
 */
+ (void)getHotListWithSuccess:(void (^)(id responseObject))success
                      failure:(void (^)(NSError *error))failure;

/*!
 * @brief 获取热门详情
 * @param categoryId 热门的id
 * @param success 返回成功的信息
 * @param failure 热门的失败的信息
 */
+ (void)getHotDetailInfoWithCategoryId:(NSString *)categoryId
                               success:(void (^)(id responseObject))success
                               failure:(void (^)(NSError *error))failure;
@end
