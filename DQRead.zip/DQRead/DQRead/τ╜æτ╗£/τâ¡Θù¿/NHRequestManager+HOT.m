//
//  NHRequestManager+HOT.m
//  DQRead
//
//  Created by rimi on 2016/12/5.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "NHRequestManager+HOT.h"

@implementation NHRequestManager (HOT)

/*!
 * @brief 热门信息的参数
 * @return 返回参数,后续可以在做修改
 */
+ (NSMutableDictionary *)HotParam{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"tag"] = @"joke";
    params[@"iid"] = @"5316804410";
    params[@"os_version"] = @"9.3.4";
    params[@"os_api"] = @"18";
    
    params[@"app_name"] = @"joke_essay";
    params[@"channel"] = @"App Store";
    params[@"device_platform"] = @"iphone";
    params[@"idfa"] = @"832E262C-31D7-488A-8856-69600FAABE36";
    params[@"live_sdk_version"] = @"120";
    
    params[@"vid"] = @"4A4CBB9E-ADC3-426B-B562-9FC8173FDA52";
    params[@"openudid"] = @"cbb1d9e8770b26c39fac806b79bf263a50da6666";
    params[@"device_type"] = @"iPhone 6 Plus";
    params[@"version_code"] = @"5.5.0";
    params[@"ac"] = @"WIFI";
    params[@"screen_width"] = @"1242";
    params[@"device_id"] = @"10752255605";
    params[@"aid"] = @"7";
    params[@"count"] = @"50";
    params[@"max_time"] = [NSString stringWithFormat:@"%.2f", [[NSDate date] timeIntervalSince1970]];
    
    return params;
}

/*!
 * @brief 获取热门列表
 * @param success 返回成功的信息
 * @param failure 热门的失败的信息
 */
+ (void)getHotListWithSuccess:(void (^)(id responseObject))success
                      failure:(void (^)(NSError *error))failure
{
     NSMutableDictionary *params = [self HotParam];
     //发现列表
    [NHRequestManager GET:@"http://lf.snssdk.com/2/essay/discovery/v3/" parameters:params responseSeializerType:NHResponseSeializerTypeJSON success:^(id responseObject) {
       static NSString *const hotList = @"hotList";
        
        [self archiveRootObjectWithFileName:hotList tofile:responseObject];
        id object = [self unarchiveObjectWithFileName:hotList];

        success(object);
        
    } failure:^(NSError *error) {
        failure(error);
    }];
}

/*!
 * @brief 获取热门详情
 * @param categoryId 热门的id
 * @param success 返回成功的信息
 * @param failure 热门的失败的信息
 */
+ (void)getHotDetailInfoWithCategoryId:(NSString *)categoryId
                               success:(void (^)(id responseObject))success
                               failure:(void (^)(NSError *error))failure{
   NSMutableDictionary *params = [self HotParam];
    // 详情参数ID
    params[@"category_id"] = categoryId;
    params[@"count"] = @"30";
    params[@"level"] = @"6";
    params[@"message_cursor"] = @"0";
    params[@"mpic"] = @"1";
    [NHRequestManager GET:@"http://lf.snssdk.com/neihan/stream/category/data/v2/" parameters:params responseSeializerType:NHResponseSeializerTypeJSON success:^(id responseObject) {
        
        NSString *hotInfo = [NSString stringWithFormat:@"%@hotInfo",categoryId];
        if (((NSArray *)responseObject[@"data"][@"data"]).count == 0) {
            responseObject = [self unarchiveObjectWithFileName:hotInfo];
        }
        [self archiveRootObjectWithFileName:hotInfo tofile:responseObject];
        
        success([self unarchiveObjectWithFileName:hotInfo]);

    } failure:^(NSError *error) {
        failure(error);
    }];
}


#pragma mark -  数据持久化

//  归档
+ (void)archiveRootObjectWithFileName:(NSString *)fileName tofile:(id)responseObject{
    NSString *doucument = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *responsePath = [NSString stringWithFormat:@"%@/%@",doucument,fileName];
    [NSKeyedArchiver archiveRootObject:responseObject toFile:responsePath];
}

//  解档
+ (id)unarchiveObjectWithFileName:(NSString *)fileName{
    NSString *doucument = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
   NSString *responsePath = [NSString stringWithFormat:@"%@/%@",doucument,fileName];
    return [NSKeyedUnarchiver unarchiveObjectWithFile:responsePath];
}
@end
