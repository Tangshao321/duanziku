//
//  NetRequest.m
//  Class02--网络请求
//
//  Created by rimi on 16/9/22.
//  Copyright © 2016年 TJX. All rights reserved.
//

#import "NetRequest.h"
#import "AFNetworking.h"
#import "LoadingView.h"

@implementation NetRequest

// GET请求实现
+ (void)GET:(NSString *)url Parameters:(NSDictionary *)parameters Success:(void (^)(id))success Failure:(void (^)(NSError *))failure{
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"showLoading" object:nil];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    // 请求超时时间
    manager.requestSerializer.timeoutInterval = 10.0;
    // 请求格式,二进制
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    // 返回格式, json
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    // 添加扩展类型
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:
                                                         @"application/json",
                                                         @"text/json",
                                                         @"text/javascript",
                                                         @"text/html", nil];
    [manager GET:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        // 有数据执行成功的 block
        success(responseObject);
        [[NSNotificationCenter defaultCenter] postNotificationName:@"hiddenLoading" object:nil];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        // 请求失败，执行失败的 block
        failure(error);
        [[NSNotificationCenter defaultCenter] postNotificationName:@"hiddenLoading" object:nil];
    }];
}

+ (void)POST:(NSString *)url Parameters:(NSDictionary *)parameters Success:(void (^)(id))success Failure:(void (^)(NSError *))failure{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    // 请求超时时间
    manager.requestSerializer.timeoutInterval = 8.0;
    // 请求格式,二进制
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    // 返回格式, json
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    // 添加扩展类型
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:
                                                         @"application/json",
                                                         @"text/json",
                                                         @"text/javascript",
                                                         @"text/html", nil];
    [manager POST:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        // 有数据执行成功的 block
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        // 请求失败，执行失败的 block
        failure(error);
    }];
}


@end
