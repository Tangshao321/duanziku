//
//  UserInfoNetWorking.m
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "UserInfoNetWorking.h"

@implementation UserInfoNetWorking

//  用户登录
+ (void)userLoginWithLoginParam:(NSArray *)param
                          block:(void(^)(BmobObject *object, NSError *error))block{
    BmobQuery *bqery = [[BmobQuery alloc] init];
    NSString *bql = @"select * from userInfo where username = ? and password = ?";
    [bqery queryInBackgroundWithBQL:bql pvalues:param block:^(BQLQueryResult *result, NSError *error) {
        block( result.resultsAry.firstObject,error);
    }];
}
@end
