//
//  UserInfoNetWorking.h
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInfoNetWorking : NSObject
+ (void)userLoginWithLoginParam:(NSArray *)param
                          block:(void(^)(BmobObject *object, NSError *error))block;
@end
