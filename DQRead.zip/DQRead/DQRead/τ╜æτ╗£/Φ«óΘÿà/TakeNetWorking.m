//
//  TakeNetWorking.m
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "TakeNetWorking.h"
#import "TakeList.h"

@implementation TakeNetWorking
//  查询订阅的信息
+ (void)takeListWithParam:(NSArray *)param
                    block:(void(^)(BQLQueryResult *result, NSError *error))block{
 
    //  参数
    TakeList *take = [TakeList sharedTakeList];
    BmobQuery *bqery = [[BmobQuery alloc] init];
    NSString *bql = [NSString stringWithFormat:@"select * from %@ where %@ = ?" ,take.tableCLassName,take.keyUserTakeId];
    NSLog(@"bql%@",bql);
    [bqery queryInBackgroundWithBQL:bql pvalues:param block:block];
}

//  订阅
+ (void)takedWithCategoryId:(NSInteger)categoryId
       userTakeCategoryList:(id)userTakeCategoryList
                      block:(void (^)(BOOL isSuccessful, NSError *error)) block{
    BmobObject  *takeList = [BmobObject objectWithClassName:[TakeList sharedTakeList].tableCLassName];
    
    //设置关联内容
    [takeList setObject:userTakeCategoryList forKey:[TakeList sharedTakeList].keyUserTakeCategoryList];
        [takeList setObject:[NSString stringWithFormat:@"%ld",categoryId] forKey:[TakeList sharedTakeList].keyCategoryId];
    
    //设置帖子关联的用户id记录
    BmobUser *takeId = [BmobUser objectWithoutDataWithClassName:[UserInfo sharedUserInfo].tableCLassName objectId:[UserInfo sharedUserInfo].objectId];
    
    [takeList setObject:takeId forKey:[TakeList sharedTakeList].keyUserTakeId];
    
    //异步保存
    [takeList saveInBackgroundWithResultBlock:block];
}

//  查看订阅id是否存在
+ (void)findCategoryIdIsExists:(NSInteger)categoryId
                    userTakeId:(id)userTakeId
                         block:(void (^)(BOOL isExists, NSError *error)) block{
    //  参数
    TakeList *take = [TakeList sharedTakeList];
    BmobQuery *bqery = [[BmobQuery alloc] init];
    NSString *bql = [NSString stringWithFormat:@"select * from %@ where %@ = ? and %@ = ?" ,take.tableCLassName,take.keyUserTakeId,take.keyCategoryId];
    NSLog(@"bql%@",bql);
    [bqery queryInBackgroundWithBQL:bql pvalues:@[userTakeId,[NSString stringWithFormat:@"%ld",categoryId]] block:^(BQLQueryResult *result, NSError *error) {
        block(result.resultsAry.count > 0,error);
    }];
}
@end
