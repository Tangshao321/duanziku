//
//  TakeNetWorking.h
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TakeNetWorking : NSObject

//  查询订阅的信息
+ (void)takeListWithParam:(NSArray *)param
                    block:(void(^)(BQLQueryResult *result, NSError *error))block;

//  订阅
+ (void)takedWithCategoryId:(NSInteger)categoryId
       userTakeCategoryList:(id)userTakeCategoryList
                      block:(void (^)(BOOL isSuccessful, NSError *error)) block;


//  查看订阅id是否存在
+ (void)findCategoryIdIsExists:(NSInteger)categoryId
                    userTakeId:(id)userTakeId
                         block:(void (^)(BOOL isExists, NSError *error)) block;
@end
