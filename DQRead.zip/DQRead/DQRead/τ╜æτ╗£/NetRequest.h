//
//  NetRequest.h
//  Class02--网络请求
//
//  Created by rimi on 16/9/22.
//  Copyright © 2016年 TJX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetRequest : NSObject

// GET请求
+ (void)GET:(NSString *)url Parameters:(NSDictionary *)parameters Success:(void(^)(id responseObject))success Failure:(void(^)(NSError *error))failure;

// POST请求
+ (void)POST:(NSString *)url Parameters:(NSDictionary *)parameters Success:(void(^)(id responseObject))success Failure:(void(^)(NSError *error))failure;

@end
