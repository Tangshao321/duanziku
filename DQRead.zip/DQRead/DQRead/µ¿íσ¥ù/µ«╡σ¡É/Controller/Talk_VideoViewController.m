//
//  Talk_VideoViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "Talk_VideoViewController.h"
#import "talk_videoModel.h"
#import "Talk_VideoTableViewCell.h"
#import "WMPlayer.h"

static NSString *const kReusableCellWithIdentifier = @"identifier";

@interface Talk_VideoViewController ()<UITableViewDelegate,UITableViewDataSource,Talk_VideoTableViewCellDelegate,WMPlayerDelegate>{
    WMPlayer *wmPlayer;
    NSIndexPath *currentIndexPath;
    BOOL isHiddenStatusBar;//记录状态的隐藏显示
    BOOL isInCell;//是否在cell中播放
}
@property (nonatomic,strong) RefreshLoadMoreTableView *videoTableView;
@property (nonatomic,strong) NSMutableArray *addVideoArray;
@property (nonatomic,strong) NSArray <talk_videoModel *>*videoArray;

@property (nonatomic,assign) CGFloat maxCellHeight;/**< 行高 */
@property (nonatomic,strong) NSMutableArray *imageArray;/**< 截取视频帧的图片数组 */

@property (nonatomic,assign) NSInteger page;/**< 数据请求页数 */

@property (nonatomic,strong) Talk_VideoTableViewCell *currentCell;

@property (nonatomic,strong) NSTimer *timer;
@property (nonatomic,assign) BOOL isFirst;/**< 是否为第一次进入视图 */

- (void)initializeDataSource;
- (void)initializeUserInterface;

@end

@implementation Talk_VideoViewController

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (BOOL)prefersStatusBarHidden{
    if (isInCell) {
        return NO;
    }
    if (isHiddenStatusBar) {//隐藏
        return YES;
    }
    return NO;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //获取设备旋转方向的通知,即使关闭了自动旋转,一样可以监测到设备的旋转方向
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    //旋转屏幕通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onDeviceOrientationChange:)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil
     ];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    isInCell = YES;
    _isFirst = YES;
    self.view.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1];
    _addVideoArray = [NSMutableArray array];
    _imageArray = [NSMutableArray array];
    //初始化一些全局设置变量
    [self initializeUserInterface];
    self.page = 1;
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
        [self initializeDataSource];
    }
    else{
        NSArray *array = [[NSUserDefaults standardUserDefaults]objectForKey:@"video"];
        _videoArray = [talk_videoModel modelArrayFromJsonArray:array];
        [self.videoTableView reloadData];
    }
}

- (void)initializeDataSource{
    
    NSString *url = [NSString stringWithFormat:@"https://route.showapi.com/255-1?page=%ld&showapi_appid=24781&showapi_timestamp=&title=&type=41&showapi_sign=ea971df6ed034394bb86848112b10e79",_page];
    [NetRequest GET:url Parameters:nil Success:^(id responseObject) {
        [_addVideoArray addObjectsFromArray:responseObject[@"showapi_res_body"][@"pagebean"][@"contentlist"]];
        _videoArray = [talk_videoModel modelArrayFromJsonArray:_addVideoArray];
        [[NSUserDefaults standardUserDefaults]setObject:_addVideoArray forKey:@"video"];
        
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            // 图片帧数组
            for (NSInteger index = 0; index < _videoArray.count; index ++) {
                [_imageArray addObject:[TjxCustomView thumbnailImageForVideo:[NSURL URLWithString:_videoArray[index].video_uri]]];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                _timer.fireDate = [NSDate distantPast];
            });
        });
        [self.videoTableView.mj_header endRefreshing];
        [self.videoTableView.mj_footer endRefreshing];
        [self.videoTableView reloadData];
        
    } Failure:^(NSError *error) {
        NSLog(@"%@",error.localizedDescription);
    }];
    
}
- (void)isLoadData{
    if (!wmPlayer) {
        _timer.fireDate = [NSDate distantFuture];
        [self.videoTableView reloadData];
    }
}

- (void)initializeUserInterface{
    [self.view addSubview:self.videoTableView];
    [self.videoTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(isLoadData) userInfo:nil repeats:YES];
    _timer.fireDate = [NSDate distantFuture];
}

- (void)videoCellClickPlayUrl:(NSString *)playUrl cell:(Talk_VideoTableViewCell *)cell{
    currentIndexPath = [NSIndexPath indexPathForRow:cell.indexPath.row inSection:0];
    
    if (wmPlayer) {
        [self releaseWMPlayer];
        wmPlayer = [[WMPlayer alloc] init];
        wmPlayer.delegate = self;
        wmPlayer.closeBtnStyle = CloseBtnStyleClose;
        wmPlayer.URLString = playUrl;
        wmPlayer.titleLabel.text = [TjxCustomView noWhiteSpaceString:_videoArray[cell.indexPath.row].text];
        wmPlayer.enableVolumeGesture = YES;
        [wmPlayer play];
    }else{
        wmPlayer = [[WMPlayer alloc] init];
        wmPlayer.delegate = self;
        wmPlayer.closeBtnStyle = CloseBtnStyleClose;
        wmPlayer.URLString = playUrl;
        wmPlayer.titleLabel.text = [TjxCustomView noWhiteSpaceString:_videoArray[cell.indexPath.row].text];
        wmPlayer.enableVolumeGesture = YES;
        [wmPlayer play];
    }
    [cell.videoImageView addSubview:wmPlayer];
    [cell.videoImageView bringSubviewToFront:wmPlayer];
    [cell.playBtn.superview sendSubviewToBack:cell.playBtn];
    [wmPlayer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(cell.videoImageView).with.offset(0);
        make.left.equalTo(cell.videoImageView).with.offset(0);
        make.right.equalTo(cell.videoImageView).with.offset(0);
        make.height.equalTo(@(cell.videoImageView.frame.size.height));
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _videoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return _maxCellHeight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Talk_VideoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kReusableCellWithIdentifier];
    if (!cell) {
        cell = [[Talk_VideoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kReusableCellWithIdentifier];
    }
    cell.delegate = self;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.indexPath = indexPath;
    cell.palyUrl = _videoArray[indexPath.row].video_uri;
    [cell.iconImageView sd_setImageWithURL:[NSURL URLWithString:_videoArray[indexPath.row].profile_image] placeholderImage:nil];
    cell.userNameLabel.text = _videoArray[indexPath.row].name;
    cell.creatTime.text = _videoArray[indexPath.row].create_time;
    cell.titleLabel.text = [TjxCustomView noWhiteSpaceString:_videoArray[indexPath.row].text];
    if (_imageArray.count == _videoArray.count) {
        cell.videoImageView.image = _imageArray[indexPath.row];
    }
    if (wmPlayer&&wmPlayer.superview) {
        if (indexPath.row==currentIndexPath.row) {
            [cell.playBtn.superview sendSubviewToBack:cell.playBtn];
        }else{
            [cell.playBtn.superview bringSubviewToFront:cell.playBtn];
        }
        NSArray *indexpaths = [tableView indexPathsForVisibleRows];
        if (![indexpaths containsObject:currentIndexPath]) {//复用
            if ([[UIApplication sharedApplication].keyWindow.subviews containsObject:wmPlayer]) {
                wmPlayer.hidden = NO;
            }else{
                wmPlayer.hidden = YES;
            }
        }
        else{
            if ([cell.videoImageView.subviews containsObject:wmPlayer]) {
                [cell.videoImageView addSubview:wmPlayer];
                [wmPlayer play];
                wmPlayer.hidden = NO;
            }
        }
    }
    _maxCellHeight = cell.getCellMaxHeight;
    return cell;
}

- (RefreshLoadMoreTableView *)videoTableView{
    if (!_videoTableView) {
        _videoTableView = [[RefreshLoadMoreTableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain withTag:1001 withDelegate:self withCellName:kReusableCellWithIdentifier withRowHeight:200 withReuseIndentifier:kReusableCellWithIdentifier withRefreshBlock:^(UITableView *sender) {
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
                _addVideoArray = [NSMutableArray array];
                _imageArray = [NSMutableArray array];
                [self initializeDataSource];
            }
            else{
                NSArray *array = [[NSUserDefaults standardUserDefaults]objectForKey:@"video"];
                _videoArray = [talk_videoModel modelArrayFromJsonArray:array];
                [self.videoTableView reloadData];
                [self.videoTableView.mj_header endRefreshing];
            }
        } withLoadMoreBlock:^(UITableView *sender) {
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
                if (!_isFirst) {
                    _page ++;
                    _imageArray = [NSMutableArray array];
                    [self initializeDataSource];
                }
                _isFirst = NO;
            }
            else{
                [TjxCustomView showMessageAutoDismissWithTitle:@"错误" content:@"请检查网络连接" disMissTime:1.5];
                [self.videoTableView.mj_footer endRefreshing];
            }
        }];
    }
    return _videoTableView;
}


#pragma mark - player Method


///播放器事件
-(void)wmplayer:(WMPlayer *)wmplayer clickedCloseButton:(UIButton *)closeBtn{
    if (wmplayer.isFullscreen) {
        Talk_VideoTableViewCell *currentCell = (Talk_VideoTableViewCell *)[self.videoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:currentIndexPath.row inSection:0]];
        [currentCell.videoImageView addSubview:wmPlayer];
        
        [self toOrientation:UIInterfaceOrientationPortrait];
        wmPlayer.isFullscreen = NO;
        wmPlayer.closeBtnStyle = CloseBtnStyleClose;
    }else{
        [self releaseWMPlayer];
    }
}
-(void)wmplayer:(WMPlayer *)wmplayer clickedFullScreenButton:(UIButton *)fullScreenBtn{
    [wmplayer removeFromSuperview];
    if (wmPlayer.isFullscreen) {//全屏
        Talk_VideoTableViewCell *currentCell = (Talk_VideoTableViewCell *)[self.videoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:currentIndexPath.row inSection:0]];
        [currentCell.videoImageView addSubview:wmPlayer];
        [self toOrientation:UIInterfaceOrientationPortrait];
        wmPlayer.isFullscreen = NO;
        wmPlayer.closeBtnStyle = CloseBtnStyleClose;
        
    }else{//非全屏
        [[UIApplication sharedApplication].keyWindow addSubview:wmPlayer];
        [self toOrientation:UIInterfaceOrientationLandscapeRight];
        wmPlayer.isFullscreen = YES;
        wmPlayer.closeBtnStyle = CloseBtnStylePop;
    }
}

// 播放结束
-(void)wmplayerFinishedPlay:(WMPlayer *)wmplayer{
    Talk_VideoTableViewCell *currentCell = (Talk_VideoTableViewCell *)[self.videoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:currentIndexPath.row inSection:0]];
    [currentCell.playBtn.superview bringSubviewToFront:currentCell.playBtn];
    [self toOrientation:UIInterfaceOrientationPortrait];
    [wmPlayer removeFromSuperview];
    
}
//操作栏隐藏或者显示都会调用此方法
-(void)wmplayer:(WMPlayer *)wmplayer isHiddenTopAndBottomView:(BOOL)isHidden{
    isHiddenStatusBar = isHidden;
    [self setNeedsStatusBarAppearanceUpdate];
}
/**
 *  旋转屏幕通知
 */
- (void)onDeviceOrientationChange:(NSNotification *)notification{
    if (wmPlayer==nil||wmPlayer.superview==nil){
        return;
    }
    
    UIDeviceOrientation orientation = [UIDevice currentDevice].orientation;
    UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)orientation;
    switch (interfaceOrientation) {
        case UIInterfaceOrientationPortraitUpsideDown:{
        }
            break;
        case UIInterfaceOrientationPortrait:{
            if (wmPlayer.isFullscreen) {
                [wmPlayer removeFromSuperview];
                Talk_VideoTableViewCell *currentCell = (Talk_VideoTableViewCell *)[self.videoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:currentIndexPath.row inSection:0]];
                [currentCell addSubview:wmPlayer];
                [self toOrientation:UIInterfaceOrientationPortrait];
                wmPlayer.isFullscreen = NO;
                isHiddenStatusBar = NO;
                isInCell = YES;
                wmPlayer.closeBtnStyle = CloseBtnStyleClose;
                
            }
        }
            break;
        case UIInterfaceOrientationLandscapeLeft:{
            if (wmPlayer.isFullscreen==NO) {
                [wmPlayer removeFromSuperview];
                [[UIApplication sharedApplication].keyWindow addSubview:wmPlayer];
                [self toOrientation:UIInterfaceOrientationLandscapeLeft];
                wmPlayer.isFullscreen = YES;
                isInCell = NO;
                isHiddenStatusBar = YES;
                wmPlayer.closeBtnStyle = CloseBtnStylePop;
            }
            
        }
            break;
        case UIInterfaceOrientationLandscapeRight:{
            if (wmPlayer.isFullscreen==NO) {
                [wmPlayer removeFromSuperview];
                [[UIApplication sharedApplication].keyWindow addSubview:wmPlayer];
                [self toOrientation:UIInterfaceOrientationLandscapeRight];
                wmPlayer.isFullscreen = YES;
                isInCell = NO;
                isHiddenStatusBar = YES;
                wmPlayer.closeBtnStyle = CloseBtnStylePop;
            }
        }
            break;
        default:
            break;
    }
    [self setNeedsStatusBarAppearanceUpdate];
}
//点击进入,退出全屏,或者监测到屏幕旋转去调用的方法
-(void)toOrientation:(UIInterfaceOrientation)orientation{
    //获取到当前状态条的方向
    UIInterfaceOrientation currentOrientation = [UIApplication sharedApplication].statusBarOrientation;
    
    //判断如果当前方向和要旋转的方向一致,那么不做任何操作
    if (currentOrientation == orientation) {
        return;
    }
    //根据要旋转的方向,使用Masonry重新修改限制
    if (orientation ==UIInterfaceOrientationPortrait) {//
        Talk_VideoTableViewCell *currentCell = (Talk_VideoTableViewCell *)[self.videoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:currentIndexPath.row inSection:0]];
        
        [wmPlayer mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(currentCell.videoImageView).with.offset(0);
            make.left.equalTo(currentCell.videoImageView).with.offset(0);
            make.right.equalTo(currentCell.videoImageView).with.offset(0);
            make.height.equalTo(@(currentCell.videoImageView.frame.size.height));
        }];
    }else{
        //这个地方加判断是为了从全屏的一侧,直接到全屏的另一侧不用修改限制,否则会出错;
        if (currentOrientation == UIInterfaceOrientationPortrait) {
            [wmPlayer mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.width.equalTo(@([UIScreen mainScreen].bounds.size.height));
                make.height.equalTo(@([UIScreen mainScreen].bounds.size.width));
                make.center.equalTo(wmPlayer.superview);
            }];
        }
    }
    //iOS6.0之后,设置状态条的方法能使用的前提是shouldAutorotate为NO,也就是说这个视图控制器内,旋转要关掉;
    //也就是说在实现这个方法的时候-(BOOL)shouldAutorotate返回值要为NO
    
    [[UIApplication sharedApplication] setStatusBarOrientation:orientation animated:NO];
    
    //获取旋转状态条需要的时间:
    [UIView beginAnimations:nil context:nil];
    //更改了状态条的方向,但是设备方向UIInterfaceOrientation还是正方向的,这就要设置给你播放视频的视图的方向设置旋转
    //给你的播放视频的view视图设置旋转
    wmPlayer.transform = CGAffineTransformIdentity;
    wmPlayer.transform = [WMPlayer getCurrentDeviceOrientation];
    [UIView setAnimationDuration:1.0]; 
    //开始旋转
    [UIView commitAnimations];
    
}

#pragma mark scrollView delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(scrollView ==self.videoTableView){
        if (wmPlayer==nil) {
            return;
        }
        if (wmPlayer.superview) {
            CGRect rectInTableView = [self.videoTableView rectForRowAtIndexPath:currentIndexPath];
            CGRect rectInSuperview = [self.videoTableView convertRect:rectInTableView toView:[self.videoTableView superview]];
            
            if (rectInSuperview.origin.y<-self.currentCell.videoImageView.frame.size.height - 100 ||rectInSuperview.origin.y>[UIScreen mainScreen].bounds.size.height) {//往上拖动
                [self releaseWMPlayer];
                [self.currentCell.playBtn.superview bringSubviewToFront:self.currentCell.playBtn];
            }
        }
        
    }
}
/**
 *  释放WMPlayer
 */
-(void)releaseWMPlayer{
    //堵塞主线程
    [wmPlayer pause];
    [wmPlayer removeFromSuperview];
    [wmPlayer.playerLayer removeFromSuperlayer];
    [wmPlayer.player replaceCurrentItemWithPlayerItem:nil];
    wmPlayer.player = nil;
    wmPlayer.currentItem = nil;
    //释放定时器，否侧不会调用WMPlayer中的dealloc方法
    [wmPlayer.autoDismissTimer invalidate];
    wmPlayer.autoDismissTimer = nil;
    
    wmPlayer.playOrPauseBtn = nil;
    wmPlayer.playerLayer = nil;
    wmPlayer = nil;
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [self releaseWMPlayer];
}

@end
