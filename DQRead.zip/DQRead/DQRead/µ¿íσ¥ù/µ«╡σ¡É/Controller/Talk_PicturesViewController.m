//
//  Talk_PicturesViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "Talk_PicturesViewController.h"
#import "Talk_PicturesTableViewCell.h"
#import "talk_picturesModel.h"
#import <ImageIO/ImageIO.h>
#import <UIImage+GIF.h>

@interface Talk_PicturesViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)RefreshLoadMoreTableView *tableView;

@property (nonatomic,strong)NSArray <talk_picturesModel *>*Talk_picturesModelArray;

@property (nonatomic,assign)CGFloat maxCellHeight; /**< cell最大值 */
@property (nonatomic,assign)NSInteger flage; /**< 图片高于15000的标记 */
@property (nonatomic,strong)NSMutableArray *muArray;//图片高度数组
@property (nonatomic,strong)NSMutableArray *picMuArray; /**< 数据源数组 */
@property (nonatomic,assign)NSInteger page; /**< 页数 */
@property (nonatomic,assign)CGFloat setY;
@end

@implementation Talk_PicturesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1];
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
        [self initData];
    }
    else{
        NSArray *array = [[NSUserDefaults standardUserDefaults]objectForKey:@"img"];
        _Talk_picturesModelArray = [talk_picturesModel modelArrayFromJsonArray:array];
        [self.tableView reloadData];
    }
    _picMuArray = [NSMutableArray array];
    _page = 1;
    [self.view addSubview:self.tableView];
}

- (void)initData {
    NSString *url = [NSString stringWithFormat:@"https://route.showapi.com/255-1?page=%ld&showapi_appid=24781&showapi_timestamp=&title=&type=10&showapi_sign=ea971df6ed034394bb86848112b10e79",_page];
    [NetRequest GET:url Parameters:nil Success:^(id responseObject) {
        [_picMuArray addObjectsFromArray:responseObject[@"showapi_res_body"][@"pagebean"][@"contentlist"]];
        _Talk_picturesModelArray = [talk_picturesModel modelArrayFromJsonArray:_picMuArray];
        [[NSUserDefaults standardUserDefaults]setObject:_picMuArray forKey:@"img"];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self initImageHeigtArray:_picMuArray];
            [_tableView reloadData];
            [_tableView.mj_header endRefreshing];
            [_tableView.mj_footer endRefreshing];
        });
    } Failure:^(NSError *error) {
        NSLog(@"%@",error.localizedDescription);
    }];
}
//计算图片高度
- (void)initImageHeigtArray:(NSArray *)array {

    _muArray = [NSMutableArray array];
    //创建一个线程组
    dispatch_queue_t queue = dispatch_queue_create("queue", DISPATCH_QUEUE_SERIAL);
    dispatch_group_t group = dispatch_group_create();
    
    for (NSInteger index = 0; index < array.count; index ++) {
        
         dispatch_group_async(group, queue, ^{
             NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:array[index][@"image0"]]];
             UIImage *image = [UIImage imageWithData:data];
             CGFloat content = (NSInteger)image.size.height;
             if (content < 500.0) {
                 content = 500.0;
             }
             [_muArray addObject:@(content)];
         });
    }
    dispatch_group_notify(group, queue, ^{
       dispatch_async(dispatch_get_main_queue(), ^{
           [self.tableView reloadData];
           self.tableView.contentOffset = CGPointMake(0, _setY);
       });
    });
    [[NSUserDefaults standardUserDefaults]setObject:_muArray forKey:@"numAry"];
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _Talk_picturesModelArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"Talk_PicturesCell";
    Talk_PicturesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell) {
        cell = [[Talk_PicturesTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    //取出高度
    NSArray *array = _muArray;
    if (indexPath.row >= array.count) {
        _maxCellHeight = 0;
    } else {
        _maxCellHeight = [array[indexPath.row] floatValue];
    }
    //判断图片大小
    if (_maxCellHeight >= 15000.0) {
        _flage = 2;
    }else {
    cell.contentImgView.frame = DQAdaptionRectFromFrame(CGRectMake(25, 235, 700, _maxCellHeight));
    NSString *imgStr = _Talk_picturesModelArray[indexPath.row].image0;
    NSString *str = [imgStr substringFromIndex:imgStr.length - 1];
    if ([str isEqualToString:@"g"]) {
        [cell.contentImgView sd_setImageWithURL:[NSURL URLWithString:_Talk_picturesModelArray[indexPath.row].image0]];
    }else {
        cell.contentImgView.image = [UIImage sd_animatedGIFWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:_Talk_picturesModelArray[indexPath.row].image0]]];
    }
    cell.titleLabel.text = _Talk_picturesModelArray[indexPath.row].name;
    cell.contentLabel.text = _Talk_picturesModelArray[indexPath.row].text;
    [cell.headImgView sd_setImageWithURL:[NSURL URLWithString:_Talk_picturesModelArray[indexPath.row].profile_image]];
    cell.timeLabel.text = _Talk_picturesModelArray[indexPath.row].create_time;
        _flage = 0;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    //取出高度
    NSArray *array = _muArray;
    if (indexPath.row >= array.count) {
        _maxCellHeight = 0;
    } else {
        _maxCellHeight = [array[indexPath.row] floatValue];
    }
    if (_maxCellHeight >= 15000.0) {
        _flage = 2;
    }else {
        _flage = 0;
    }
    return _flage == 2 ? 0 : DQAdaption(_maxCellHeight + 260);
}


#pragma mark - 懒加载

- (RefreshLoadMoreTableView *)tableView {
    if (!_tableView) {
        _tableView = [[RefreshLoadMoreTableView alloc]initWithFrame:self.view.frame style:UITableViewStylePlain withTag:100 withDelegate:self withCellName:@"Talk_PicturesTableViewCell" withRowHeight:DQAdaption(500) withReuseIndentifier:@"Talk_PicturesCell" withRefreshBlock:^(UITableView *sender) {
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
                [_tableView reloadData];
            }
            else{
                NSArray *array = [[NSUserDefaults standardUserDefaults]objectForKey:@"img"];
                _Talk_picturesModelArray = [talk_picturesModel modelArrayFromJsonArray:array];
                [self.tableView reloadData];
                [self.tableView.mj_header endRefreshing];
            }
        } withLoadMoreBlock:^(UITableView *sender) {
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
                _page ++;
                _setY = _tableView.contentOffset.y;
                [self initData];
            }
            else{
                [TjxCustomView showMessageAutoDismissWithTitle:@"错误" content:@"请检查网络连接" disMissTime:1.5];
                [self.tableView.mj_footer endRefreshing];
            }
            
        }];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;

}


@end
