//
//  Talk_TalkViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "Talk_TalkViewController.h"
#import "talk_talkModel.h"
#import "Talk_TalkTableViewCell.h"

static NSString *const kReusableCellWithIdentifier = @"identifier";

@interface Talk_TalkViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) RefreshLoadMoreTableView *talkTableView;
@property (nonatomic,strong) NSArray <talk_talkModel *>*talkArray;
@property (nonatomic,assign) CGFloat maxCellHeight;
@property (nonatomic,strong) NSMutableArray *addTalkArray;
@property (nonatomic,assign) NSInteger page;

- (void)initializeDataSource;
- (void)initializeUserInterface;

@end

@implementation Talk_TalkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1];
    _addTalkArray = [NSMutableArray array];
    _page = 1;/**< 默认从第一页开始 */
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
        [self initializeDataSource];
    }
    else{
        NSArray *array = [[NSUserDefaults standardUserDefaults]objectForKey:@"talk"];
        _talkArray = [talk_talkModel modelArrayFromJsonArray:array];
        [self.talkTableView reloadData];
    }
    [self initializeUserInterface];
}

- (void)initializeDataSource{
    
    NSString *url = [NSString stringWithFormat:@"https://route.showapi.com/255-1?page=%ld&showapi_appid=24781&showapi_timestamp=&title=&type=29&showapi_sign=ea971df6ed034394bb86848112b10e79",_page];
    [NetRequest GET:url Parameters:nil Success:^(id responseObject) {
        [_addTalkArray addObjectsFromArray:responseObject[@"showapi_res_body"][@"pagebean"][@"contentlist"]];
        _talkArray = [talk_talkModel modelArrayFromJsonArray:_addTalkArray];
        [[NSUserDefaults standardUserDefaults] setObject:_addTalkArray forKey:@"talk"];
        [self.talkTableView reloadData];
        [self.talkTableView.mj_header endRefreshing];
        [self.talkTableView.mj_footer endRefreshing];
    
    } Failure:^(NSError *error) {
        NSLog(@"%@",error.localizedDescription);
    }];
}

- (void)initializeUserInterface{
    [self.view addSubview:self.talkTableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _talkArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Talk_TalkTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kReusableCellWithIdentifier];
    if (!cell) {
        cell = [[Talk_TalkTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kReusableCellWithIdentifier];
    }
    _maxCellHeight = [cell setCellHeightWithContentHeight:_talkArray[indexPath.row].contentHeight];
    [cell.talkImageView sd_setImageWithURL:[NSURL URLWithString:_talkArray[indexPath.row].profile_image]];
    cell.talkAuthor.text = _talkArray[indexPath.row].name;
    cell.talkTime.text = _talkArray[indexPath.row].create_time;
    cell.talkContent.text = _talkArray[indexPath.row].text;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return _maxCellHeight;
}

- (RefreshLoadMoreTableView *)talkTableView{
    if (!_talkTableView) {
   
        _talkTableView = [[RefreshLoadMoreTableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain withTag:1001 withDelegate:self withCellName:kReusableCellWithIdentifier withRowHeight:200 withReuseIndentifier:kReusableCellWithIdentifier withRefreshBlock:^(UITableView *sender) {
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
                _addTalkArray = [NSMutableArray array];
                [self initializeDataSource];
            }
            else{
                NSArray *array = [[NSUserDefaults standardUserDefaults]objectForKey:@"talk"];
                _talkArray = [talk_talkModel modelArrayFromJsonArray:array];
                [self.talkTableView reloadData];
                [self.talkTableView.mj_header endRefreshing];
            }
            
        } withLoadMoreBlock:^(UITableView *sender) {
            
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
                _page ++;
                [self initializeDataSource];
            }
            else{
                [TjxCustomView showMessageAutoDismissWithTitle:@"错误" content:@"请检查网络连接" disMissTime:1.5];
                [self.talkTableView.mj_footer endRefreshing];
            }
        }];
    }
    return _talkTableView;
}


@end
