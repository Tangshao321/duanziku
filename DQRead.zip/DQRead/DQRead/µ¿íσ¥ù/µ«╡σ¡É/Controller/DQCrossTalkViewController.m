//
//  DQCrossTalkViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQCrossTalkViewController.h"
#import "Talk_PicturesViewController.h"
#import "Talk_TalkViewController.h"
#import "Talk_VideoViewController.h"
#import "Talk_VoiceViewController.h"

@interface DQCrossTalkViewController ()<VTMagicViewDelegate,VTMagicViewDataSource>

@property (nonatomic,strong)VTMagicController *magicController;
@property (nonatomic,strong)NSMutableArray<UIViewController*> *viewControllers;

@end

@implementation DQCrossTalkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1];
    [self.view addSubview:self.magicController.view];
    [self.magicController.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(0, 0, 0, 0));
        make.width.height.equalTo(self.view);
    }];
    [_magicController.magicView reloadData];
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex {
    NSArray *pageArr = @[@"Talk_VideoViewController",@"Talk_TalkViewController",@"Talk_VoiceViewController",@"Talk_PicturesViewController"];
    UIViewController *vc = [magicView dequeueReusablePageWithIdentifier:pageArr[pageIndex]];
    if (!vc) {
        vc = [[NSClassFromString(pageArr[pageIndex]) alloc]init];
    }
    return vc;
}


//标题数组
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView
{
    return @[@"视频",@"段子",@"音乐",@"图片"];
}
//字体样式
- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex
{
    static NSString *itemIdentifier = @"itemIdentifier";
    UIButton *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (!menuItem) {
        menuItem = [UIButton buttonWithType:UIButtonTypeCustom];
        [menuItem setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [menuItem setTitleColor:[UIColor colorWithRed:0.47 green:0.63 blue:0.31 alpha:1.00] forState:UIControlStateSelected];
        menuItem.titleLabel.font = [UIFont fontWithName:@"Helvetica" size:14.f];
    }
    return menuItem;
}


- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
        _magicController.magicView.navigationColor = [UIColor whiteColor];
        _magicController.magicView.sliderColor = [UIColor colorWithRed:0.47 green:0.63 blue:0.31 alpha:1.00];
        _magicController.magicView.switchStyle = VTSwitchStyleDefault;
        _magicController.magicView.layoutStyle = VTLayoutStyleDivide;
        _magicController.magicView.headerHeight = 40.f;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
        // 是否预加载下一页  默认为yes
        _magicController.magicView.needPreloading = NO;
    }
    return _magicController;
}

@end
