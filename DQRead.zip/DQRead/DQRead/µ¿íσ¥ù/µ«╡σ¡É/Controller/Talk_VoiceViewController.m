//
//  Talk_VoiceViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "Talk_VoiceViewController.h"
#import "talk_voiceModel.h"
#import "Talk_VoiceTableViewCell.h"
#import "AudioPlayer.h"

static NSString *const kReusableCellWithIdentifier = @"identifier";

@interface Talk_VoiceViewController ()<UITableViewDelegate,UITableViewDataSource,Talk_VoiceTableViewCellDelegate>

@property (nonatomic,strong) NSArray <talk_voiceModel *>*voiceArray;
@property (nonatomic,strong) NSMutableArray *addVoiceArray;
@property (nonatomic,strong) RefreshLoadMoreTableView *voiceTableView;
@property (nonatomic,assign) CGFloat maxCellHeight;
@property (nonatomic,strong) AudioPlayer *audioPlayer;

@property (nonatomic,assign) NSInteger page;

- (void)initializeDataSource;
- (void)initializeUserInterface;

@end

@implementation Talk_VoiceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1];
    _addVoiceArray = [NSMutableArray array];
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
        [self initializeDataSource];
    }
    else{
        NSArray *array = [[NSUserDefaults standardUserDefaults]objectForKey:@"voice"];
        _voiceArray = [talk_voiceModel modelArrayFromJsonArray:array];
        [self.voiceTableView reloadData];
    }
    _page = 1;
    [self initializeUserInterface];
}

- (void)initializeDataSource{
    NSString *url = [NSString stringWithFormat:@"https://route.showapi.com/255-1?page=%ld&showapi_appid=24781&showapi_timestamp=&title=&type=31&showapi_sign=ea971df6ed034394bb86848112b10e79",_page];
    [NetRequest GET:url Parameters:nil Success:^(id responseObject) {
        [_addVoiceArray addObjectsFromArray:responseObject[@"showapi_res_body"][@"pagebean"][@"contentlist"]];
        _voiceArray = [talk_voiceModel modelArrayFromJsonArray:_addVoiceArray];
        [[NSUserDefaults standardUserDefaults]setObject:_addVoiceArray forKey:@"voice"];
        
        [self.voiceTableView reloadData];
        [self.voiceTableView.mj_header endRefreshing];
        [self.voiceTableView.mj_footer endRefreshing];
    } Failure:^(NSError *error) {
        NSLog(@"%@",error.localizedDescription);
    }];
    
}

- (void)initializeUserInterface{
    [self.view addSubview:self.voiceTableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _voiceArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Talk_VoiceTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kReusableCellWithIdentifier];
    if (!cell) {
        cell = [[Talk_VoiceTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kReusableCellWithIdentifier];
    }
    cell.delegate = self;
    [cell.iconImageView sd_setImageWithURL:[NSURL URLWithString:_voiceArray[indexPath.row].profile_image]];
    cell.userNameLabel.text = _voiceArray[indexPath.row].name;
    cell.creatTimeLabel.text = _voiceArray[indexPath.row].create_time;
    cell.contentLabel.text = [TjxCustomView noWhiteSpaceString:_voiceArray[indexPath.row].text];
    
    [cell.voiceCover sd_setImageWithURL:[NSURL URLWithString:_voiceArray[indexPath.row].image3] placeholderImage:nil];
    
    cell.playUrl = _voiceArray[indexPath.row].voice_uri;
    
    _maxCellHeight = [cell setContentHeight:_voiceArray[indexPath.row].contentHeight];
    
    return cell;
}

#pragma mark - cellClick delegate

- (void)videoCellClickPlayUrl:(NSString *)playUrl button:(AudioButton *)sender{
    if (_audioPlayer == nil) {
        _audioPlayer = [[AudioPlayer alloc] init];
    }
    
    if ([_audioPlayer.button isEqual:sender]) {
        [_audioPlayer play];
    } else {
        [_audioPlayer stop];
        
        _audioPlayer.button = sender;
        _audioPlayer.url = [NSURL URLWithString:playUrl];
        
        [_audioPlayer play];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return _maxCellHeight;
}

- (RefreshLoadMoreTableView *)voiceTableView{
    if (!_voiceTableView) {
        _voiceTableView = [[RefreshLoadMoreTableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain withTag:10001 withDelegate:self withCellName:kReusableCellWithIdentifier withRowHeight:200 withReuseIndentifier:kReusableCellWithIdentifier withRefreshBlock:^(UITableView *sender) {
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
                _addVoiceArray = [NSMutableArray array];
                [self initializeDataSource];
            }
            else{
                NSArray *array = [[NSUserDefaults standardUserDefaults]objectForKey:@"voice"];
                _voiceArray = [talk_voiceModel modelArrayFromJsonArray:array];
                [self.voiceTableView reloadData];
                [self.voiceTableView.mj_header endRefreshing];
            }
            
        } withLoadMoreBlock:^(UITableView *sender) {
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"isNetwork"] boolValue]) {
                _page ++;
                [self initializeDataSource];
            }
            else{
                [TjxCustomView showMessageAutoDismissWithTitle:@"错误" content:@"请检查网络连接" disMissTime:1.5];
                [self.voiceTableView.mj_footer endRefreshing];
            }
            
        }];
    }
    return _voiceTableView;
}

@end
