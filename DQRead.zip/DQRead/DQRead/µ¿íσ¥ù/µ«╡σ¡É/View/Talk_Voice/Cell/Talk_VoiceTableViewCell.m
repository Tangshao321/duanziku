//
//  Talk_VoiceTableViewCell.m
//  DQRead
//
//  Created by rimi on 2016/12/1.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "Talk_VoiceTableViewCell.h"

@implementation Talk_VoiceTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setUI];
    }
    return self;
}

- (void)setUI{
    _iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 40, 40)];
    _iconImageView.layer.cornerRadius = 20;
    _iconImageView.layer.masksToBounds = YES;
    [self.contentView addSubview:_iconImageView];
    
    _userNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_iconImageView.frame) + 10, CGRectGetMinY(_iconImageView.frame) + 10, SCREEN_WIDTH * 0.5, 20)];
    _userNameLabel.font = DQAFont(25);
    [self.contentView addSubview:_userNameLabel];
    
    _creatTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 130, CGRectGetMinY(_userNameLabel.frame), 120, CGRectGetHeight(_userNameLabel.bounds))];
    _creatTimeLabel.font = DQAFont(20);
    _creatTimeLabel.textColor = [UIColor grayColor];
    [self.contentView addSubview:_creatTimeLabel];
    
    _contentLabel = [[UILabel alloc] init];
    _contentLabel.numberOfLines = 0;
    _contentLabel.font = DQAFont(25);
    [self.contentView addSubview:_contentLabel];
    
    _voiceCover = [[UIImageView alloc] init];
    _voiceCover.layer.cornerRadius = 25;
    _voiceCover.layer.masksToBounds = YES;
    [self.contentView addSubview:_voiceCover];
    
    _voiceButton = [[AudioButton alloc] init];
    _voiceButton.layer.cornerRadius = 25;
    _voiceButton.layer.masksToBounds = YES;
    [_voiceButton addTarget:self action:@selector(playClick) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:_voiceButton];
    
    _lineView = [[UIView alloc] init];
    _lineView.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1.00];
    [self.contentView addSubview:_lineView];
    
}

- (CGFloat)setContentHeight:(CGFloat)contentHeight{
    
    if (contentHeight < 50) {
        _contentLabel.frame = CGRectMake(CGRectGetMinX(_iconImageView.frame), CGRectGetMaxY(_iconImageView.frame) + 10, SCREEN_WIDTH * 0.7, 50);
    }
    else{
        _contentLabel.frame = CGRectMake(CGRectGetMinX(_iconImageView.frame), CGRectGetMaxY(_iconImageView.frame) + 10, SCREEN_WIDTH * 0.7, contentHeight);
    }
    
    _voiceCover.center = CGPointMake(SCREEN_WIDTH - 60, CGRectGetMidY(_contentLabel.frame));
    _voiceCover.bounds = CGRectMake(0, 0, 50, 50);
    
    _voiceButton.frame = _voiceCover.frame;
    
    _lineView.frame = CGRectMake(0, CGRectGetMaxY(_contentLabel.frame) + 10, SCREEN_WIDTH, 10);
    
    return CGRectGetMaxY(_lineView.frame);
}

- (void)playClick{
    [self.delegate videoCellClickPlayUrl:_playUrl button:_voiceButton];
}

@end
