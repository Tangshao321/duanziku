//
//  Talk_VoiceTableViewCell.h
//  DQRead
//
//  Created by rimi on 2016/12/1.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AudioButton.h"
@class Talk_VoiceTableViewCell;

@protocol Talk_VoiceTableViewCellDelegate <NSObject>

//cell 播放按钮点击时候回调的代理方法
- (void)videoCellClickPlayUrl:(NSString *)playUrl button:(AudioButton *)sender;

@end

@interface Talk_VoiceTableViewCell : UITableViewCell

@property (nonatomic,strong) UIImageView *iconImageView;/**< 用户头像 */
@property (nonatomic,strong) UILabel *userNameLabel;/**< 用户名 */
@property (nonatomic,strong) UILabel *creatTimeLabel;/**< 时间 */
@property (nonatomic,strong) UILabel *contentLabel;/**< 内容文本 */

@property (nonatomic,strong) UIImageView *voiceCover;/**< 音乐封面 */
@property (nonatomic,strong) AudioButton *voiceButton;/**< 播放按钮 */

@property (nonatomic,strong) UIView *lineView;
@property (nonatomic,strong) NSString *playUrl;
@property (nonatomic,assign) id <Talk_VoiceTableViewCellDelegate>delegate;

- (CGFloat)setContentHeight:(CGFloat)contentHeight;

@end
