//
//  Talk_VideoTableViewCell.m
//  DQRead
//
//  Created by rimi on 2016/12/1.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "Talk_VideoTableViewCell.h"

@implementation Talk_VideoTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setUI];
    }
    return self;
}

- (void)setUI{
    _iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 40, 40)];
    _iconImageView.layer.cornerRadius = 20;
    _iconImageView.layer.masksToBounds = YES;
    [self.contentView addSubview:_iconImageView];
    
    _userNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_iconImageView.frame) + 10, CGRectGetMinY(_iconImageView.frame) + 10, SCREEN_WIDTH * 0.5, 20)];
    _userNameLabel.font = DQAFont(25);
    [self.contentView addSubview:_userNameLabel];
    
    
    _creatTime = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 130, CGRectGetMinY(_userNameLabel.frame), 120, CGRectGetHeight(_userNameLabel.bounds))];
    _creatTime.font = DQAFont(20);
    _creatTime.textColor = [UIColor grayColor];
    [self.contentView addSubview:_creatTime];
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMinX(_iconImageView.frame), CGRectGetMaxY(_iconImageView.frame), SCREEN_WIDTH - 20, 50)];
    _titleLabel.font = DQAFont(25);
    _titleLabel.numberOfLines = 0;
    _titleLabel.textColor = [UIColor blackColor];
    [self.contentView addSubview:_titleLabel];
    
    
    _videoImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMinX(_iconImageView.frame), CGRectGetMaxY(_titleLabel.frame) + 10, SCREEN_WIDTH - 20, 200)];
    _videoImageView.userInteractionEnabled = YES;
    _videoImageView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"kuBackground.jpg"]];
    [self.contentView addSubview:_videoImageView];
    
    _playBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_playBtn setImage:[UIImage imageNamed:@"play"] forState:UIControlStateNormal];
    [_playBtn addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.videoImageView addSubview:_playBtn];
    [_playBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.videoImageView);
        make.width.height.mas_equalTo(50);
    }];
    
    _lineView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_videoImageView.frame) + 10, SCREEN_WIDTH, 10)];
    _lineView.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1.00];
    [self.contentView addSubview:_lineView];
    
}


- (CGFloat)getCellMaxHeight{
    return CGRectGetMaxY(_lineView.frame);
}

- (void)buttonClick{
    [self.delegate videoCellClickPlayUrl:_palyUrl cell:self];
}


@end
