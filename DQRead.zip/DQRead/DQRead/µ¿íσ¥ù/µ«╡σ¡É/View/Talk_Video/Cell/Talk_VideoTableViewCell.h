//
//  Talk_VideoTableViewCell.h
//  DQRead
//
//  Created by rimi on 2016/12/1.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Talk_VideoTableViewCell;

@protocol Talk_VideoTableViewCellDelegate <NSObject>

//cell 播放按钮点击时候回调的代理方法
- (void)videoCellClickPlayUrl:(NSString *)playUrl cell:(Talk_VideoTableViewCell *)cell;

@end

@interface Talk_VideoTableViewCell : UITableViewCell

@property (nonatomic,strong) UIImageView *iconImageView;/**< 头像 */
@property (nonatomic,strong) UILabel *userNameLabel;/**< 用户名 */
@property (nonatomic,strong) UILabel *creatTime;/**< 创建时间 */
@property (nonatomic,strong) UILabel *titleLabel;/**< 标题 */
@property (nonatomic,strong) UIImageView *videoImageView;/**< 视频图片 */
@property (nonatomic,strong) UIView *lineView;

@property (nonatomic,strong) UIButton *playBtn;

@property (nonatomic,strong) NSString *palyUrl;
@property (nonatomic,strong) NSIndexPath    * indexPath;        //cell indexPath

@property (nonatomic,assign) id <Talk_VideoTableViewCellDelegate>delegate;


- (CGFloat)getCellMaxHeight;

@end
