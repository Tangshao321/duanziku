//
//  Talk_TalkTableViewCell.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "Talk_TalkTableViewCell.h"

@implementation Talk_TalkTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setUI];
    }
    return self;
}

- (void)setUI{
    _talkContent = [[UILabel alloc] init];
    _talkContent.numberOfLines = 0;
    _talkContent.font = DQAFont(25);
    [self.contentView addSubview:_talkContent];
    
    _talkImageView = [[UIImageView alloc] init];
    _talkImageView.layer.cornerRadius = 25;
    _talkImageView.layer.masksToBounds = YES;
    [self.contentView addSubview:_talkImageView];
    
    
    _talkAuthor = [[UILabel alloc] init];
    _talkAuthor.font = DQAFont(20);
    [self.contentView addSubview:_talkAuthor];
    
    _talkTime = [[UILabel alloc] init];
    _talkTime.font = DQAFont(18);
    [self.contentView addSubview:_talkTime];
    
    _backView = [[UIView alloc] init];
    _backView.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1.00];
    [self.contentView addSubview:_backView];
    
}

- (CGFloat)setCellHeightWithContentHeight:(CGFloat)contentHeight{
    
    _talkImageView.frame = CGRectMake(10, 10, 50, 50);
    
    _talkAuthor.frame = CGRectMake(CGRectGetMaxX(_talkImageView.frame) + 10, CGRectGetMinY(_talkImageView.frame), SCREEN_WIDTH * 0.5, 25);
    
    _talkTime.frame = CGRectMake(CGRectGetMinX(_talkAuthor.frame), CGRectGetMaxY(_talkAuthor.frame) + 5, CGRectGetWidth(_talkAuthor.bounds), 20);
    
    _talkContent.frame = CGRectMake(CGRectGetMinX(_talkImageView.frame), CGRectGetMaxY(_talkImageView.frame), SCREEN_WIDTH - 20, contentHeight);
    
    _backView.frame = CGRectMake(0, CGRectGetMaxY(_talkContent.frame) + 10, SCREEN_WIDTH, 10);
    
    return CGRectGetMaxY(_backView.frame);
}


@end
