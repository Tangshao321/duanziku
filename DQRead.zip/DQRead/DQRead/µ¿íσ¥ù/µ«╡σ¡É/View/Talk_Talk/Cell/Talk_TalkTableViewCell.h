//
//  Talk_TalkTableViewCell.h
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Talk_TalkTableViewCell : UITableViewCell

@property (nonatomic,strong) UIImageView *talkImageView;/**< 段子图片 */
@property (nonatomic,strong) UILabel *talkAuthor;/**< 作者 */
@property (nonatomic,strong) UILabel *talkTime;/**< 添加时间 */
@property (nonatomic,strong) UILabel *talkContent;/**< 段子 */
@property (nonatomic,strong) UIView *backView;

- (CGFloat)setCellHeightWithContentHeight:(CGFloat)contentHeight;

@end
