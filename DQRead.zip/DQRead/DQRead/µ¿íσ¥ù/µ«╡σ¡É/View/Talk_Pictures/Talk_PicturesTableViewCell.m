//
//  Talk_PicturesTableViewCell.m
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "Talk_PicturesTableViewCell.h"

@implementation Talk_PicturesTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initUI];
    }
    return self;
}

- (void)initUI {
    _headImgView = [[UIImageView alloc]initWithFrame:DQAdaptionRectFromFrame(CGRectMake(20, 20, 100, 100))];
    //_headImgView.backgroundColor = [UIColor redColor];
    _headImgView.layer.cornerRadius = DQAdaption(50);
    _headImgView.layer.masksToBounds = YES;
    [self.contentView addSubview:_headImgView];
    
    _titleLabel = [[UILabel alloc]initWithFrame:DQAdaptionRectFromFrame(CGRectMake(150, 30, 300, 30))];
    _titleLabel.font = DQAFont(25);
    //_titleLabel.backgroundColor = [UIColor orangeColor];
    [self.contentView addSubview:_titleLabel];
    
    _timeLabel = [[UILabel alloc]initWithFrame:DQAdaptionRectFromFrame(CGRectMake(150, 80, 300, 30))];
    _timeLabel.font = DQAFont(20);
    //_titleLabel.backgroundColor = [UIColor orangeColor];
    [self.contentView addSubview:_timeLabel];
    
    _contentLabel = [[UILabel alloc]initWithFrame:DQAdaptionRectFromFrame(CGRectMake(50, 100, 650, 120))];
    _contentLabel.font = DQAFont(25);
    _contentLabel.numberOfLines = 0;
    //_contentLabel.backgroundColor = [UIColor greenColor];
    [self.contentView addSubview:_contentLabel];
    
    _contentImgView = [[UIImageView alloc]init];
    //_contentImgView.backgroundColor = [UIColor purpleColor];
    [self.contentView addSubview:_contentImgView];
}
//更新布局时调用,调用多次(不能添加子控件)
- (void)layoutSubviews {
    
}


@end
