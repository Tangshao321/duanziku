//
//  Talk_PicturesTableViewCell.h
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Talk_PicturesTableViewCell : UITableViewCell

@property (nonatomic,strong)UIImageView *headImgView;
@property (nonatomic,strong)UILabel *titleLabel;
@property (nonatomic,strong)UILabel *timeLabel;
@property (nonatomic,strong)UILabel *contentLabel;
@property (nonatomic,strong)UIImageView *contentImgView;


@end
