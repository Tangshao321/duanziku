//
//  talk_videoModel.m
//  123
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 TJX. All rights reserved.
//

#import "talk_videoModel.h"

@implementation talk_videoModel

+ (NSArray *)modelArrayFromJsonArray:(NSArray *)array{
    NSMutableArray *modelArray = [NSMutableArray array];
    for (NSDictionary *dict in array) {
        talk_videoModel *model = [[talk_videoModel alloc] init];
        [model setValuesForKeysWithDictionary:dict];
        [modelArray addObject:model];
    }
    return modelArray;
}


@end
