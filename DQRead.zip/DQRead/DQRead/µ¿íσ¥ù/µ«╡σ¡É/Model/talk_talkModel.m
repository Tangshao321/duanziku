//
//  talk_talkModel.m
//  123
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 TJX. All rights reserved.
//

#import "talk_talkModel.h"

@implementation talk_talkModel

+ (NSArray *)modelArrayFromJsonArray:(NSArray *)array{
    NSMutableArray *modelArray = [NSMutableArray array];
    for (NSDictionary *dict in array) {
        talk_talkModel *model = [[talk_talkModel alloc] init];
        [model setValuesForKeysWithDictionary:dict];
        [modelArray addObject:model];
    }
    return modelArray;
}


- (CGFloat)contentHeight{
    
    CGFloat content = [self.text heightForWidth:SCREEN_WIDTH - 20 andFont:DQAFont(25)];
    return content;
}



@end
