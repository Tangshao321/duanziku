//
//  talk_picturesModel.m
//  123
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 TJX. All rights reserved.
//

#import "talk_picturesModel.h"

@implementation talk_picturesModel

+ (NSArray *)modelArrayFromJsonArray:(NSArray *)array{
    NSMutableArray *modelArray = [NSMutableArray array];
    for (NSDictionary *dict in array) {
        talk_picturesModel *model = [[talk_picturesModel alloc] init];
        [model setValuesForKeysWithDictionary:dict];
        [modelArray addObject:model];
    }
    return modelArray;
}

@end
