//
//  talk_talkModel.h
//  123
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 TJX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface talk_talkModel : NSObject

@property (nonatomic,strong) NSString *videotime;
@property (nonatomic,strong) NSString *weixin_url;
@property (nonatomic,strong) NSString *id;
@property (nonatomic,strong) NSString *width;
@property (nonatomic,strong) NSString *type;
@property (nonatomic,strong) NSString *love;
@property (nonatomic,strong) NSString *voicelength;
@property (nonatomic,strong) NSString *voicetime;
@property (nonatomic,strong) NSString *profile_image;
@property (nonatomic,strong) NSString *text;
@property (nonatomic,strong) NSString *height;
@property (nonatomic,strong) NSString *hate;
@property (nonatomic,strong) NSString *voiceuri;
@property (nonatomic,strong) NSString *create_time;
@property (nonatomic,strong) NSString *name;

@property (nonatomic,assign) CGFloat contentHeight;/**< 文本内容高度 */

+ (NSArray *)modelArrayFromJsonArray:(NSArray *)array;

@end
