//
//  talk_voiceModel.m
//  123
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 TJX. All rights reserved.
//

#import "talk_voiceModel.h"

@implementation talk_voiceModel

+ (NSArray *)modelArrayFromJsonArray:(NSArray *)array{
    NSMutableArray *modelArray = [NSMutableArray array];
    for (NSDictionary *dict in array) {
        talk_voiceModel *model = [[talk_voiceModel alloc] init];
        [model setValuesForKeysWithDictionary:dict];
        [modelArray addObject:model];
    }
    return modelArray;
}

- (CGFloat)contentHeight{
    
    CGFloat content = [self.text heightForWidth:SCREEN_WIDTH * 0.7 andFont:DQAFont(15)];
    
    return content;
}

@end
