//
//  DQFeedbackViewController.m
//  DQRead
//
//  Created by rimi on 2016/12/1.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQFeedbackViewController.h"

@interface DQFeedbackViewController ()
@property (nonatomic,strong)UITextView *feedbackTextView;
@end

@implementation DQFeedbackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI{
    self.view.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:244/255.0 alpha:1.0];
    self.title = @"意见反馈";
    _feedbackTextView = [[UITextView alloc] initWithFrame:CGRectMake(10, 20, KWIDTH - 20, KHEIGHT * 0.35)];
    _feedbackTextView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_feedbackTextView];
    
    UIButton *loginButton = [UIButton buttonWithType:UIButtonTypeSystem];
    loginButton.frame = CGRectMake(20, CGRectGetMaxY(_feedbackTextView.frame) + 50, KWIDTH - 40, 50);
    loginButton.backgroundColor =[UIColor colorWithRed:50/255.0 green:170/255.0 blue:101/255.0 alpha:1.0];
    [loginButton setTitle:@"提交" forState:UIControlStateNormal];
    loginButton.titleLabel.font = [UIFont systemFontOfSize:21];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginButton addTarget:self action:@selector(buttonClickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
}
#pragma mark - Button click event
- (void)buttonClickEvent:(UIButton *)sender{
    if (_feedbackTextView.text.length == 0 ) {
        [AlertViewController AlertTitle:@"提交失败" Message:@"请输入您的宝贵意见!" ViewController:self];
    }else{
        BmobObject *feedbackObj = [[BmobObject alloc] initWithClassName:@"Feedback"];
        //反馈内容
        [feedbackObj setObject:_feedbackTextView.text forKey:@"content"];
        //保存反馈信息到Bmob云数据库中
        [feedbackObj saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {if (isSuccessful) {
            [AlertViewController AlertTitle:@"温馨提示" Message:@"意见反馈成功" ViewController:self];
        }else{
            [AlertViewController AlertTitle:@"提交失败" Message:@"请输入您的宝贵意见!" ViewController:self];
        }
            
       }];
    }
}

#pragma mark - 回收键盘
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
@end
