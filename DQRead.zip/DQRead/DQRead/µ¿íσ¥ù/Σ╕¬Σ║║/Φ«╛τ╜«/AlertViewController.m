//
//  AlertViewController.m
//  绵阳师范
//
//  Created by rimi on 16/10/20.
//  Copyright © 2016年 贺丹. All rights reserved.
//

#import "AlertViewController.h"

@interface AlertViewController ()

@end

@implementation AlertViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}

//中部
+ (void)AlertTitle:(NSString *)title Message:(NSString *)message ActionTitle:(NSString *)actionTitle ViewController:(UIViewController *)viewController {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *alertAction = [UIAlertAction actionWithTitle:actionTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        nil;
    }];
    [alert addAction:alertAction];
    [viewController presentViewController:alert animated:YES completion:nil];
}

//几秒后自动消失
+ (void)AlertTitle:(NSString *)title Message:(NSString *)message ViewController:(UIViewController *)viewController {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    [viewController presentViewController:alert animated:YES completion:nil];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //2秒消息弹出框
        [alert dismissViewControllerAnimated:YES completion:nil];
        
    });
}
//有block的弹出框(上传头像)
+ (void)AlertTitle:(NSString *)title Message:(NSString *)message ActionTitle:(NSString *)actionTitle ViewController:(UIViewController *)viewController preferredStyle:(UIAlertControllerStyle)style action:(addAction)alertAction {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:style];
    if (alertAction) {
        alertAction(alert);
    }else{
        UIAlertAction *alertAc = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            nil;
        }];
        [alert addAction:alertAc];
    }
    [viewController presentViewController:alert animated:YES completion:nil];
}
//获取当前视图控制器
+ (UIViewController *)keyViewContrller{
    
    UIViewController * vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (vc.presentedViewController) {
        vc = vc.presentedViewController;
    }
    return vc;
}

//闹钟通知
+ (void)AlertTitle:(NSString *)title Message:(NSString *)message ActionTitle:(NSString *)actionTitle  NSDictionary:(NSDictionary *)dic{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *determine = [UIAlertAction actionWithTitle:actionTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //发送通知(点击详细信息)
        [[NSNotificationCenter defaultCenter]postNotificationName:@"notice" object:nil userInfo:dic];
        //删除数据
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:[NSString stringWithFormat:@"%@",dic[[[dic allKeys]firstObject]][@"noticeId"]]];
    }];
    [alert addAction:determine];
    [[self keyViewContrller] presentViewController:alert animated:YES completion:nil];
}




@end
