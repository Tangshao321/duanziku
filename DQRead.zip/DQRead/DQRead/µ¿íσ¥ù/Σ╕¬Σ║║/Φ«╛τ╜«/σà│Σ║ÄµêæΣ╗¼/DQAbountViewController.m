//
//  DQAbountViewController.m
//  DQRead
//
//  Created by rimi on 2016/12/2.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQAbountViewController.h"

@interface DQAbountViewController ()

@property (nonatomic,strong) NSString *content;
@property (nonatomic,strong) UIWebView *webView;

@end

@implementation DQAbountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"关于我们";
    _content = @"哈哈哈哈哈哈哈正在ing";
    _webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, KWIDTH, KHEIGHT)];
    [_webView loadHTMLString:_content baseURL:nil];
    [self.view addSubview:_webView];

}

@end
