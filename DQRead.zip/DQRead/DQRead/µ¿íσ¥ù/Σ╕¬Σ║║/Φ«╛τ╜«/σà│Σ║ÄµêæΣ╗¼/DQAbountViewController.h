//
//  DQAbountViewController.h
//  DQRead
//
//  Created by rimi on 2016/12/2.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQBaseViewController.h"

@interface DQAbountViewController : DQBaseViewController

@end
