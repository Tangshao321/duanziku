//
//  AlertViewController.h
//  绵阳师范
//
//  Created by rimi on 16/10/20.
//  Copyright © 2016年 贺丹. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^addAction)(UIAlertController *alert);

@interface AlertViewController : UIViewController

//几秒后消失
+ (void)AlertTitle:(NSString *)title Message:(NSString *)message ViewController:(UIViewController *)viewController;
//中部
+ (void)AlertTitle:(NSString *)title Message:(NSString *)message ActionTitle:(NSString *)actionTitle ViewController:(UIViewController *)viewController ;
//下面
+ (void)AlertTitle:(NSString *)title Message:(NSString *)message ActionTitle:(NSString *)actionTitle ViewController:(UIViewController *)viewController preferredStyle:(UIAlertControllerStyle)style action:(addAction)alertAction;
//闹钟通知
+ (void)AlertTitle:(NSString *)title Message:(NSString *)message ActionTitle:(NSString *)actionTitle  NSDictionary:(NSDictionary *)dic;
//获取当前控制器
+ (UIViewController *)keyViewContrller;


@end
