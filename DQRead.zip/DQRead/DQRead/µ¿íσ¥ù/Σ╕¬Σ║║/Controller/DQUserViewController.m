//
//  DQUserViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQUserViewController.h"
#import "DQUserTableViewCell.h"
#import "DQLoginViewController.h"
#import "DQFeedbackViewController.h"
#import "DQAbountViewController.h"
@interface DQUserViewController ()<UITableViewDataSource,UITableViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>
/**< 名字 */
@property (nonatomic,strong) UILabel *nameLabel;
/**< 头像 */
@property (nonatomic,strong)  UIImageView *headImage;
@property (nonatomic,strong) UIImageView *backgroundImage;
/**< tableView */
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *pushImageArr;
@property (nonatomic, strong) NSArray *pushTextArr;
@property (nonatomic, strong) NSArray *otherImageArr;
@property (nonatomic, strong) NSArray *otherTextArr;
@property (nonatomic, strong) NSDictionary *dict;
//  判断是否登录
@property (nonatomic,assign) BOOL isLogin;
/**< 表头 */
@property (nonatomic,strong) UIView *tableHeader;


@end

@implementation DQUserViewController
- (instancetype)init{
    self= [super init];
    if (self )
    {
        //  注册通知登录时改变头像
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateHeadImgToNotifcation:) name:@"updateHeadImg" object:nil];
        
    }
    
    return self;
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    
//    _dict = [[NSUserDefaults standardUserDefaults] objectForKey:@"info"];
//    if ([_dict[@"ifLogin"] isEqualToString:@"YES"]) {
//        _nameLabel.text = _dict[@"accountL"];
//    }else{
//        _nameLabel.text = @"点击登录";
//    }
//    [TjxCustomView configImageInObject:_headImage];
    
    _isLogin = [UserInfo sharedUserInfo].objectId.length > 0;
    if (_isLogin)
    {
        _nameLabel.text = [UserInfo sharedUserInfo].userName;
    }else{
        _nameLabel.text = @"点击登录";
    }
    [TjxCustomView configImageInObject:_headImage];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1];
    [self initUI];
}
- (void)initUI{
    /**< tableview表头 */
    _tableHeader = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KWIDTH, KWIDTH * 0.33 + 50)];
    _tableHeader.backgroundColor = [UIColor whiteColor];
    //  添加表头
    self.tableView.tableHeaderView = _tableHeader;
    //  表格视图
    [self.view addSubview:self.tableView];
    
    UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, KWIDTH, KWIDTH * 0.33 + 50)];
    image.image = [UIImage imageNamed:@"个人-背景.jpg"];
    [self.tableHeader addSubview:image];
    
    //头像
    _headImage = [[UIImageView alloc] initWithFrame:CGRectMake(KWIDTH * 0.38,20, KWIDTH * 0.23, KWIDTH * 0.23)];
    _headImage.layer.cornerRadius = KWIDTH * 0.23/2;
    
    _headImage.layer.masksToBounds = YES;
    _headImage.userInteractionEnabled = YES;
    [_headImage setImage:[UIImage imageNamed:@"默认头像"]];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapAction:)];
    [_headImage addGestureRecognizer:tap];
    [self.tableHeader addSubview:_headImage];
    
    _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,CGRectGetMaxY(_headImage.frame) + 10, KWIDTH, 30)];
    _nameLabel.textColor = [UIColor whiteColor];
    _nameLabel.textAlignment = NSTextAlignmentCenter;
    [self.tableHeader addSubview:_nameLabel];
    
    _otherImageArr = @[[UIImage imageNamed:@"设置-推送"],[UIImage imageNamed:@"设置-叫上闺蜜图"],[UIImage imageNamed:@"设置-意见反馈"],[UIImage imageNamed:@"设置-评价"],[UIImage imageNamed:@"设置-今日封面"],[UIImage imageNamed:@"设置-关于"],[UIImage imageNamed:@"设置-清除缓存"]];
    _otherTextArr = @[@"推送设置",@"叫上朋友一起",@"意见反馈",@"去App Store,给个评价吧",@"版本更新",@"关于我们",@"清除缓存"];
    
}
#pragma mark - 点击事件
- (void)logOutBUttonPressed:(UIButton *)sender {
    if (_isLogin) {
 //       NSMutableDictionary *dic = [NSMutableDictionary dictionary];
//        [dic setValue:@"NO" forKey:@"ifLogin"];
//        [dic setValue:@"" forKey:@"accountL"];
//        [dic setValue:@"" forKey:@"objectId"];
//        [dic setValue:@"" forKey:@"headUrl"];
        
  //      [[NSUserDefaults standardUserDefaults] setObject:dic forKey:@"info"];
        //  立即保存数据
        [[NSUserDefaults standardUserDefaults]synchronize];
        _nameLabel.text = @"点击登录";
        [TjxCustomView configImageInObject:_headImage];
        // 返回头部
        [self.tableView scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
        [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"退出登录" disMissTime:1.0];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:[UserInfo sharedUserInfo].userDefaultsKey];
        [[UserInfo sharedUserInfo] clearAllInfo];
        
        //  修改头像
        [self.headImage setImage:[TjxCustomView customImage]];
    }
    else{
        [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"请先登录" disMissTime:1.0];
    }
    
}
#pragma mark -Tap click event
- (void)singleTapAction:(UIGestureRecognizer *)tap{
    if ([UserInfo sharedUserInfo].objectId.length>0) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"选择照片" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        [alert addAction:[UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            // 1.判断相册是否可以打开
            if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) return;
            
            UIImagePickerController *ipc = [[UIImagePickerController alloc] init];
            ipc.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            ipc.allowsEditing = YES;
            ipc.delegate = self;
            [self presentViewController:ipc animated:YES completion:nil];
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
    else{
        [self presentViewController:[DQLoginViewController new]  animated:YES completion:nil];
    }
}

//  响应通知改变头像
- (void)updateHeadImgToNotifcation:(NSNotification *)info{
    [self.headImage sd_setImageWithURL:info.userInfo[@"headUrl"]];
}

- (void)dealloc{
  //  删除通知
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark - UITableView协议


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 7;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
     NSString *identifier = [NSString stringWithFormat:@"cell%ld",indexPath.row];
    DQUserTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[DQUserTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    else
    {
        //删除cell的所有子视图
        while ([cell.contentView.subviews lastObject] != nil)
        {
            [(UIView*)[cell.contentView.subviews lastObject] removeFromSuperview];
        }
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle =UITableViewCellSelectionStyleNone;
    cell.settingImage.image = _otherImageArr[indexPath.row];
    cell.settingLabel.text = _otherTextArr[indexPath.row];
    if (indexPath.row == 0) {
        cell.pushLabel.hidden = NO;
        cell.pushLabel.text = @"你可能错过最好玩的内容、活动，点击去设置允许通知";
    }else if (indexPath.row == 4){
        UILabel *label = [[UILabel alloc] initWithFrame:DQAdaptionRect(kBaseWidth * 0.70, 33, 150, 50)];
        label.font = DQAFont(23);
        label.text  = @"当前版本1.3.0";
        [cell addSubview:label];
    }else if (indexPath.row == 6){
        UILabel *redLabel = [[UILabel alloc] initWithFrame:DQAdaptionRect(kBaseWidth * 0.75, 33, 120, 50)];
        redLabel.tag = 500;
        redLabel.font = DQAFont(32);
        SDImageCache * imageChache = [SDImageCache sharedImageCache];
        NSUInteger cacheSize = [imageChache getSize]; // 单位为：byte
        NSString * msg = [NSString stringWithFormat:@"%.1fMB",cacheSize / 1024 / 1024.0];
        redLabel.text = msg;
        [cell addSubview:redLabel];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        NSURL * url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        if([[UIApplication sharedApplication] canOpenURL:url]) {
            NSURL*url =[NSURL URLWithString:UIApplicationOpenSettingsURLString];
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
        }
    }else if (indexPath.row == 2){
        DQFeedbackViewController *vc = [[DQFeedbackViewController alloc] init] ;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else if ( indexPath.row == 3){
        NSString *appID = @"564457517";
        NSString *str = [NSString stringWithFormat:
                         @"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=%@",appID];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str] options:@{} completionHandler:nil];
    }else if (indexPath.row == 4){
        [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"没有可用的版本更新" disMissTime:1.0];
    }else if (indexPath.row == 5){
        DQAbountViewController *vc = [[DQAbountViewController alloc] init] ;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else if(indexPath.row == 6){
        SDImageCache * imageChache = [SDImageCache sharedImageCache];
        // 清除缓存
        [imageChache clearMemory];
        [imageChache clearDisk];
        UILabel *myLabel = (UILabel *)[self.view viewWithTag:500];
        //            NSLog(@"first %@",myLabel.text);
        NSUInteger cacheSize = [imageChache getSize]; // 单位为：byte
        NSString * msg = [NSString stringWithFormat:@"%.1fMB",cacheSize / 1024 / 1024.0];
        //            NSLog(@"second %@",msg);
        
        myLabel.text = msg;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return DQAdaption(310);
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
   
        UIView *footerView = [[UIView alloc] init];
        footerView.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:244/255.0 alpha:1.0];
        
        UIButton *logOutButton = [UIButton buttonWithType:UIButtonTypeSystem];
        logOutButton.frame = DQAdaptionRect(0, 50, kBaseWidth, 67 *2);
        logOutButton.backgroundColor = [UIColor whiteColor];
        [logOutButton setTitle:@"退出登录" forState:UIControlStateNormal];
        [logOutButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [logOutButton addTarget:self action:@selector(logOutBUttonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [footerView addSubview:logOutButton];
        self.tableView.tableFooterView = footerView;
        return footerView;
}

//返回程序
#pragma mark - image picker
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
//将数据请求在bmob云端
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    _headImage.image = info[UIImagePickerControllerOriginalImage];
    
    NSData *data = UIImagePNGRepresentation(info[UIImagePickerControllerEditedImage]);
    BmobFile *file = [[BmobFile alloc] initWithFileName:@"headImage.jpg" withFileData:data];
    [file saveInBackground:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            
            BmobObject *userInfo = [BmobObject objectWithoutDataWithClassName:@"userInfo" objectId:[UserInfo sharedUserInfo].objectId];
            [userInfo setObject:file.url forKey:@"headUrl"];
            [userInfo updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    NSLog(@"更新数据成功");
                    [[NSUserDefaults standardUserDefaults] setObject:file.url forKey:[UserInfo sharedUserInfo].keyHeadUrl];
                    // 保存
                    [TjxCustomView saveHeadImageData:data];
                }
            }];
        }
        else{
            NSLog(@"%@",error);
        }
    }];
    
}

#pragma mark - getter
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0,0, KWIDTH ,KHEIGHT - 115) style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = DQAdaption(120);
    }
    return _tableView;
}
@end
