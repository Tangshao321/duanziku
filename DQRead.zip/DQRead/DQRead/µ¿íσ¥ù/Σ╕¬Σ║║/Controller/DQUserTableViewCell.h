//
//  TkMeTableViewCell.h
//  Signsystem
//
//  Created by rimi on 16/10/21.
//  Copyright © 2016年 QQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DQUserTableViewCell : UITableViewCell
@property (nonatomic, strong) UIImageView *settingImage;
@property (nonatomic, strong) UILabel *settingLabel;
@property (nonatomic, strong) UILabel *pushLabel;
@end
