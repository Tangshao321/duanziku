//
//  TkMeTableViewCell.m
//  Signsystem
//
//  Created by rimi on 16/10/21.
//  Copyright © 2016年 QQ. All rights reserved.
//

#import "DQUserTableViewCell.h"

@implementation DQUserTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initUserInterface];
    }
    return self;
}

- (void)initUserInterface {
    _settingImage = [[UIImageView alloc] initWithFrame:DQAdaptionRect(60, 30, 40, 40)];
    [self addSubview:_settingImage];
    
    _settingLabel = [[UILabel alloc] initWithFrame:DQAdaptionRect(130, 30, kBaseWidth * 0.65, 42)];
    _settingLabel.textColor = [UIColor grayColor];
    _settingLabel.font = [UIFont systemFontOfSize:13];
    [self addSubview:_settingLabel];
    
    _pushLabel = [[UILabel alloc] initWithFrame:DQAdaptionRect(130, 70, kBaseWidth * 0.80, 40)];
    _pushLabel.textColor = [UIColor colorWithRed:1.0 green:78/255.0 blue:174/255.0 alpha:1.0];
    _pushLabel.font = [UIFont systemFontOfSize:12];
    [self addSubview:_pushLabel];
    
}
@end
