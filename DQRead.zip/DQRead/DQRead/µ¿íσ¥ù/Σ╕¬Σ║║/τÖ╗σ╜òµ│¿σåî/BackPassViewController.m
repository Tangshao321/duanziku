//
//  BackPassViewController.m
//  DQRead
//
//  Created by rimi on 2016/12/7.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "BackPassViewController.h"

@interface BackPassViewController ()
@property (nonatomic ,strong) UITextField *account;
@property (nonatomic ,strong) UITextField *email;
@property (nonatomic ,strong) UIButton *retrievePass;
@end

@implementation BackPassViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeBackgroundImage];
    [self initUI];
}
- (void)initializeBackgroundImage{
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"login background.jpg"]];
    [self iOS8BlurImageImplement];
    
}
// iOS8 使用系统自带的处理方式
- (void)iOS8BlurImageImplement {
    UIBlurEffect *beffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    UIVisualEffectView *view = [[UIVisualEffectView alloc] initWithEffect:beffect];
    view.frame = self.view.bounds;
    [self.view addSubview:view];
}
- (void)initUI{
    
    UIView *bView = [[UIView alloc] initWithFrame:self.view.bounds];
    bView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
    [self.view addSubview:bView];
    //返回
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeSystem];
    backButton.frame = CGRectMake(-50, -40, 150, 150);
    [backButton setTitle:@"返回" forState:UIControlStateNormal];
    [backButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    backButton.tag = 0;
    [bView addSubview:backButton];
    
    //账号
    UILabel *aLabel = [[UILabel alloc] init];
    aLabel.frame = CGRectMake(70, MAX_Y(backButton.frame) + 30, 50, 50);
    aLabel.text = @"账号";
    aLabel.textColor = [UIColor whiteColor];
    aLabel.font = DQAFont(37);
    [bView addSubview:aLabel];
    _account = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(aLabel.frame), CGRectGetMaxY(backButton.frame) + 30, KWIDTH * 0.6, 50)];
    _account.placeholder = @"请输入账号";
    _account.borderStyle = UITextBorderStyleNone;
    _account.clearButtonMode = UITextFieldViewModeWhileEditing;/**< 按钮清除 */
    _account.autocorrectionType = UITextAutocorrectionTypeNo;/**< 取消自动修改 */
    _account.autocapitalizationType = UITextAutocapitalizationTypeNone;/**< 取消首字母大写 */
    _account.textColor = [UIColor whiteColor];
    [bView addSubview:_account];
    UILabel *accountLabel = [[UILabel alloc] initWithFrame:CGRectMake(67, CGRectGetMaxY(aLabel.frame) - 10, KWIDTH * 0.6 + 50, 1)];
    accountLabel.backgroundColor = ThemeColor;
    [bView addSubview:accountLabel];
    
    //邮箱
    UILabel *eLabel = [[UILabel alloc] init];
    eLabel.frame = CGRectMake(70, MAX_Y(accountLabel.frame) + 30, 50, 50);
    eLabel.text = @"邮箱";
    eLabel.textColor = [UIColor whiteColor];
    aLabel.font = DQAFont(37);
    [bView addSubview:eLabel];
    _email = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(eLabel.frame), CGRectGetMaxY(accountLabel.frame) + 30, KWIDTH * 0.6, 50)];
    _email.placeholder = @"请输入邮箱";
    _email.borderStyle = UITextBorderStyleNone;
    _email.clearButtonMode = UITextFieldViewModeWhileEditing;/**< 按钮清除 */
    _email.autocorrectionType = UITextAutocorrectionTypeNo;/**< 取消自动修改 */
    _email.autocapitalizationType = UITextAutocapitalizationTypeNone;/**< 取消首字母大写 */
    _email.textColor = [UIColor whiteColor];
    [bView addSubview:_email];
    UILabel *emailLabel = [[UILabel alloc] initWithFrame:CGRectMake(67, CGRectGetMaxY(eLabel.frame) - 10, KWIDTH * 0.6 + 50, 1)];
    emailLabel.backgroundColor = ThemeColor;
    [bView addSubview:emailLabel];
    
    //修改
    UIButton *loginButton = [UIButton buttonWithType:UIButtonTypeSystem];
    loginButton.frame = CGRectMake(KWIDTH/3, MAX_Y(emailLabel.frame) + 50, 150, 40);
    [loginButton setTitle:@"确认修改" forState:UIControlStateNormal];
    loginButton.backgroundColor = [UIColor colorWithRed:50/255.0 green:170/255.0 blue:101/255.0 alpha:1.0] ;
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginButton addTarget:self action:@selector(backPass) forControlEvents:UIControlEventTouchUpInside];
    loginButton.titleLabel.font = DQAFont(37);
    loginButton.tag = 1;
    loginButton.layer.masksToBounds = YES;
    loginButton.layer.cornerRadius = 10;
    [bView addSubview:loginButton];
}
//邮箱地址的正则表达式
- (BOOL)isValidateEmail:(NSString *)email{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
- (void)backPass
{
    BmobUser *bUser = [BmobUser currentUser];
    
    if (self.account.text.length == 0 || self.email.text.length == 0) {
        [AlertViewController AlertTitle:@"温馨提示" Message:@"请填写完整!" ViewController:self];
    }else if ([self isValidateEmail:_email.text] == NO){
        [AlertViewController AlertTitle:@"提示" Message:@"请输入正确的邮箱地址" ActionTitle:@"确定" ViewController:self];
    }else if ([bUser.username isEqualToString:self.account.text]) {
        //进行操作
        [BmobUser requestPasswordResetInBackgroundWithEmail:self.email.text];
        [BmobUser requestPasswordResetInBackgroundWithEmail:bUser.email];
        UIAlertController *alertcontroller = [UIAlertController alertControllerWithTitle:@"提示" message:@"请进入邮箱验证,点击确定返回登录页" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *alert = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self back];
        }];
        [self presentViewController:alertcontroller animated:YES completion:^{
            
        }];
        [alertcontroller addAction:alert];
    }else if(bUser.username != self.account.text){
        UIAlertController *alertcontroller = [UIAlertController alertControllerWithTitle:@"提示" message:@"账号或者邮箱不正确" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *alert = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [self presentViewController:alertcontroller animated:YES completion:^{
            
        }];
        [alertcontroller addAction:alert];
    }
    
}
- (void)back{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

@end
