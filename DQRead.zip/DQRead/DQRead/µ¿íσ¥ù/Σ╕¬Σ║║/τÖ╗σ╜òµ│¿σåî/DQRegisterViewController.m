//
//  DQLogonViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQRegisterViewController.h"



@interface DQRegisterViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (nonatomic,strong) UITextField *account;/**< 账号 */
@property (nonatomic,strong) UITextField *password;/**< 密码 */
@property (nonatomic,strong) UITextField *email;/**< 邮箱 */
@property (nonatomic,strong) UITextField *spassword;/**< 确定密码 */
@property (nonatomic,strong) NSString *ac;
@property (nonatomic,strong) NSString *pwd;

@end

@implementation DQRegisterViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeBackgroundImage];
    [self initUI];
}
- (void)initializeBackgroundImage{
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"login background.jpg"]];
    [self iOS8BlurImageImplement];
    
}
// iOS8 使用系统自带的处理方式
- (void)iOS8BlurImageImplement {
    UIBlurEffect *beffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    UIVisualEffectView *view = [[UIVisualEffectView alloc] initWithEffect:beffect];
    view.frame = self.view.bounds;
    [self.view addSubview:view];
}
- (void)initUI{
    
    UIView *bView = [[UIView alloc] initWithFrame:self.view.bounds];
    bView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
    [self.view addSubview:bView];
    //返回
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeSystem];
    backButton.frame = CGRectMake(-50, -40, 150, 150);
    [backButton setTitle:@"返回" forState:UIControlStateNormal];
    [backButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(respondstoBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    backButton.tag = 0;
    [bView addSubview:backButton];
    
    //注册
    UILabel *loginLabel = [[UILabel alloc] init];
    loginLabel.frame = CGRectMake(KWIDTH/3 + 43, -40, 150, 150);
    loginLabel.text = @"注册";
    loginLabel.textColor = [UIColor whiteColor];
    loginLabel.font = DQAFont(37);
    [bView addSubview:loginLabel];
    
    
    //账号
    UILabel *aLabel = [[UILabel alloc] init];
    aLabel.frame = CGRectMake(70, MAX_Y(backButton.frame) + 30, 50, 50);
    aLabel.text = @"账号";
    aLabel.textColor = [UIColor whiteColor];
    aLabel.font = DQAFont(37);
    [bView addSubview:aLabel];
    _account = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(aLabel.frame), CGRectGetMaxY(backButton.frame) + 30, KWIDTH * 0.6, 50)];
    _account.placeholder = @"请输入账号";
    _account.borderStyle = UITextBorderStyleNone;
    _account.clearButtonMode = UITextFieldViewModeWhileEditing;/**< 按钮清除 */
    _account.autocorrectionType = UITextAutocorrectionTypeNo;/**< 取消自动修改 */
    _account.autocapitalizationType = UITextAutocapitalizationTypeNone;/**< 取消首字母大写 */
    _account.textColor = [UIColor whiteColor];
    [bView addSubview:_account];
    UILabel *accountLabel = [[UILabel alloc] initWithFrame:CGRectMake(67, CGRectGetMaxY(aLabel.frame) - 10, KWIDTH * 0.6 + 50, 1)];
    accountLabel.backgroundColor = ThemeColor;
    [bView addSubview:accountLabel];
    
    
    
    //邮箱
    UILabel *eLabel = [[UILabel alloc] init];
    eLabel.frame = CGRectMake(70, MAX_Y(accountLabel.frame) + 30, 50, 50);
    eLabel.text = @"邮箱";
    eLabel.textColor = [UIColor whiteColor];
    aLabel.font = DQAFont(37);
    [bView addSubview:eLabel];
    _email = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(eLabel.frame), CGRectGetMaxY(accountLabel.frame) + 30, KWIDTH * 0.6, 50)];
    _email.placeholder = @"请输入邮箱";
    _email.borderStyle = UITextBorderStyleNone;
    _email.clearButtonMode = UITextFieldViewModeWhileEditing;/**< 按钮清除 */
    _email.autocorrectionType = UITextAutocorrectionTypeNo;/**< 取消自动修改 */
    _email.autocapitalizationType = UITextAutocapitalizationTypeNone;/**< 取消首字母大写 */
    _email.textColor = [UIColor whiteColor];
    [bView addSubview:_email];
    UILabel *emailLabel = [[UILabel alloc] initWithFrame:CGRectMake(67, CGRectGetMaxY(eLabel.frame) - 10, KWIDTH * 0.6 + 50, 1)];
    emailLabel.backgroundColor = ThemeColor;
    [bView addSubview:emailLabel];

    
    
    //密码
    UILabel *pLabel = [[UILabel alloc] init];
    pLabel.frame = CGRectMake(70, MAX_Y(emailLabel.frame) + 30, 50, 50);
    pLabel.text = @"密码";
    pLabel.textColor = [UIColor whiteColor];
    pLabel.font = DQAFont(37);
    [bView addSubview:pLabel];
    _password = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(pLabel.frame), CGRectGetMaxY(emailLabel.frame) + 30, KWIDTH * 0.6, 50)];
    _password.placeholder = @"请输入密码";
    _password.borderStyle = UITextBorderStyleNone;
    _password.clearButtonMode = UITextFieldViewModeWhileEditing;/**< 按钮清除 */
    _password.autocorrectionType = UITextAutocorrectionTypeNo;/**< 取消自动修改 */
    _password.autocapitalizationType = UITextAutocapitalizationTypeNone;/**< 取消首字母大写 */
    _password.secureTextEntry = YES;
    _password.textColor = [UIColor whiteColor];
    [bView addSubview:_password];
    UILabel *pwdLabel = [[UILabel alloc] initWithFrame:CGRectMake(67, CGRectGetMaxY(pLabel.frame) - 10, KWIDTH * 0.6 + 50, 1)];
    pwdLabel.backgroundColor = ThemeColor;
    [bView addSubview:pwdLabel];
    
    //确定密码
    UILabel *spLabel = [[UILabel alloc] init];
    spLabel.frame = CGRectMake(70, MAX_Y(pwdLabel.frame) + 30, 100 , 50);
    spLabel.text = @"确定密码";
    spLabel.textColor = [UIColor whiteColor];
    spLabel.font = DQAFont(37);
    [bView addSubview:spLabel];
    _spassword = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(spLabel
.frame), CGRectGetMaxY(pwdLabel.frame) + 30, KWIDTH * 0.5, 50)];
    _spassword.placeholder = @"请输入密码";
    _spassword.borderStyle = UITextBorderStyleNone;
    _spassword.clearButtonMode = UITextFieldViewModeWhileEditing;/**< 按钮清除 */
    _spassword.autocorrectionType = UITextAutocorrectionTypeNo;/**< 取消自动修改 */
    _spassword.autocapitalizationType = UITextAutocapitalizationTypeNone;/**< 取消首字母大写 */
    _spassword.secureTextEntry = YES;
    _spassword.textColor = [UIColor whiteColor];
    [bView addSubview:_spassword];
    UILabel *spwdLabel = [[UILabel alloc] initWithFrame:CGRectMake(67, CGRectGetMaxY(spLabel.frame) - 10, KWIDTH * 0.6 + 50, 1)];
    spwdLabel.backgroundColor = ThemeColor;
    [bView addSubview:spwdLabel];
    
    
    //注册
    UIButton *loginButton = [UIButton buttonWithType:UIButtonTypeSystem];
    loginButton.frame = CGRectMake(KWIDTH/3, MAX_Y(spwdLabel.frame) + 50, 150, 40);
    [loginButton setTitle:@"注  册" forState:UIControlStateNormal];
    loginButton.backgroundColor = [UIColor colorWithRed:50/255.0 green:170/255.0 blue:101/255.0 alpha:1.0] ;
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginButton addTarget:self action:@selector(respondstoBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    loginButton.titleLabel.font = DQAFont(37);
    loginButton.tag = 1;
    loginButton.layer.masksToBounds = YES;
    loginButton.layer.cornerRadius = 10;
    [bView addSubview:loginButton];
    
}
#pragma mark - respondstoBackBtn 返回事件
-(void)respondstoBackBtn:(UIButton *)sender{
    switch (sender.tag) {
        case 0:
            [self back];
            break;
        case 1:
            [self registerResponder];
        break;
        default:
            break;
    }
    
}
// 返回
- (void)back{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

// 登录按钮点击事件
- (void)registerResponder{
    if (_account.text.length == 0 || _password.text.length == 0 || _password.text.length == 0) {
        [AlertViewController AlertTitle:@"温馨提示" Message:@"请填写完整!" ViewController:self];
        
    }else if (_password.text != _spassword.text){
        [AlertViewController AlertTitle:@"温馨提示" Message:@"两次输入的密码不同!" ViewController:self];
    }
    else
    {
        
        BmobQuery *bquery = [BmobQuery queryWithClassName:@"userInfo"];
        NSArray *array = @[@{@"username" : self.account.text},@{@"email" : self.email.text}];
        [bquery addTheConstraintByAndOperationWithArray:array];
        [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (array.count == 0) {
                BmobObject *userInfo = [BmobObject objectWithClassName:@"userInfo"];
                [userInfo setObject:self.account.text forKey:@"username"];
                [userInfo setObject:self.password.text forKey:@"password"];
                [userInfo setObject:@"" forKey:@"headUrl"];
                [userInfo saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                    [AlertViewController AlertTitle:@"提示" Message:@"注册成功，2秒后进入登录页" ViewController:self];
                    [self performSelector:@selector(back) withObject:self afterDelay:2];
                }];
            }
            else{
                [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"注册失败！可能有重复用户,请重试" disMissTime:2.0];
                _password.text = @"";
                _spassword.text = @"";
                [_account resignFirstResponder];
            }
        }];
        
    }
}
#pragma mark - 回收键盘
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}



@end
