//
//  DQLoginViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQLoginViewController.h"
#import "DQRegisterViewController.h"
#import "BackPassViewController.h"
#import "UserInfoNetWorking.h"

@interface DQLoginViewController ()
@property (nonatomic,strong) UITextField *account;/**< 账号 */
@property (nonatomic,strong) UITextField *password;/**< 密码 */
@property (nonatomic,strong) UIImageView *imageView;
@property (nonatomic,strong) NSString *ac;
@property (nonatomic,strong) NSString *pwd;

@end

@implementation DQLoginViewController
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    }
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeBackgroundImage];
    [self initUI];
}
- (void)initializeBackgroundImage{
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"login background.jpg"]];
     [self iOS8BlurImageImplement];
    
}
// iOS8 使用系统自带的处理方式
- (void)iOS8BlurImageImplement {
    UIBlurEffect *beffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    UIVisualEffectView *view = [[UIVisualEffectView alloc] initWithEffect:beffect];
    view.frame = self.view.bounds;
    [self.view addSubview:view];
}
- (void)initUI{
    UIView *bView = [[UIView alloc] initWithFrame:self.view.bounds];
    bView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
    [self.view addSubview:bView];
    //返回
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeSystem];
    backButton.frame = CGRectMake(-50, -40, 150, 150);
    [backButton setTitle:@"返回" forState:UIControlStateNormal];
    [backButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(respondstoBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    backButton.tag = 0;
    [bView addSubview:backButton];

    //注册
    UIButton *logonButton = [UIButton buttonWithType:UIButtonTypeSystem];
    logonButton.frame = CGRectMake(KWIDTH - 100, -40, 150, 150);
    [logonButton setTitle:@"注册" forState:UIControlStateNormal];
    [logonButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [logonButton addTarget:self action:@selector(respondstoBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    logonButton.tag = 1;
    [bView addSubview:logonButton];
    
    //登录
    UILabel *loginLabel = [[UILabel alloc] init];
    loginLabel.frame = CGRectMake(KWIDTH/3 + 43, -40, 150, 150);
    loginLabel.text = @"登陆";
    loginLabel.textColor = [UIColor whiteColor];
    loginLabel.font = DQAFont(37);
    [bView addSubview:loginLabel];
    
    //头像
    _imageView = [[UIImageView alloc] initWithFrame: CGRectMake(KWIDTH/3 , MAX_Y(loginLabel.frame), 130, 130)];
    _imageView.layer.cornerRadius = 65;
    _imageView.layer.masksToBounds = YES;
    [self.imageView setImage:[UIImage imageNamed:@"默认头像"]];
    [bView addSubview:_imageView];
   
    //账号
    UILabel *aLabel = [[UILabel alloc] init];
    aLabel.frame = CGRectMake(70, MAX_Y(_imageView.frame) + 30, 50, 50);
    aLabel.text = @"账号";
    aLabel.textColor = [UIColor whiteColor];
    aLabel.font = DQAFont(37);
    [bView addSubview:aLabel];
    _account = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(aLabel.frame), CGRectGetMaxY(_imageView.frame) + 30, KWIDTH * 0.6, 50)];
    _account.placeholder = @"请输入账号";
    _account.borderStyle = UITextBorderStyleNone;
    _account.clearButtonMode = UITextFieldViewModeWhileEditing;/**< 按钮清除 */
    _account.autocorrectionType = UITextAutocorrectionTypeNo;/**< 取消自动修改 */
    _account.autocapitalizationType = UITextAutocapitalizationTypeNone;/**< 取消首字母大写 */
    _account.textColor = [UIColor whiteColor];
    [bView addSubview:_account];
    UILabel *accountLabel = [[UILabel alloc] initWithFrame:CGRectMake(67, CGRectGetMaxY(aLabel.frame) - 10, KWIDTH * 0.6 + 50, 1)];
    accountLabel.backgroundColor = ThemeColor;
    [bView addSubview:accountLabel];

    //密码
    UILabel *pLabel = [[UILabel alloc] init];
    pLabel.frame = CGRectMake(70, MAX_Y(accountLabel.frame) + 30, 50, 50);
    pLabel.text = @"密码";
    pLabel.textColor = [UIColor whiteColor];
    pLabel.font = DQAFont(37);
    [bView addSubview:pLabel];
    _password = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(pLabel.frame), CGRectGetMaxY(accountLabel.frame) + 30, KWIDTH * 0.6, 50)];
    _password.placeholder = @"请输入密码";
    _password.borderStyle = UITextBorderStyleNone;
    _password.clearButtonMode = UITextFieldViewModeWhileEditing;/**< 按钮清除 */
    _password.autocorrectionType = UITextAutocorrectionTypeNo;/**< 取消自动修改 */
    _password.autocapitalizationType = UITextAutocapitalizationTypeNone;/**< 取消首字母大写 */
    _password.textColor = [UIColor whiteColor];
    _password.secureTextEntry = YES;
    [bView addSubview:_password];
    UILabel *pwdLabel = [[UILabel alloc] initWithFrame:CGRectMake(67, CGRectGetMaxY(pLabel.frame) - 10, KWIDTH * 0.6 + 50, 1)];
    pwdLabel.backgroundColor = ThemeColor;
    [bView addSubview:pwdLabel];


    //登录
    UIButton *loginButton = [UIButton buttonWithType:UIButtonTypeSystem];
    loginButton.frame = CGRectMake(KWIDTH/3, MAX_Y(pwdLabel.frame) + 50, 150, 40);
    [loginButton setTitle:@"登  陆" forState:UIControlStateNormal];
    loginButton.backgroundColor = [UIColor colorWithRed:50/255.0 green:170/255.0 blue:101/255.0 alpha:1.0] ;
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginButton addTarget:self action:@selector(respondstoBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    loginButton.titleLabel.font = DQAFont(37);
    loginButton.tag = 3;
    loginButton.layer.masksToBounds = YES;
    loginButton.layer.cornerRadius = 10;
    [bView addSubview:loginButton];
    
    //忘记密码
    UIButton *forgetButton = [[UIButton alloc] initWithFrame:CGRectMake(KWIDTH/3, MAX_Y(loginButton.frame), 150, 30)];
    [forgetButton setTitle:@"忘记密码?" forState:UIControlStateNormal];
    [forgetButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    forgetButton.titleLabel.font = DQAFont(28);
    forgetButton.tag = 4;
    [forgetButton addTarget:self action:@selector(respondstoBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    [bView addSubview:forgetButton];

    
}
#pragma mark - respondstoBackBtn 返回事件
-(void)respondstoBackBtn:(UIButton *)sender{
    switch (sender.tag) {
        case 0:
            [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
            break;
        case 1:
            [self presentViewController:[DQRegisterViewController new] animated:YES completion:nil];
            break;
        case 3:
            [self loginResponder];
            break;
        default:
        case 4:{
            [self presentViewController:[[BackPassViewController alloc] init] animated:YES completion:nil];
        }
            break;
            break;
    }
    
}

// 登录点击事件
- (void)loginResponder{
    if ([self.account.text isEqualToString:@""] || [self.password.text isEqualToString:@""]) {
        [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"请填写完整的信息" disMissTime:1.0];
    }else{
        [UserInfoNetWorking userLoginWithLoginParam:@[self.account.text,self.password.text] block:^(BmobObject *object, NSError *error) {
            if (object){
                NSLog(@"%@",object);
                //  保存登陆的信息
                [[UserInfo sharedUserInfo] addUserInfo:object];
                //  归档
                NSData *userData = [NSKeyedArchiver archivedDataWithRootObject:[UserInfo sharedUserInfo]];
                [[NSUserDefaults standardUserDefaults] setObject:userData forKey:@"userInfo"];
                //  同步
                [[NSUserDefaults standardUserDefaults] synchronize];
                
                [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setValue:_account.text forKey:@"accountL"];
                [dict setValue:[UserInfo sharedUserInfo].objectId forKey:@"objectId"];
                [dict setValue:[UserInfo sharedUserInfo].headUrl forKey:@"headUrl"];
                [dict setValue:@"YES"  forKey:@"ifLogin"];
                [[NSUserDefaults standardUserDefaults] setObject:dict forKey:@"info"];
//                [[NSUserDefaults standardUserDefaults]setObject:_account.text forKey:@"accountL"];
//                [[NSUserDefaults standardUserDefaults] setObject:[UserInfo sharedUserInfo].objectId forKey:@"objectId"];
//                [[NSUserDefaults standardUserDefaults] setObject:[UserInfo sharedUserInfo].headUrl forKey:@"headUrl"];
//                [[NSUserDefaults standardUserDefaults]setObject:@"YES" forKey:@"ifLogin"];
                
                
                //  发送通知改变头像
                [[NSNotificationCenter defaultCenter]postNotificationName:@"updateHeadImg" object:nil userInfo:@{@"headUrl":[UserInfo sharedUserInfo].headUrl}];
                
                [self dismissViewControllerAnimated:YES completion:nil];
            }else{
                [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"用户名密码错误" disMissTime:1.0];
            }
        }];
    }
    
}


#pragma mark - 回收键盘
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
@end
