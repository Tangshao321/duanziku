//
//  UserInfo.m
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "UserInfo.h"
#import <objc/runtime.h>

@implementation UserInfo
+ (instancetype)sharedUserInfo
{
    static UserInfo *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[[self class] alloc]init];
        instance.userDefaultsKey = @"userInfo";
        
        instance.tableCLassName = @"userInfo";
        instance.keyUserId = @"objectId";
        instance.keyUserName =@"username";
        instance.keyEmail = @"email";
        instance.keyPassword = @"password";
        instance.keyHeadUrl = @"headUrl";
        instance.keyRegisterTime = @"createAt";
    });
    return instance;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self) {
        unsigned int count = 0;
        objc_property_t *propertyList = class_copyPropertyList([self class], &count);
        for(int i = 0; i < count; i++){
            objc_property_t aProperty = propertyList[i];
            const char *name = property_getName(aProperty);
            NSString *nameStr = [NSString stringWithUTF8String:name];
            //  使用kvc获取属性值
            [self setValue:[aDecoder decodeObjectForKey:nameStr] forKey:nameStr];
        }
    }
    return self;
}


- (void)encodeWithCoder:(NSCoder *)aCoder{
    unsigned int count = 0;
    objc_property_t *propertyList = class_copyPropertyList([self class], &count);
    for(int i = 0; i < count; i++){
        objc_property_t aProperty = propertyList[i];
        const char *name = property_getName(aProperty);
        NSString *nameStr = [NSString stringWithUTF8String:name];
        //  使用kvc获取属性值
        id value = [self valueForKey:nameStr];
        [aCoder encodeObject:value forKey:nameStr];
    }
}

//  添加用户信息
- (void)addUserInfo:(BmobObject *)object{
    self.userName = [object objectForKey:self.keyUserName];
    self.objectId = [object objectId];
    self.registerTime = [object createdAt];
    self.headUrl = [object objectForKey:self.keyHeadUrl];
    self.email = [object objectForKey:self.email];
}

//  重新设值
- (void)reset:(UserInfo *)userInfo{
    self.userName = userInfo.userName;
    self.objectId = userInfo.objectId;
    self.registerTime = userInfo.registerTime;
    self.headUrl = userInfo.headUrl;
    self.email = userInfo.email;
}

- (void)clearAllInfo{
    self.userName = nil;
    self.objectId = nil;
    self.registerTime = nil;
    self.headUrl = nil;
    self.email = nil;
}

@end
