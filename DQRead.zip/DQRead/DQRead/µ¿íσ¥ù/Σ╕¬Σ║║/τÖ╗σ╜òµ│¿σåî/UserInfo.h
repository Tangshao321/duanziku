//
//  UserInfo.h
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInfo : NSObject<NSCoding>
@property (nonatomic ,strong) NSString  *userDefaultsKey;


//  数据表的表名
@property (nonatomic ,strong) NSString  *tableCLassName;
//   数据的表的列名
@property (nonatomic ,strong) NSString  *keyUserName;
@property (nonatomic ,strong) NSString  *keyPassword;
@property (nonatomic ,strong) NSString  *keyEmail;
@property (nonatomic ,strong) NSString  *keyHeadUrl;
@property (nonatomic ,strong) NSString  *keyUserId;
@property (nonatomic ,strong) NSString  *keyRegisterTime;









//  请求下来的信息
@property (nonatomic ,strong) NSString *userName;
@property (nonatomic ,strong) NSString *objectId;
@property (nonatomic ,strong) NSString *headUrl;
@property (nonatomic ,strong) NSString *email;
@property (nonatomic ,strong) NSDate *registerTime;


//  单例
+ (instancetype)sharedUserInfo;

//  添加用户信息
- (void)addUserInfo:(BmobObject *)object;
//  重新设值
- (void)reset:(UserInfo *)userInfo;

- (void)clearAllInfo;
@end
