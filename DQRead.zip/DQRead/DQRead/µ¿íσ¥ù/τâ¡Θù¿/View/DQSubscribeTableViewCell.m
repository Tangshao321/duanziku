//
//  DQSubscribeTableViewCell.m
//  DQRead
//
//  Created by rimi on 2016/12/5.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQSubscribeTableViewCell.h"

//  间隔宽度
#define spaceWidth   DQAdaption(35)

@implementation DQSubscribeTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        CGFloat headPortraitWidth = DQAdaption(75);
        //  文字字体大小
        UIFont *fontSize = DQAFont(28);
        //  头像
        _headPortrait  = [[UIImageView alloc] initWithFrame:CGRectMake(spaceWidth, DQAdaption(25), headPortraitWidth, headPortraitWidth)];
        _headPortrait.layer.cornerRadius = headPortraitWidth /2;
        _headPortrait.layer.masksToBounds = YES;
   
        [self.contentView addSubview:_headPortrait];
        
        
        //  昵称
        _nickname = [[UILabel alloc] initWithFrame:DQAdaptionRect(130, 50, 400, 30)];
        _nickname.font = fontSize;
        [self.contentView addSubview:self.nickname];
        
        //  标题
        _aTitle = [[UILabel alloc] init];
        _aTitle.numberOfLines = 0;
         _aTitle.font = fontSize;
        [self.contentView addSubview:self.aTitle];
    }
    return self;
}

/**
 *  设置cell 的内容
 */
- (void)setCellContent:(BaseClass *)baseClass
{
    
    [self.imageGroupView removeFromSuperview];
    self.imageGroupView = nil;
    //  图片组视图
    self.imageGroupView = [[UIView alloc] init];
    [self.headPortrait sd_setImageWithURL:[NSURL URLWithString:baseClass.group.user.avatarUrl]];
    [self.nickname setText:baseClass.group.user.name];
    [self.aTitle setText:baseClass.group.content];
    //  更新frame
    [self.aTitle setFrame:CGRectMake(CGRectGetMinX(self.headPortrait.frame), CGRectGetMaxY(self.headPortrait.frame) + DQAdaption(20), SCREEN_WIDTH - 2 * spaceWidth, baseClass.group.heightForsContent)];
    
    //  图片间隔
    CGFloat imgSpaceWidth = DQAdaption(26);
    //  判断是否为多张图片
    if (baseClass.group.largeImageList.count > 0){
        /** 计算图片的宽度 */
        //  图片的个数
        NSInteger ImageCount = baseClass.group.thumbImageList.count > 9 ? 9:baseClass.group.thumbImageList.count;
        //  图片的宽度
        CGFloat ImageWidth = ImageCount > 1 ? ((SCREEN_WIDTH - 4 * imgSpaceWidth) / 3):(SCREEN_WIDTH - 2 * imgSpaceWidth);
        for (int i  = 0; i < ImageCount;i ++){
            UIImageView *aImageView = [[UIImageView alloc] initWithFrame:CGRectMake(imgSpaceWidth + (ImageWidth + imgSpaceWidth) * (i % 3), imgSpaceWidth + ((ImageWidth + imgSpaceWidth) * (i / 3)), ImageWidth, ImageWidth)];
            [aImageView sd_setImageWithURL:[NSURL URLWithString:baseClass.group.thumbImageList[i].url]];
            //  添加手势
            [aImageView addTapGestureRecognizerWithTarget:self action:@selector(imageViewTapGesture:)];
            // tag
            aImageView.tag = 100 + i;
            [self.imageGroupView addSubview:aImageView];
        }
        
        int num = 0;
        if (ImageCount%3 > 0) {
            num = 1;
        }
        
        [self.imageGroupView setFrame:CGRectMake(0, CGRectGetMaxY(self.aTitle.frame), SCREEN_WIDTH, imgSpaceWidth + (ImageWidth + imgSpaceWidth) * ((ImageCount / 3 ) + num) )];
        [self.contentView addSubview:self.imageGroupView];
    }else if (baseClass.group.largeImage.width > 0){
        CGFloat width = SCREEN_WIDTH - 2 * imgSpaceWidth;
        CGFloat height = (width/baseClass.group.largeImage.width) * baseClass.group.largeImage.height;
        UIImageView *aImageView = [[UIImageView alloc] initWithFrame:CGRectMake(imgSpaceWidth, imgSpaceWidth, width, height)];
        [aImageView sd_setImageWithURL:[NSURL URLWithString:baseClass.group.largeImage.urlList[0].url]];
        //  添加手势
        [aImageView addTapGestureRecognizerWithTarget:self action:@selector(imageViewTapGesture:)];
        
        aImageView.tag = 111;
        [self.imageGroupView addSubview:aImageView];
        [self.imageGroupView setFrame:CGRectMake(0, CGRectGetMaxY(self.aTitle.frame), SCREEN_WIDTH,CGRectGetMaxY(aImageView.frame)+ imgSpaceWidth)];
        
        [self.contentView addSubview:self.imageGroupView];

    }else{
        [self.imageGroupView setFrame:CGRectMake(0, CGRectGetMaxY(self.aTitle.frame), SCREEN_WIDTH,0)];
    }
    
}


/**
 *  cell 的高度
 */
- (CGFloat)cellHeight
{
    return CGRectGetMaxY(self.imageGroupView.frame) + DQAdaption(35);
}

/**
 *  图片的点击手势
 */
- (void)imageViewTapGesture:(UITapGestureRecognizer *)sender
{
    
    if (_delegate && [_delegate respondsToSelector:@selector(ImageView:tapedIndexPath:currnetTapImagTag:)]) {
        UIImageView *tapImageView =  (UIImageView *)sender.view;
        [_delegate ImageView:tapImageView tapedIndexPath:_indexPath currnetTapImagTag:tapImageView.tag%100];
    }
  
}


//  更新布局的时候回调用，会调用多次，因此不能再该方法中初始化子控件
- (void)layoutSubviews
{

}
@end
