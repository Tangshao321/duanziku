//
//  DQImageDetailCollectionViewCell.m
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQImageDetailCollectionViewCell.h"
#import "TransitionAnimation.h"


CGFloat lastScale = 1.0;
@implementation DQImageDetailCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:[UIColor clearColor]];
        _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
        _scrollView.tag = 1001;
        [self.contentView addSubview:_scrollView];
        
        _aImageView = [[UIImageView alloc] initWithFrame:self.bounds];
        [_scrollView addSubview:_aImageView];
       
        //  点击手势
        [self.aImageView addTapGestureRecognizerWithTarget:self action:@selector(ImageViewTapGesture:)];
        //  放大手势
        [self.aImageView addPinchGestureRecognizerWithTarget:self action:@selector(ImageViewPinchGesture:)];
    }
    return self;
}

//  多张图片
- (void)setCellContent:(LargeImageList *)largeImageList
{
  _scrollView.contentSize = self.aImageView.frame.size;

  //  添加图片
  [self.aImageView sd_setImageWithURL:[NSURL URLWithString:largeImageList.url]];
    
    // 计算图片的宽高度
    CGFloat imageWidth = SCREEN_WIDTH;
    CGFloat imageHeight = SCREEN_HEIGHT;
    //  距离
    CGFloat margin_top = 0;
    CGFloat margin_left = 0;
    if (largeImageList.width >= SCREEN_WIDTH )
    {
        imageWidth = SCREEN_WIDTH;
        margin_left = 0;
    }
    else
    {
        imageWidth = largeImageList.width;
        margin_left = (SCREEN_WIDTH - imageWidth) / 2;
    }
    
    //  按比例得到的图片高度
    CGFloat  scaleImageHeight = (SCREEN_WIDTH/largeImageList.width) * largeImageList.height;
    
    if ( scaleImageHeight < SCREEN_HEIGHT)
    {
        margin_top = (SCREEN_HEIGHT - scaleImageHeight)/2;
    }
    else
    {
        margin_top = 0;
    }
     imageHeight = scaleImageHeight;
    
    [self.aImageView setFrame:CGRectMake(margin_left, margin_top, imageWidth, imageHeight)];
    _scrollView.contentSize = self.aImageView.frame.size;
}

// 单张图片
- (void)setCellImage:(LargeImage *)largeImage
{
    _scrollView.contentSize = CGSizeMake(0, 0);
    //  添加图片
    [self.aImageView sd_setImageWithURL:[NSURL URLWithString:largeImage.urlList[0].url]];
    
    // 计算图片的宽高度
    CGFloat imageWidth = SCREEN_WIDTH;
    CGFloat imageHeight = SCREEN_HEIGHT;
    //  距离
    CGFloat margin_top = 0;
    CGFloat margin_left = 0;
    if (largeImage.width >= SCREEN_WIDTH )
    {
        imageWidth = SCREEN_WIDTH;
        margin_left = 0;
    }
    else
    {
        imageWidth = largeImage.width;
        margin_left = (SCREEN_WIDTH - imageWidth) / 2;
    }
    
    //  按比例得到的图片高度
    CGFloat  scaleImageHeight = (SCREEN_WIDTH/largeImage.width) * largeImage.height;
    
    if ( scaleImageHeight < SCREEN_HEIGHT)
    {
        margin_top = (SCREEN_HEIGHT - scaleImageHeight)/2;
    }
    else
    {
        margin_top = 0;
    }
    imageHeight = scaleImageHeight;
    
    [self.aImageView setFrame:CGRectMake(margin_left, margin_top, imageWidth, imageHeight)];
    _scrollView.contentSize = self.aImageView.frame.size;
}

//  图片的点击手势
- (void)ImageViewTapGesture:(UITapGestureRecognizer *)sender
{
    //  添加过度动画
    [[UIApplication sharedApplication].keyWindow.layer addAnimation:[TransitionAnimation transitionAnimation] forKey:nil];
    [_lastVC dismissViewControllerAnimated:YES completion:nil];
}


- (void)ImageViewPinchGesture:(UIPinchGestureRecognizer *)sender
{
    //  如果停止拖放就还原到原始大小
//    if (sender.state == UIGestureRecognizerStateEnded){
//        lastScale = 1.0;
//    }
    
    //  判断缩放的比例大小
    if(lastScale > 2.0){
        lastScale = 2.0;
    }else if (lastScale < 0.5){
        lastScale = 0.5;
    }
    NSLog(@"%lf",lastScale);
    

    [sender.view setTransform:CGAffineTransformMakeScale(lastScale, lastScale)];
    lastScale = sender.scale;
}

@end
