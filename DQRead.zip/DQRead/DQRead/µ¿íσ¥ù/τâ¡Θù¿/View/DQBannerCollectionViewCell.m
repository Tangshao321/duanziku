//
//  DQBannerCollectionViewCell.m
//  DQRead
//
//  Created by rimi on 2016/12/7.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQBannerCollectionViewCell.h"

@implementation DQBannerCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        CGFloat height = SCREEN_WIDTH/640 * 250;
        self.bannerIamge = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, height)];
        [self.contentView addSubview:self.bannerIamge];
    }
    return self;
}

@end
