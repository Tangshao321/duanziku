//
//  DQHotListTableViewCell.m
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQHotListTableViewCell.h"
#import "TakeList.h"
#import "TakeNetWorking.h"


//  间隔宽度
#define spaceWidth   DQAdaption(35)


@interface DQHotListTableViewCell()
@property (nonatomic ,strong) CategoryList  *category ;
@end

@implementation DQHotListTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        CGFloat headPortraitWidth = DQAdaption(82);
        //  头像
        _headPortrait  = [[UIImageView alloc] initWithFrame:CGRectMake(spaceWidth, DQAdaption(25), headPortraitWidth, headPortraitWidth)];
        _headPortrait.layer.cornerRadius = 3;
        _headPortrait.layer.masksToBounds = YES;
        
        [self.contentView addSubview:_headPortrait];
        
        
        //  昵称
        _nickname = [[UILabel alloc] initWithFrame:DQAdaptionRect(138, spaceWidth, 400, 30)];
        _nickname.font = DQAFont(30);
        [self.contentView addSubview:self.nickname];
        
        //  标题
        _aContent = [[UILabel alloc] initWithFrame:DQAdaptionRect(138, 70, 400, 30)];
        _aContent.font = DQAFont(22);
        _aContent.textColor = [UIColor colorWithRed:0.62 green:0.62 blue:0.62 alpha:1.00];
        [self.contentView addSubview:self.aContent];
        
        CGFloat takeButtonWitdh = DQAdaption(120);
        //  订阅按钮
        self.takeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.takeButton.frame = CGRectMake(SCREEN_WIDTH - takeButtonWitdh - DQAdaption(30) , DQAdaption(20), takeButtonWitdh, DQAdaption(60));
        [self.takeButton setTitle:@"订阅" forState:UIControlStateNormal];
        [self.takeButton setTitle:@"已订阅" forState:UIControlStateSelected];
        [self.takeButton setTitleColor:ThemeColor];
        [self.takeButton addTarget:self action:@selector(takeButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.takeButton];
        
        UILabel *lineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, DQAdaption(140) - 1, SCREEN_WIDTH, 1)];
        lineLabel.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1.00];
        [self.contentView addSubview:lineLabel];
    }
    return self;
}

- (void)setCellContent:(CategoryList *)categoryList{
    //self.takeButton.selected = NO;
    //self.takeButton.enabled = YES;
    self.category = categoryList;
    [self.headPortrait sd_setImageWithURL:[NSURL URLWithString:categoryList.smallIconUrl]];
    [self.nickname setText:categoryList.name];
    [self.aContent setText:categoryList.placeholder];
}


- (void)takeButtonClick:(UIButton *)sender{
    if ([UserInfo sharedUserInfo].objectId.length ==  0) {
        [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"请登陆后再订阅" disMissTime:2];
        return;
    }
    
    //  判断是否已订阅
    [TakeNetWorking findCategoryIdIsExists:self.category.categoryListIdentifier userTakeId:[UserInfo sharedUserInfo].objectId block:^(BOOL isExists, NSError *error) {
       
        if (isExists) {
            //  设置订阅按钮的选中效果
            self.takeButton.selected = isExists;
            self.takeButton.enabled = isExists;
             [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"已订阅" disMissTime:2];
        }else{
            //  订阅
            [self taked];
        }
    }];
    
    //   BmobObject  *takeList = [BmobObject objectWithClassName:[TakeList sharedTakeList].tableCLassName];
    
//    //设置关联内容
//    [takeList setObject:self.dict forKey:[TakeList sharedTakeList].keyUserTakeCategoryList];
//    NSInteger categoryId = self.category.categoryListIdentifier;
//    [takeList setObject:[NSString stringWithFormat:@"%ld",categoryId] forKey:[TakeList sharedTakeList].keyCategoryId];
//    
//    //设置帖子关联的用户id记录
//    BmobUser *takeId = [BmobUser objectWithoutDataWithClassName:[UserInfo sharedUserInfo].tableCLassName objectId:[UserInfo sharedUserInfo].objectId];
//   
//    [takeList setObject:takeId forKey:[TakeList sharedTakeList].keyUserTakeId];
//    
//    
//    //异步保存
//    [takeList saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
//            if (isSuccessful) {
//                self.takeButton.selected = YES;
//                //创建成功,表示已订阅
//                //打印objectId
//               [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"成功订阅" disMissTime:2];
//            }else{
//               [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"订阅失败" disMissTime:2];
//                NSLog(@"%@",error);
//            }
//    }];
    
}

//  订阅
- (void)taked{
    NSLog(@"123456");
    [TakeNetWorking takedWithCategoryId:self.category.categoryListIdentifier userTakeCategoryList:self.dict block:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            self.takeButton.selected = YES;
            //创建成功,表示已订阅
            //打印objectId
            [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"成功订阅" disMissTime:2];
        }else{
            [TjxCustomView showMessageAutoDismissWithTitle:@"提示" content:@"订阅失败" disMissTime:2];
            NSLog(@"%@",error);
        }
        
    }];

}

- (void)layoutSubviews{
    [super layoutSubviews];
}

@end
