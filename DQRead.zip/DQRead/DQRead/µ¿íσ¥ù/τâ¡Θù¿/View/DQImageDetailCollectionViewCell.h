//
//  DQImageDetailCollectionViewCell.h
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataModels.h"

@interface DQImageDetailCollectionViewCell : UICollectionViewCell
@property (nonatomic ,strong) UIScrollView *scrollView ;
/*!
 * 图片
 */
@property (nonatomic ,strong) UIImageView *aImageView;
/*!
 * 多张图片的url
 */
@property (nonatomic ,strong,setter=setCellContent:) LargeImageList  *largeImageList ;

/*!
 * 单张图片的url
 */
@property (nonatomic ,strong,setter=setCellImage:) LargeImage *largeImage;

/*!
 * 控制器类
 */
@property (nonatomic ,weak) UIViewController  *lastVC;
@end
