//
//  DQSubscribeTableViewCell.h
//  DQRead
//
//  Created by rimi on 2016/12/5.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataModels.h"

//    cell的图片的点击代理方法
@protocol UITableViewCellImageTapDelegate <NSObject>

- (void)ImageView:(UIImageView *)imageView
   tapedIndexPath:(NSIndexPath *)indexPath
currnetTapImagTag:(NSInteger)ImageTag;
@end


@interface DQSubscribeTableViewCell : UITableViewCell
@property (nonatomic ,weak)id<UITableViewCellImageTapDelegate> delegate;

@property (nonatomic ,strong) NSIndexPath  *indexPath;

/**
 * 头像
 */
@property (nonatomic ,strong) UIImageView  *headPortrait;
/**
 * 昵称
 */
@property (nonatomic ,strong) UILabel  *nickname;
/**
 * 标题
 */
@property (nonatomic ,strong) UILabel  *aTitle;
/**
 * 标签
 */
@property (nonatomic ,strong) UILabel  *tagLabel;

/**
 * 图片组
 */
@property (nonatomic ,strong) UIView *imageGroupView;

//  设置cell的内容
@property (nonatomic ,strong,setter=setCellContent:) BaseClass  *baseClass;
// cell的高度
@property (nonatomic ,assign)CGFloat cellHeight;
@end
