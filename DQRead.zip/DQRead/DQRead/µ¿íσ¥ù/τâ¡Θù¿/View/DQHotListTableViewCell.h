//
//  DQHotListTableViewCell.h
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryList.h"
@interface DQHotListTableViewCell : UITableViewCell
@property (nonatomic ,strong) NSIndexPath  *indexPath;

/**
 * 头像
 */
@property (nonatomic ,strong) UIImageView  *headPortrait;
/**
 * 昵称
 */
@property (nonatomic ,strong) UILabel  *nickname;
/**
 * 内容
 */
@property (nonatomic ,strong) UILabel  *aContent;
/**
 * 标签
 */
@property (nonatomic ,strong) UILabel  *tagLabel;
/**
 * 订阅按钮
 */
@property (nonatomic ,strong) UIButton *takeButton;


@property (nonatomic ,strong,setter=setCellContent:)CategoryList *categoryList;


@property (nonatomic ,strong) NSDictionary  *dict;
@end
