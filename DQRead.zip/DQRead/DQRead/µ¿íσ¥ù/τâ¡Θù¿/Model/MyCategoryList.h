//
//  MyCategoryList.h
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Extra;

@interface MyCategoryList : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *icon;
@property (nonatomic, assign) double isRecommend;
@property (nonatomic, assign) double shareType;
@property (nonatomic, assign) double isTop;
@property (nonatomic, assign) double myCategoryListIdentifier;
@property (nonatomic, copy) NSString * mixWeight;
@property (nonatomic, strong) NSString *iconUrl;
@property (nonatomic, assign) double totalUpdates;
@property (nonatomic, strong) NSString *smallIconUrl;
@property (nonatomic, assign) double isRisk;
@property (nonatomic, assign) double bigCategoryId;
@property (nonatomic, strong) NSString *topStartTime;
@property (nonatomic, assign) double type;
@property (nonatomic, strong) NSString *buttons;
@property (nonatomic, assign) double allowText;
@property (nonatomic, strong) Extra *extra;
@property (nonatomic, strong) NSString *tag;
@property (nonatomic, strong) NSString *intro;
@property (nonatomic, assign) double priority;
@property (nonatomic, assign) double postRuleId;
@property (nonatomic, assign) double subscribeCount;
@property (nonatomic, assign) double allowMultiImage;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *smallIcon;
@property (nonatomic, assign) double status;
@property (nonatomic, assign) double todayUpdates;
@property (nonatomic, strong) NSString *topEndTime;
@property (nonatomic, assign) double visible;
@property (nonatomic, strong) NSArray *materialBar;
@property (nonatomic, assign) double allowGif;
@property (nonatomic, assign) double allowTextAndPic;
@property (nonatomic, strong) NSString *channels;
@property (nonatomic, assign) double allowVideo;
@property (nonatomic, assign) double dedup;
@property (nonatomic, strong) NSString *shareUrl;
@property (nonatomic, strong) NSString *placeholder;
@property (nonatomic, assign) double hasTimeliness;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
