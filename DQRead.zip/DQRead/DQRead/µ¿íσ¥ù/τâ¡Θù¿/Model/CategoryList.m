//
//  CategoryList.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "CategoryList.h"
#import "Extra.h"


NSString *const kCategoryListIcon = @"icon";
NSString *const kCategoryListIsRecommend = @"is_recommend";
NSString *const kCategoryListShareType = @"share_type";
NSString *const kCategoryListIsTop = @"is_top";
NSString *const kCategoryListId = @"id";
NSString *const kCategoryListMixWeight = @"mix_weight";
NSString *const kCategoryListIconUrl = @"icon_url";
NSString *const kCategoryListTotalUpdates = @"total_updates";
NSString *const kCategoryListSmallIconUrl = @"small_icon_url";
NSString *const kCategoryListIsRisk = @"is_risk";
NSString *const kCategoryListBigCategoryId = @"big_category_id";
NSString *const kCategoryListTopStartTime = @"top_start_time";
NSString *const kCategoryListType = @"type";
NSString *const kCategoryListButtons = @"buttons";
NSString *const kCategoryListAllowText = @"allow_text";
NSString *const kCategoryListExtra = @"extra";
NSString *const kCategoryListTag = @"tag";
NSString *const kCategoryListIntro = @"intro";
NSString *const kCategoryListPriority = @"priority";
NSString *const kCategoryListPostRuleId = @"post_rule_id";
NSString *const kCategoryListSubscribeCount = @"subscribe_count";
NSString *const kCategoryListAllowMultiImage = @"allow_multi_image";
NSString *const kCategoryListName = @"name";
NSString *const kCategoryListSmallIcon = @"small_icon";
NSString *const kCategoryListStatus = @"status";
NSString *const kCategoryListTodayUpdates = @"today_updates";
NSString *const kCategoryListTopEndTime = @"top_end_time";
NSString *const kCategoryListVisible = @"visible";
NSString *const kCategoryListMaterialBar = @"material_bar";
NSString *const kCategoryListAllowGif = @"allow_gif";
NSString *const kCategoryListAllowTextAndPic = @"allow_text_and_pic";
NSString *const kCategoryListChannels = @"channels";
NSString *const kCategoryListAllowVideo = @"allow_video";
NSString *const kCategoryListDedup = @"dedup";
NSString *const kCategoryListShareUrl = @"share_url";
NSString *const kCategoryListPlaceholder = @"placeholder";
NSString *const kCategoryListHasTimeliness = @"has_timeliness";


@interface CategoryList ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation CategoryList

@synthesize icon = _icon;
@synthesize isRecommend = _isRecommend;
@synthesize shareType = _shareType;
@synthesize isTop = _isTop;
@synthesize categoryListIdentifier = _categoryListIdentifier;
@synthesize mixWeight = _mixWeight;
@synthesize iconUrl = _iconUrl;
@synthesize totalUpdates = _totalUpdates;
@synthesize smallIconUrl = _smallIconUrl;
@synthesize isRisk = _isRisk;
@synthesize bigCategoryId = _bigCategoryId;
@synthesize topStartTime = _topStartTime;
@synthesize type = _type;
@synthesize buttons = _buttons;
@synthesize allowText = _allowText;
@synthesize extra = _extra;
@synthesize tag = _tag;
@synthesize intro = _intro;
@synthesize priority = _priority;
@synthesize postRuleId = _postRuleId;
@synthesize subscribeCount = _subscribeCount;
@synthesize allowMultiImage = _allowMultiImage;
@synthesize name = _name;
@synthesize smallIcon = _smallIcon;
@synthesize status = _status;
@synthesize todayUpdates = _todayUpdates;
@synthesize topEndTime = _topEndTime;
@synthesize visible = _visible;
@synthesize materialBar = _materialBar;
@synthesize allowGif = _allowGif;
@synthesize allowTextAndPic = _allowTextAndPic;
@synthesize channels = _channels;
@synthesize allowVideo = _allowVideo;
@synthesize dedup = _dedup;
@synthesize shareUrl = _shareUrl;
@synthesize placeholder = _placeholder;
@synthesize hasTimeliness = _hasTimeliness;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.icon = [self objectOrNilForKey:kCategoryListIcon fromDictionary:dict];
            self.isRecommend = [[self objectOrNilForKey:kCategoryListIsRecommend fromDictionary:dict] doubleValue];
            self.shareType = [[self objectOrNilForKey:kCategoryListShareType fromDictionary:dict] doubleValue];
            self.isTop = [[self objectOrNilForKey:kCategoryListIsTop fromDictionary:dict] doubleValue];
            self.categoryListIdentifier = [[self objectOrNilForKey:kCategoryListId fromDictionary:dict] doubleValue];
            self.mixWeight = [self objectOrNilForKey:kCategoryListMixWeight fromDictionary:dict];
            self.iconUrl = [self objectOrNilForKey:kCategoryListIconUrl fromDictionary:dict];
            self.totalUpdates = [[self objectOrNilForKey:kCategoryListTotalUpdates fromDictionary:dict] doubleValue];
            self.smallIconUrl = [self objectOrNilForKey:kCategoryListSmallIconUrl fromDictionary:dict];
            self.isRisk = [[self objectOrNilForKey:kCategoryListIsRisk fromDictionary:dict] doubleValue];
            self.bigCategoryId = [[self objectOrNilForKey:kCategoryListBigCategoryId fromDictionary:dict] doubleValue];
            self.topStartTime = [self objectOrNilForKey:kCategoryListTopStartTime fromDictionary:dict];
            self.type = [[self objectOrNilForKey:kCategoryListType fromDictionary:dict] doubleValue];
            self.buttons = [self objectOrNilForKey:kCategoryListButtons fromDictionary:dict];
            self.allowText = [[self objectOrNilForKey:kCategoryListAllowText fromDictionary:dict] doubleValue];
            self.extra = [Extra modelObjectWithDictionary:[dict objectForKey:kCategoryListExtra]];
            self.tag = [self objectOrNilForKey:kCategoryListTag fromDictionary:dict];
            self.intro = [self objectOrNilForKey:kCategoryListIntro fromDictionary:dict];
            self.priority = [[self objectOrNilForKey:kCategoryListPriority fromDictionary:dict] doubleValue];
            self.postRuleId = [[self objectOrNilForKey:kCategoryListPostRuleId fromDictionary:dict] doubleValue];
            self.subscribeCount = [[self objectOrNilForKey:kCategoryListSubscribeCount fromDictionary:dict] doubleValue];
            self.allowMultiImage = [[self objectOrNilForKey:kCategoryListAllowMultiImage fromDictionary:dict] doubleValue];
            self.name = [self objectOrNilForKey:kCategoryListName fromDictionary:dict];
            self.smallIcon = [self objectOrNilForKey:kCategoryListSmallIcon fromDictionary:dict];
            self.status = [[self objectOrNilForKey:kCategoryListStatus fromDictionary:dict] doubleValue];
            self.todayUpdates = [[self objectOrNilForKey:kCategoryListTodayUpdates fromDictionary:dict] doubleValue];
            self.topEndTime = [self objectOrNilForKey:kCategoryListTopEndTime fromDictionary:dict];
            self.visible = [[self objectOrNilForKey:kCategoryListVisible fromDictionary:dict] doubleValue];
            self.materialBar = [self objectOrNilForKey:kCategoryListMaterialBar fromDictionary:dict];
            self.allowGif = [[self objectOrNilForKey:kCategoryListAllowGif fromDictionary:dict] doubleValue];
            self.allowTextAndPic = [[self objectOrNilForKey:kCategoryListAllowTextAndPic fromDictionary:dict] doubleValue];
            self.channels = [self objectOrNilForKey:kCategoryListChannels fromDictionary:dict];
            self.allowVideo = [[self objectOrNilForKey:kCategoryListAllowVideo fromDictionary:dict] doubleValue];
            self.dedup = [[self objectOrNilForKey:kCategoryListDedup fromDictionary:dict] doubleValue];
            self.shareUrl = [self objectOrNilForKey:kCategoryListShareUrl fromDictionary:dict];
            self.placeholder = [self objectOrNilForKey:kCategoryListPlaceholder fromDictionary:dict];
            self.hasTimeliness = [[self objectOrNilForKey:kCategoryListHasTimeliness fromDictionary:dict] doubleValue];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.icon forKey:kCategoryListIcon];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isRecommend] forKey:kCategoryListIsRecommend];
    [mutableDict setValue:[NSNumber numberWithDouble:self.shareType] forKey:kCategoryListShareType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isTop] forKey:kCategoryListIsTop];
    [mutableDict setValue:[NSNumber numberWithDouble:self.categoryListIdentifier] forKey:kCategoryListId];
    [mutableDict setValue:self.mixWeight forKey:kCategoryListMixWeight];
    [mutableDict setValue:self.iconUrl forKey:kCategoryListIconUrl];
    [mutableDict setValue:[NSNumber numberWithDouble:self.totalUpdates] forKey:kCategoryListTotalUpdates];
    [mutableDict setValue:self.smallIconUrl forKey:kCategoryListSmallIconUrl];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isRisk] forKey:kCategoryListIsRisk];
    [mutableDict setValue:[NSNumber numberWithDouble:self.bigCategoryId] forKey:kCategoryListBigCategoryId];
    [mutableDict setValue:self.topStartTime forKey:kCategoryListTopStartTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.type] forKey:kCategoryListType];
    [mutableDict setValue:self.buttons forKey:kCategoryListButtons];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowText] forKey:kCategoryListAllowText];
    [mutableDict setValue:[self.extra dictionaryRepresentation] forKey:kCategoryListExtra];
    [mutableDict setValue:self.tag forKey:kCategoryListTag];
    [mutableDict setValue:self.intro forKey:kCategoryListIntro];
    [mutableDict setValue:[NSNumber numberWithDouble:self.priority] forKey:kCategoryListPriority];
    [mutableDict setValue:[NSNumber numberWithDouble:self.postRuleId] forKey:kCategoryListPostRuleId];
    [mutableDict setValue:[NSNumber numberWithDouble:self.subscribeCount] forKey:kCategoryListSubscribeCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowMultiImage] forKey:kCategoryListAllowMultiImage];
    [mutableDict setValue:self.name forKey:kCategoryListName];
    [mutableDict setValue:self.smallIcon forKey:kCategoryListSmallIcon];
    [mutableDict setValue:[NSNumber numberWithDouble:self.status] forKey:kCategoryListStatus];
    [mutableDict setValue:[NSNumber numberWithDouble:self.todayUpdates] forKey:kCategoryListTodayUpdates];
    [mutableDict setValue:self.topEndTime forKey:kCategoryListTopEndTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.visible] forKey:kCategoryListVisible];
    NSMutableArray *tempArrayForMaterialBar = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.materialBar) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForMaterialBar addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForMaterialBar addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForMaterialBar] forKey:kCategoryListMaterialBar];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowGif] forKey:kCategoryListAllowGif];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowTextAndPic] forKey:kCategoryListAllowTextAndPic];
    [mutableDict setValue:self.channels forKey:kCategoryListChannels];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowVideo] forKey:kCategoryListAllowVideo];
    [mutableDict setValue:[NSNumber numberWithDouble:self.dedup] forKey:kCategoryListDedup];
    [mutableDict setValue:self.shareUrl forKey:kCategoryListShareUrl];
    [mutableDict setValue:self.placeholder forKey:kCategoryListPlaceholder];
    [mutableDict setValue:[NSNumber numberWithDouble:self.hasTimeliness] forKey:kCategoryListHasTimeliness];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.icon = [aDecoder decodeObjectForKey:kCategoryListIcon];
    self.isRecommend = [aDecoder decodeDoubleForKey:kCategoryListIsRecommend];
    self.shareType = [aDecoder decodeDoubleForKey:kCategoryListShareType];
    self.isTop = [aDecoder decodeDoubleForKey:kCategoryListIsTop];
    self.categoryListIdentifier = [aDecoder decodeDoubleForKey:kCategoryListId];
    self.mixWeight = [aDecoder decodeObjectForKey:kCategoryListMixWeight];
    self.iconUrl = [aDecoder decodeObjectForKey:kCategoryListIconUrl];
    self.totalUpdates = [aDecoder decodeDoubleForKey:kCategoryListTotalUpdates];
    self.smallIconUrl = [aDecoder decodeObjectForKey:kCategoryListSmallIconUrl];
    self.isRisk = [aDecoder decodeDoubleForKey:kCategoryListIsRisk];
    self.bigCategoryId = [aDecoder decodeDoubleForKey:kCategoryListBigCategoryId];
    self.topStartTime = [aDecoder decodeObjectForKey:kCategoryListTopStartTime];
    self.type = [aDecoder decodeDoubleForKey:kCategoryListType];
    self.buttons = [aDecoder decodeObjectForKey:kCategoryListButtons];
    self.allowText = [aDecoder decodeDoubleForKey:kCategoryListAllowText];
    self.extra = [aDecoder decodeObjectForKey:kCategoryListExtra];
    self.tag = [aDecoder decodeObjectForKey:kCategoryListTag];
    self.intro = [aDecoder decodeObjectForKey:kCategoryListIntro];
    self.priority = [aDecoder decodeDoubleForKey:kCategoryListPriority];
    self.postRuleId = [aDecoder decodeDoubleForKey:kCategoryListPostRuleId];
    self.subscribeCount = [aDecoder decodeDoubleForKey:kCategoryListSubscribeCount];
    self.allowMultiImage = [aDecoder decodeDoubleForKey:kCategoryListAllowMultiImage];
    self.name = [aDecoder decodeObjectForKey:kCategoryListName];
    self.smallIcon = [aDecoder decodeObjectForKey:kCategoryListSmallIcon];
    self.status = [aDecoder decodeDoubleForKey:kCategoryListStatus];
    self.todayUpdates = [aDecoder decodeDoubleForKey:kCategoryListTodayUpdates];
    self.topEndTime = [aDecoder decodeObjectForKey:kCategoryListTopEndTime];
    self.visible = [aDecoder decodeDoubleForKey:kCategoryListVisible];
    self.materialBar = [aDecoder decodeObjectForKey:kCategoryListMaterialBar];
    self.allowGif = [aDecoder decodeDoubleForKey:kCategoryListAllowGif];
    self.allowTextAndPic = [aDecoder decodeDoubleForKey:kCategoryListAllowTextAndPic];
    self.channels = [aDecoder decodeObjectForKey:kCategoryListChannels];
    self.allowVideo = [aDecoder decodeDoubleForKey:kCategoryListAllowVideo];
    self.dedup = [aDecoder decodeDoubleForKey:kCategoryListDedup];
    self.shareUrl = [aDecoder decodeObjectForKey:kCategoryListShareUrl];
    self.placeholder = [aDecoder decodeObjectForKey:kCategoryListPlaceholder];
    self.hasTimeliness = [aDecoder decodeDoubleForKey:kCategoryListHasTimeliness];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_icon forKey:kCategoryListIcon];
    [aCoder encodeDouble:_isRecommend forKey:kCategoryListIsRecommend];
    [aCoder encodeDouble:_shareType forKey:kCategoryListShareType];
    [aCoder encodeDouble:_isTop forKey:kCategoryListIsTop];
    [aCoder encodeDouble:_categoryListIdentifier forKey:kCategoryListId];
    [aCoder encodeObject:_mixWeight forKey:kCategoryListMixWeight];
    [aCoder encodeObject:_iconUrl forKey:kCategoryListIconUrl];
    [aCoder encodeDouble:_totalUpdates forKey:kCategoryListTotalUpdates];
    [aCoder encodeObject:_smallIconUrl forKey:kCategoryListSmallIconUrl];
    [aCoder encodeDouble:_isRisk forKey:kCategoryListIsRisk];
    [aCoder encodeDouble:_bigCategoryId forKey:kCategoryListBigCategoryId];
    [aCoder encodeObject:_topStartTime forKey:kCategoryListTopStartTime];
    [aCoder encodeDouble:_type forKey:kCategoryListType];
    [aCoder encodeObject:_buttons forKey:kCategoryListButtons];
    [aCoder encodeDouble:_allowText forKey:kCategoryListAllowText];
    [aCoder encodeObject:_extra forKey:kCategoryListExtra];
    [aCoder encodeObject:_tag forKey:kCategoryListTag];
    [aCoder encodeObject:_intro forKey:kCategoryListIntro];
    [aCoder encodeDouble:_priority forKey:kCategoryListPriority];
    [aCoder encodeDouble:_postRuleId forKey:kCategoryListPostRuleId];
    [aCoder encodeDouble:_subscribeCount forKey:kCategoryListSubscribeCount];
    [aCoder encodeDouble:_allowMultiImage forKey:kCategoryListAllowMultiImage];
    [aCoder encodeObject:_name forKey:kCategoryListName];
    [aCoder encodeObject:_smallIcon forKey:kCategoryListSmallIcon];
    [aCoder encodeDouble:_status forKey:kCategoryListStatus];
    [aCoder encodeDouble:_todayUpdates forKey:kCategoryListTodayUpdates];
    [aCoder encodeObject:_topEndTime forKey:kCategoryListTopEndTime];
    [aCoder encodeDouble:_visible forKey:kCategoryListVisible];
    [aCoder encodeObject:_materialBar forKey:kCategoryListMaterialBar];
    [aCoder encodeDouble:_allowGif forKey:kCategoryListAllowGif];
    [aCoder encodeDouble:_allowTextAndPic forKey:kCategoryListAllowTextAndPic];
    [aCoder encodeObject:_channels forKey:kCategoryListChannels];
    [aCoder encodeDouble:_allowVideo forKey:kCategoryListAllowVideo];
    [aCoder encodeDouble:_dedup forKey:kCategoryListDedup];
    [aCoder encodeObject:_shareUrl forKey:kCategoryListShareUrl];
    [aCoder encodeObject:_placeholder forKey:kCategoryListPlaceholder];
    [aCoder encodeDouble:_hasTimeliness forKey:kCategoryListHasTimeliness];
}

- (id)copyWithZone:(NSZone *)zone {
    CategoryList *copy = [[CategoryList alloc] init];
    
    
    
    if (copy) {

        copy.icon = [self.icon copyWithZone:zone];
        copy.isRecommend = self.isRecommend;
        copy.shareType = self.shareType;
        copy.isTop = self.isTop;
        copy.categoryListIdentifier = self.categoryListIdentifier;
        copy.mixWeight = [self.mixWeight copyWithZone:zone];
        copy.iconUrl = [self.iconUrl copyWithZone:zone];
        copy.totalUpdates = self.totalUpdates;
        copy.smallIconUrl = [self.smallIconUrl copyWithZone:zone];
        copy.isRisk = self.isRisk;
        copy.bigCategoryId = self.bigCategoryId;
        copy.topStartTime = [self.topStartTime copyWithZone:zone];
        copy.type = self.type;
        copy.buttons = [self.buttons copyWithZone:zone];
        copy.allowText = self.allowText;
        copy.extra = [self.extra copyWithZone:zone];
        copy.tag = [self.tag copyWithZone:zone];
        copy.intro = [self.intro copyWithZone:zone];
        copy.priority = self.priority;
        copy.postRuleId = self.postRuleId;
        copy.subscribeCount = self.subscribeCount;
        copy.allowMultiImage = self.allowMultiImage;
        copy.name = [self.name copyWithZone:zone];
        copy.smallIcon = [self.smallIcon copyWithZone:zone];
        copy.status = self.status;
        copy.todayUpdates = self.todayUpdates;
        copy.topEndTime = [self.topEndTime copyWithZone:zone];
        copy.visible = self.visible;
        copy.materialBar = [self.materialBar copyWithZone:zone];
        copy.allowGif = self.allowGif;
        copy.allowTextAndPic = self.allowTextAndPic;
        copy.channels = [self.channels copyWithZone:zone];
        copy.allowVideo = self.allowVideo;
        copy.dedup = self.dedup;
        copy.shareUrl = [self.shareUrl copyWithZone:zone];
        copy.placeholder = [self.placeholder copyWithZone:zone];
        copy.hasTimeliness = self.hasTimeliness;
    }
    
    return copy;
}


@end
