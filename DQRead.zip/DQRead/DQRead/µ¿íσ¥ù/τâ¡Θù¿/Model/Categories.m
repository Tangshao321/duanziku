//
//  Categories.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "Categories.h"
#import "CategoryList.h"


NSString *const kCategoriesPriority = @"priority";
NSString *const kCategoriesCategoryCount = @"category_count";
NSString *const kCategoriesId = @"id";
NSString *const kCategoriesIntro = @"intro";
NSString *const kCategoriesCategoryList = @"category_list";
NSString *const kCategoriesName = @"name";
NSString *const kCategoriesIcon = @"icon";


@interface Categories ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Categories

@synthesize priority = _priority;
@synthesize categoryCount = _categoryCount;
@synthesize categoriesIdentifier = _categoriesIdentifier;
@synthesize intro = _intro;
@synthesize categoryList = _categoryList;
@synthesize name = _name;
@synthesize icon = _icon;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.priority = [[self objectOrNilForKey:kCategoriesPriority fromDictionary:dict] doubleValue];
            self.categoryCount = [[self objectOrNilForKey:kCategoriesCategoryCount fromDictionary:dict] doubleValue];
            self.categoriesIdentifier = [[self objectOrNilForKey:kCategoriesId fromDictionary:dict] doubleValue];
            self.intro = [self objectOrNilForKey:kCategoriesIntro fromDictionary:dict];
    NSObject *receivedCategoryList = [dict objectForKey:kCategoriesCategoryList];
    NSMutableArray *parsedCategoryList = [NSMutableArray array];
    
    if ([receivedCategoryList isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedCategoryList) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedCategoryList addObject:[CategoryList modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedCategoryList isKindOfClass:[NSDictionary class]]) {
       [parsedCategoryList addObject:[CategoryList modelObjectWithDictionary:(NSDictionary *)receivedCategoryList]];
    }

    self.categoryList = [NSArray arrayWithArray:parsedCategoryList];
            self.name = [self objectOrNilForKey:kCategoriesName fromDictionary:dict];
            self.icon = [self objectOrNilForKey:kCategoriesIcon fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[NSNumber numberWithDouble:self.priority] forKey:kCategoriesPriority];
    [mutableDict setValue:[NSNumber numberWithDouble:self.categoryCount] forKey:kCategoriesCategoryCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.categoriesIdentifier] forKey:kCategoriesId];
    [mutableDict setValue:self.intro forKey:kCategoriesIntro];
    NSMutableArray *tempArrayForCategoryList = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.categoryList) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForCategoryList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForCategoryList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForCategoryList] forKey:kCategoriesCategoryList];
    [mutableDict setValue:self.name forKey:kCategoriesName];
    [mutableDict setValue:self.icon forKey:kCategoriesIcon];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.priority = [aDecoder decodeDoubleForKey:kCategoriesPriority];
    self.categoryCount = [aDecoder decodeDoubleForKey:kCategoriesCategoryCount];
    self.categoriesIdentifier = [aDecoder decodeDoubleForKey:kCategoriesId];
    self.intro = [aDecoder decodeObjectForKey:kCategoriesIntro];
    self.categoryList = [aDecoder decodeObjectForKey:kCategoriesCategoryList];
    self.name = [aDecoder decodeObjectForKey:kCategoriesName];
    self.icon = [aDecoder decodeObjectForKey:kCategoriesIcon];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeDouble:_priority forKey:kCategoriesPriority];
    [aCoder encodeDouble:_categoryCount forKey:kCategoriesCategoryCount];
    [aCoder encodeDouble:_categoriesIdentifier forKey:kCategoriesId];
    [aCoder encodeObject:_intro forKey:kCategoriesIntro];
    [aCoder encodeObject:_categoryList forKey:kCategoriesCategoryList];
    [aCoder encodeObject:_name forKey:kCategoriesName];
    [aCoder encodeObject:_icon forKey:kCategoriesIcon];
}

- (id)copyWithZone:(NSZone *)zone {
    Categories *copy = [[Categories alloc] init];
    
    
    
    if (copy) {

        copy.priority = self.priority;
        copy.categoryCount = self.categoryCount;
        copy.categoriesIdentifier = self.categoriesIdentifier;
        copy.intro = [self.intro copyWithZone:zone];
        copy.categoryList = [self.categoryList copyWithZone:zone];
        copy.name = [self.name copyWithZone:zone];
        copy.icon = [self.icon copyWithZone:zone];
    }
    
    return copy;
}


@end
