//
//  MyTopCategoryList.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "MyTopCategoryList.h"
#import "Extra.h"


NSString *const kMyTopCategoryListIcon = @"icon";
NSString *const kMyTopCategoryListIsRecommend = @"is_recommend";
NSString *const kMyTopCategoryListShareType = @"share_type";
NSString *const kMyTopCategoryListIsTop = @"is_top";
NSString *const kMyTopCategoryListId = @"id";
NSString *const kMyTopCategoryListMixWeight = @"mix_weight";
NSString *const kMyTopCategoryListIconUrl = @"icon_url";
NSString *const kMyTopCategoryListTotalUpdates = @"total_updates";
NSString *const kMyTopCategoryListSmallIconUrl = @"small_icon_url";
NSString *const kMyTopCategoryListIsRisk = @"is_risk";
NSString *const kMyTopCategoryListBigCategoryId = @"big_category_id";
NSString *const kMyTopCategoryListTopStartTime = @"top_start_time";
NSString *const kMyTopCategoryListType = @"type";
NSString *const kMyTopCategoryListButtons = @"buttons";
NSString *const kMyTopCategoryListAllowText = @"allow_text";
NSString *const kMyTopCategoryListExtra = @"extra";
NSString *const kMyTopCategoryListTag = @"tag";
NSString *const kMyTopCategoryListIntro = @"intro";
NSString *const kMyTopCategoryListPriority = @"priority";
NSString *const kMyTopCategoryListPostRuleId = @"post_rule_id";
NSString *const kMyTopCategoryListSubscribeCount = @"subscribe_count";
NSString *const kMyTopCategoryListAllowMultiImage = @"allow_multi_image";
NSString *const kMyTopCategoryListName = @"name";
NSString *const kMyTopCategoryListSmallIcon = @"small_icon";
NSString *const kMyTopCategoryListStatus = @"status";
NSString *const kMyTopCategoryListTodayUpdates = @"today_updates";
NSString *const kMyTopCategoryListTopEndTime = @"top_end_time";
NSString *const kMyTopCategoryListVisible = @"visible";
NSString *const kMyTopCategoryListMaterialBar = @"material_bar";
NSString *const kMyTopCategoryListAllowGif = @"allow_gif";
NSString *const kMyTopCategoryListAllowTextAndPic = @"allow_text_and_pic";
NSString *const kMyTopCategoryListChannels = @"channels";
NSString *const kMyTopCategoryListAllowVideo = @"allow_video";
NSString *const kMyTopCategoryListDedup = @"dedup";
NSString *const kMyTopCategoryListShareUrl = @"share_url";
NSString *const kMyTopCategoryListPlaceholder = @"placeholder";
NSString *const kMyTopCategoryListHasTimeliness = @"has_timeliness";


@interface MyTopCategoryList ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation MyTopCategoryList

@synthesize icon = _icon;
@synthesize isRecommend = _isRecommend;
@synthesize shareType = _shareType;
@synthesize isTop = _isTop;
@synthesize myTopCategoryListIdentifier = _myTopCategoryListIdentifier;
@synthesize mixWeight = _mixWeight;
@synthesize iconUrl = _iconUrl;
@synthesize totalUpdates = _totalUpdates;
@synthesize smallIconUrl = _smallIconUrl;
@synthesize isRisk = _isRisk;
@synthesize bigCategoryId = _bigCategoryId;
@synthesize topStartTime = _topStartTime;
@synthesize type = _type;
@synthesize buttons = _buttons;
@synthesize allowText = _allowText;
@synthesize extra = _extra;
@synthesize tag = _tag;
@synthesize intro = _intro;
@synthesize priority = _priority;
@synthesize postRuleId = _postRuleId;
@synthesize subscribeCount = _subscribeCount;
@synthesize allowMultiImage = _allowMultiImage;
@synthesize name = _name;
@synthesize smallIcon = _smallIcon;
@synthesize status = _status;
@synthesize todayUpdates = _todayUpdates;
@synthesize topEndTime = _topEndTime;
@synthesize visible = _visible;
@synthesize materialBar = _materialBar;
@synthesize allowGif = _allowGif;
@synthesize allowTextAndPic = _allowTextAndPic;
@synthesize channels = _channels;
@synthesize allowVideo = _allowVideo;
@synthesize dedup = _dedup;
@synthesize shareUrl = _shareUrl;
@synthesize placeholder = _placeholder;
@synthesize hasTimeliness = _hasTimeliness;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.icon = [self objectOrNilForKey:kMyTopCategoryListIcon fromDictionary:dict];
            self.isRecommend = [[self objectOrNilForKey:kMyTopCategoryListIsRecommend fromDictionary:dict] doubleValue];
            self.shareType = [[self objectOrNilForKey:kMyTopCategoryListShareType fromDictionary:dict] doubleValue];
            self.isTop = [[self objectOrNilForKey:kMyTopCategoryListIsTop fromDictionary:dict] doubleValue];
            self.myTopCategoryListIdentifier = [[self objectOrNilForKey:kMyTopCategoryListId fromDictionary:dict] doubleValue];
            self.mixWeight = [self objectOrNilForKey:kMyTopCategoryListMixWeight fromDictionary:dict];
            self.iconUrl = [self objectOrNilForKey:kMyTopCategoryListIconUrl fromDictionary:dict];
            self.totalUpdates = [[self objectOrNilForKey:kMyTopCategoryListTotalUpdates fromDictionary:dict] doubleValue];
            self.smallIconUrl = [self objectOrNilForKey:kMyTopCategoryListSmallIconUrl fromDictionary:dict];
            self.isRisk = [[self objectOrNilForKey:kMyTopCategoryListIsRisk fromDictionary:dict] doubleValue];
            self.bigCategoryId = [[self objectOrNilForKey:kMyTopCategoryListBigCategoryId fromDictionary:dict] doubleValue];
            self.topStartTime = [self objectOrNilForKey:kMyTopCategoryListTopStartTime fromDictionary:dict];
            self.type = [[self objectOrNilForKey:kMyTopCategoryListType fromDictionary:dict] doubleValue];
            self.buttons = [self objectOrNilForKey:kMyTopCategoryListButtons fromDictionary:dict];
            self.allowText = [[self objectOrNilForKey:kMyTopCategoryListAllowText fromDictionary:dict] doubleValue];
            self.extra = [Extra modelObjectWithDictionary:[dict objectForKey:kMyTopCategoryListExtra]];
            self.tag = [self objectOrNilForKey:kMyTopCategoryListTag fromDictionary:dict];
            self.intro = [self objectOrNilForKey:kMyTopCategoryListIntro fromDictionary:dict];
            self.priority = [[self objectOrNilForKey:kMyTopCategoryListPriority fromDictionary:dict] doubleValue];
            self.postRuleId = [[self objectOrNilForKey:kMyTopCategoryListPostRuleId fromDictionary:dict] doubleValue];
            self.subscribeCount = [[self objectOrNilForKey:kMyTopCategoryListSubscribeCount fromDictionary:dict] doubleValue];
            self.allowMultiImage = [[self objectOrNilForKey:kMyTopCategoryListAllowMultiImage fromDictionary:dict] doubleValue];
            self.name = [self objectOrNilForKey:kMyTopCategoryListName fromDictionary:dict];
            self.smallIcon = [self objectOrNilForKey:kMyTopCategoryListSmallIcon fromDictionary:dict];
            self.status = [[self objectOrNilForKey:kMyTopCategoryListStatus fromDictionary:dict] doubleValue];
            self.todayUpdates = [[self objectOrNilForKey:kMyTopCategoryListTodayUpdates fromDictionary:dict] doubleValue];
            self.topEndTime = [self objectOrNilForKey:kMyTopCategoryListTopEndTime fromDictionary:dict];
            self.visible = [[self objectOrNilForKey:kMyTopCategoryListVisible fromDictionary:dict] doubleValue];
            self.materialBar = [self objectOrNilForKey:kMyTopCategoryListMaterialBar fromDictionary:dict];
            self.allowGif = [[self objectOrNilForKey:kMyTopCategoryListAllowGif fromDictionary:dict] doubleValue];
            self.allowTextAndPic = [[self objectOrNilForKey:kMyTopCategoryListAllowTextAndPic fromDictionary:dict] doubleValue];
            self.channels = [self objectOrNilForKey:kMyTopCategoryListChannels fromDictionary:dict];
            self.allowVideo = [[self objectOrNilForKey:kMyTopCategoryListAllowVideo fromDictionary:dict] doubleValue];
            self.dedup = [[self objectOrNilForKey:kMyTopCategoryListDedup fromDictionary:dict] doubleValue];
            self.shareUrl = [self objectOrNilForKey:kMyTopCategoryListShareUrl fromDictionary:dict];
            self.placeholder = [self objectOrNilForKey:kMyTopCategoryListPlaceholder fromDictionary:dict];
            self.hasTimeliness = [[self objectOrNilForKey:kMyTopCategoryListHasTimeliness fromDictionary:dict] doubleValue];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.icon forKey:kMyTopCategoryListIcon];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isRecommend] forKey:kMyTopCategoryListIsRecommend];
    [mutableDict setValue:[NSNumber numberWithDouble:self.shareType] forKey:kMyTopCategoryListShareType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isTop] forKey:kMyTopCategoryListIsTop];
    [mutableDict setValue:[NSNumber numberWithDouble:self.myTopCategoryListIdentifier] forKey:kMyTopCategoryListId];
    [mutableDict setValue:self.mixWeight forKey:kMyTopCategoryListMixWeight];
    [mutableDict setValue:self.iconUrl forKey:kMyTopCategoryListIconUrl];
    [mutableDict setValue:[NSNumber numberWithDouble:self.totalUpdates] forKey:kMyTopCategoryListTotalUpdates];
    [mutableDict setValue:self.smallIconUrl forKey:kMyTopCategoryListSmallIconUrl];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isRisk] forKey:kMyTopCategoryListIsRisk];
    [mutableDict setValue:[NSNumber numberWithDouble:self.bigCategoryId] forKey:kMyTopCategoryListBigCategoryId];
    [mutableDict setValue:self.topStartTime forKey:kMyTopCategoryListTopStartTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.type] forKey:kMyTopCategoryListType];
    [mutableDict setValue:self.buttons forKey:kMyTopCategoryListButtons];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowText] forKey:kMyTopCategoryListAllowText];
    [mutableDict setValue:[self.extra dictionaryRepresentation] forKey:kMyTopCategoryListExtra];
    [mutableDict setValue:self.tag forKey:kMyTopCategoryListTag];
    [mutableDict setValue:self.intro forKey:kMyTopCategoryListIntro];
    [mutableDict setValue:[NSNumber numberWithDouble:self.priority] forKey:kMyTopCategoryListPriority];
    [mutableDict setValue:[NSNumber numberWithDouble:self.postRuleId] forKey:kMyTopCategoryListPostRuleId];
    [mutableDict setValue:[NSNumber numberWithDouble:self.subscribeCount] forKey:kMyTopCategoryListSubscribeCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowMultiImage] forKey:kMyTopCategoryListAllowMultiImage];
    [mutableDict setValue:self.name forKey:kMyTopCategoryListName];
    [mutableDict setValue:self.smallIcon forKey:kMyTopCategoryListSmallIcon];
    [mutableDict setValue:[NSNumber numberWithDouble:self.status] forKey:kMyTopCategoryListStatus];
    [mutableDict setValue:[NSNumber numberWithDouble:self.todayUpdates] forKey:kMyTopCategoryListTodayUpdates];
    [mutableDict setValue:self.topEndTime forKey:kMyTopCategoryListTopEndTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.visible] forKey:kMyTopCategoryListVisible];
    NSMutableArray *tempArrayForMaterialBar = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.materialBar) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForMaterialBar addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForMaterialBar addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForMaterialBar] forKey:kMyTopCategoryListMaterialBar];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowGif] forKey:kMyTopCategoryListAllowGif];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowTextAndPic] forKey:kMyTopCategoryListAllowTextAndPic];
    [mutableDict setValue:self.channels forKey:kMyTopCategoryListChannels];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowVideo] forKey:kMyTopCategoryListAllowVideo];
    [mutableDict setValue:[NSNumber numberWithDouble:self.dedup] forKey:kMyTopCategoryListDedup];
    [mutableDict setValue:self.shareUrl forKey:kMyTopCategoryListShareUrl];
    [mutableDict setValue:self.placeholder forKey:kMyTopCategoryListPlaceholder];
    [mutableDict setValue:[NSNumber numberWithDouble:self.hasTimeliness] forKey:kMyTopCategoryListHasTimeliness];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.icon = [aDecoder decodeObjectForKey:kMyTopCategoryListIcon];
    self.isRecommend = [aDecoder decodeDoubleForKey:kMyTopCategoryListIsRecommend];
    self.shareType = [aDecoder decodeDoubleForKey:kMyTopCategoryListShareType];
    self.isTop = [aDecoder decodeDoubleForKey:kMyTopCategoryListIsTop];
    self.myTopCategoryListIdentifier = [aDecoder decodeDoubleForKey:kMyTopCategoryListId];
    self.mixWeight = [aDecoder decodeObjectForKey:kMyTopCategoryListMixWeight];
    self.iconUrl = [aDecoder decodeObjectForKey:kMyTopCategoryListIconUrl];
    self.totalUpdates = [aDecoder decodeDoubleForKey:kMyTopCategoryListTotalUpdates];
    self.smallIconUrl = [aDecoder decodeObjectForKey:kMyTopCategoryListSmallIconUrl];
    self.isRisk = [aDecoder decodeDoubleForKey:kMyTopCategoryListIsRisk];
    self.bigCategoryId = [aDecoder decodeDoubleForKey:kMyTopCategoryListBigCategoryId];
    self.topStartTime = [aDecoder decodeObjectForKey:kMyTopCategoryListTopStartTime];
    self.type = [aDecoder decodeDoubleForKey:kMyTopCategoryListType];
    self.buttons = [aDecoder decodeObjectForKey:kMyTopCategoryListButtons];
    self.allowText = [aDecoder decodeDoubleForKey:kMyTopCategoryListAllowText];
    self.extra = [aDecoder decodeObjectForKey:kMyTopCategoryListExtra];
    self.tag = [aDecoder decodeObjectForKey:kMyTopCategoryListTag];
    self.intro = [aDecoder decodeObjectForKey:kMyTopCategoryListIntro];
    self.priority = [aDecoder decodeDoubleForKey:kMyTopCategoryListPriority];
    self.postRuleId = [aDecoder decodeDoubleForKey:kMyTopCategoryListPostRuleId];
    self.subscribeCount = [aDecoder decodeDoubleForKey:kMyTopCategoryListSubscribeCount];
    self.allowMultiImage = [aDecoder decodeDoubleForKey:kMyTopCategoryListAllowMultiImage];
    self.name = [aDecoder decodeObjectForKey:kMyTopCategoryListName];
    self.smallIcon = [aDecoder decodeObjectForKey:kMyTopCategoryListSmallIcon];
    self.status = [aDecoder decodeDoubleForKey:kMyTopCategoryListStatus];
    self.todayUpdates = [aDecoder decodeDoubleForKey:kMyTopCategoryListTodayUpdates];
    self.topEndTime = [aDecoder decodeObjectForKey:kMyTopCategoryListTopEndTime];
    self.visible = [aDecoder decodeDoubleForKey:kMyTopCategoryListVisible];
    self.materialBar = [aDecoder decodeObjectForKey:kMyTopCategoryListMaterialBar];
    self.allowGif = [aDecoder decodeDoubleForKey:kMyTopCategoryListAllowGif];
    self.allowTextAndPic = [aDecoder decodeDoubleForKey:kMyTopCategoryListAllowTextAndPic];
    self.channels = [aDecoder decodeObjectForKey:kMyTopCategoryListChannels];
    self.allowVideo = [aDecoder decodeDoubleForKey:kMyTopCategoryListAllowVideo];
    self.dedup = [aDecoder decodeDoubleForKey:kMyTopCategoryListDedup];
    self.shareUrl = [aDecoder decodeObjectForKey:kMyTopCategoryListShareUrl];
    self.placeholder = [aDecoder decodeObjectForKey:kMyTopCategoryListPlaceholder];
    self.hasTimeliness = [aDecoder decodeDoubleForKey:kMyTopCategoryListHasTimeliness];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_icon forKey:kMyTopCategoryListIcon];
    [aCoder encodeDouble:_isRecommend forKey:kMyTopCategoryListIsRecommend];
    [aCoder encodeDouble:_shareType forKey:kMyTopCategoryListShareType];
    [aCoder encodeDouble:_isTop forKey:kMyTopCategoryListIsTop];
    [aCoder encodeDouble:_myTopCategoryListIdentifier forKey:kMyTopCategoryListId];
    [aCoder encodeObject:_mixWeight forKey:kMyTopCategoryListMixWeight];
    [aCoder encodeObject:_iconUrl forKey:kMyTopCategoryListIconUrl];
    [aCoder encodeDouble:_totalUpdates forKey:kMyTopCategoryListTotalUpdates];
    [aCoder encodeObject:_smallIconUrl forKey:kMyTopCategoryListSmallIconUrl];
    [aCoder encodeDouble:_isRisk forKey:kMyTopCategoryListIsRisk];
    [aCoder encodeDouble:_bigCategoryId forKey:kMyTopCategoryListBigCategoryId];
    [aCoder encodeObject:_topStartTime forKey:kMyTopCategoryListTopStartTime];
    [aCoder encodeDouble:_type forKey:kMyTopCategoryListType];
    [aCoder encodeObject:_buttons forKey:kMyTopCategoryListButtons];
    [aCoder encodeDouble:_allowText forKey:kMyTopCategoryListAllowText];
    [aCoder encodeObject:_extra forKey:kMyTopCategoryListExtra];
    [aCoder encodeObject:_tag forKey:kMyTopCategoryListTag];
    [aCoder encodeObject:_intro forKey:kMyTopCategoryListIntro];
    [aCoder encodeDouble:_priority forKey:kMyTopCategoryListPriority];
    [aCoder encodeDouble:_postRuleId forKey:kMyTopCategoryListPostRuleId];
    [aCoder encodeDouble:_subscribeCount forKey:kMyTopCategoryListSubscribeCount];
    [aCoder encodeDouble:_allowMultiImage forKey:kMyTopCategoryListAllowMultiImage];
    [aCoder encodeObject:_name forKey:kMyTopCategoryListName];
    [aCoder encodeObject:_smallIcon forKey:kMyTopCategoryListSmallIcon];
    [aCoder encodeDouble:_status forKey:kMyTopCategoryListStatus];
    [aCoder encodeDouble:_todayUpdates forKey:kMyTopCategoryListTodayUpdates];
    [aCoder encodeObject:_topEndTime forKey:kMyTopCategoryListTopEndTime];
    [aCoder encodeDouble:_visible forKey:kMyTopCategoryListVisible];
    [aCoder encodeObject:_materialBar forKey:kMyTopCategoryListMaterialBar];
    [aCoder encodeDouble:_allowGif forKey:kMyTopCategoryListAllowGif];
    [aCoder encodeDouble:_allowTextAndPic forKey:kMyTopCategoryListAllowTextAndPic];
    [aCoder encodeObject:_channels forKey:kMyTopCategoryListChannels];
    [aCoder encodeDouble:_allowVideo forKey:kMyTopCategoryListAllowVideo];
    [aCoder encodeDouble:_dedup forKey:kMyTopCategoryListDedup];
    [aCoder encodeObject:_shareUrl forKey:kMyTopCategoryListShareUrl];
    [aCoder encodeObject:_placeholder forKey:kMyTopCategoryListPlaceholder];
    [aCoder encodeDouble:_hasTimeliness forKey:kMyTopCategoryListHasTimeliness];
}

- (id)copyWithZone:(NSZone *)zone {
    MyTopCategoryList *copy = [[MyTopCategoryList alloc] init];
    
    
    
    if (copy) {

        copy.icon = [self.icon copyWithZone:zone];
        copy.isRecommend = self.isRecommend;
        copy.shareType = self.shareType;
        copy.isTop = self.isTop;
        copy.myTopCategoryListIdentifier = self.myTopCategoryListIdentifier;
        copy.mixWeight = [self.mixWeight copyWithZone:zone];
        copy.iconUrl = [self.iconUrl copyWithZone:zone];
        copy.totalUpdates = self.totalUpdates;
        copy.smallIconUrl = [self.smallIconUrl copyWithZone:zone];
        copy.isRisk = self.isRisk;
        copy.bigCategoryId = self.bigCategoryId;
        copy.topStartTime = [self.topStartTime copyWithZone:zone];
        copy.type = self.type;
        copy.buttons = [self.buttons copyWithZone:zone];
        copy.allowText = self.allowText;
        copy.extra = [self.extra copyWithZone:zone];
        copy.tag = [self.tag copyWithZone:zone];
        copy.intro = [self.intro copyWithZone:zone];
        copy.priority = self.priority;
        copy.postRuleId = self.postRuleId;
        copy.subscribeCount = self.subscribeCount;
        copy.allowMultiImage = self.allowMultiImage;
        copy.name = [self.name copyWithZone:zone];
        copy.smallIcon = [self.smallIcon copyWithZone:zone];
        copy.status = self.status;
        copy.todayUpdates = self.todayUpdates;
        copy.topEndTime = [self.topEndTime copyWithZone:zone];
        copy.visible = self.visible;
        copy.materialBar = [self.materialBar copyWithZone:zone];
        copy.allowGif = self.allowGif;
        copy.allowTextAndPic = self.allowTextAndPic;
        copy.channels = [self.channels copyWithZone:zone];
        copy.allowVideo = self.allowVideo;
        copy.dedup = self.dedup;
        copy.shareUrl = [self.shareUrl copyWithZone:zone];
        copy.placeholder = [self.placeholder copyWithZone:zone];
        copy.hasTimeliness = self.hasTimeliness;
    }
    
    return copy;
}


@end
