//
//  Extra.h
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface Extra : NSObject <NSCoding, NSCopying>

@property (nonatomic, copy) NSString * topEndTime;
@property (nonatomic, strong) NSArray *defaultLabelIds;
@property (nonatomic, strong) NSString *heatHours;
@property (nonatomic, strong) NSArray *labelIds;
@property (nonatomic, assign) BOOL isTop;
@property (nonatomic, copy) NSString * heatStartTime;
@property (nonatomic, copy) NSString * mixWeight;
@property (nonatomic, assign) BOOL needHeat;
@property (nonatomic, strong) NSArray *materialBar;
@property (nonatomic, assign) BOOL hasTimeliness;
@property (nonatomic, copy) NSString * topStartTime;
@property (nonatomic, copy) NSString * heatEndTime;
@property (nonatomic, strong) NSString *heatDays;
@property (nonatomic, assign) BOOL isRisk;
@property (nonatomic, strong) NSArray *bindMaterialBar;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
