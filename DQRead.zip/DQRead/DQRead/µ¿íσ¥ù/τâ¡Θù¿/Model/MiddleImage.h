//
//  MiddleImage.h
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface MiddleImage : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *uri;
@property (nonatomic, assign) double rWidth;
@property (nonatomic, strong) NSArray *urlList;
@property (nonatomic, assign) double height;
@property (nonatomic, assign) double rHeight;
@property (nonatomic, assign) double width;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
