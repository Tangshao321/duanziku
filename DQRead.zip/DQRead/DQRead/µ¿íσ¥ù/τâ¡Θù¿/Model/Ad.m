//
//  Ad.m
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "Ad.h"
#import "LogExtra.h"


NSString *const kAdLogExtra = @"log_extra";
NSString *const kAdSource = @"source";
NSString *const kAdOpenUrl = @"open_url";
NSString *const kAdTitle = @"title";
NSString *const kAdGifUrl = @"gif_url";
NSString *const kAdButtonText = @"button_text";
NSString *const kAdDisplayImageHeight = @"display_image_height";
NSString *const kAdIsAd = @"is_ad";
NSString *const kAdAppleid = @"appleid";
NSString *const kAdTrackUrlList = @"track_url_list";
NSString *const kAdAbShowStyle = @"ab_show_style";
NSString *const kAdAvatarName = @"avatar_name";
NSString *const kAdHideIfExists = @"hide_if_exists";
NSString *const kAdTrackUrl = @"track_url";
NSString *const kAdAvatarUrl = @"avatar_url";
NSString *const kAdWebUrl = @"web_url";
NSString *const kAdDownloadUrl = @"download_url";
NSString *const kAdType = @"type";
NSString *const kAdId = @"id";
NSString *const kAdDisplayInfo = @"display_info";
NSString *const kAdDisplayType = @"display_type";
NSString *const kAdLabel = @"label";
NSString *const kAdDisplayImage = @"display_image";
NSString *const kAdPackage = @"package";
NSString *const kAdEndTime = @"end_time";
NSString *const kAdAdId = @"ad_id";
NSString *const kAdDisplayImageWidth = @"display_image_width";
NSString *const kAdIpaUrl = @"ipa_url";


@interface Ad ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Ad

@synthesize logExtra = _logExtra;
@synthesize source = _source;
@synthesize openUrl = _openUrl;
@synthesize title = _title;
@synthesize gifUrl = _gifUrl;
@synthesize buttonText = _buttonText;
@synthesize displayImageHeight = _displayImageHeight;
@synthesize isAd = _isAd;
@synthesize appleid = _appleid;
@synthesize trackUrlList = _trackUrlList;
@synthesize abShowStyle = _abShowStyle;
@synthesize avatarName = _avatarName;
@synthesize hideIfExists = _hideIfExists;
@synthesize trackUrl = _trackUrl;
@synthesize avatarUrl = _avatarUrl;
@synthesize webUrl = _webUrl;
@synthesize downloadUrl = _downloadUrl;
@synthesize type = _type;
@synthesize adIdentifier = _adIdentifier;
@synthesize displayInfo = _displayInfo;
@synthesize displayType = _displayType;
@synthesize label = _label;
@synthesize displayImage = _displayImage;
@synthesize package = _package;
@synthesize endTime = _endTime;
@synthesize adId = _adId;
@synthesize displayImageWidth = _displayImageWidth;
@synthesize ipaUrl = _ipaUrl;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.logExtra = [LogExtra modelObjectWithDictionary:[dict objectForKey:kAdLogExtra]];
            self.source = [self objectOrNilForKey:kAdSource fromDictionary:dict];
            self.openUrl = [self objectOrNilForKey:kAdOpenUrl fromDictionary:dict];
            self.title = [self objectOrNilForKey:kAdTitle fromDictionary:dict];
            self.gifUrl = [self objectOrNilForKey:kAdGifUrl fromDictionary:dict];
            self.buttonText = [self objectOrNilForKey:kAdButtonText fromDictionary:dict];
            self.displayImageHeight = [[self objectOrNilForKey:kAdDisplayImageHeight fromDictionary:dict] doubleValue];
            self.isAd = [[self objectOrNilForKey:kAdIsAd fromDictionary:dict] doubleValue];
            self.appleid = [self objectOrNilForKey:kAdAppleid fromDictionary:dict];
            self.trackUrlList = [self objectOrNilForKey:kAdTrackUrlList fromDictionary:dict];
            self.abShowStyle = [[self objectOrNilForKey:kAdAbShowStyle fromDictionary:dict] doubleValue];
            self.avatarName = [self objectOrNilForKey:kAdAvatarName fromDictionary:dict];
            self.hideIfExists = [[self objectOrNilForKey:kAdHideIfExists fromDictionary:dict] doubleValue];
            self.trackUrl = [self objectOrNilForKey:kAdTrackUrl fromDictionary:dict];
            self.avatarUrl = [self objectOrNilForKey:kAdAvatarUrl fromDictionary:dict];
            self.webUrl = [self objectOrNilForKey:kAdWebUrl fromDictionary:dict];
            self.downloadUrl = [self objectOrNilForKey:kAdDownloadUrl fromDictionary:dict];
            self.type = [self objectOrNilForKey:kAdType fromDictionary:dict];
            self.adIdentifier = [[self objectOrNilForKey:kAdId fromDictionary:dict] doubleValue];
            self.displayInfo = [self objectOrNilForKey:kAdDisplayInfo fromDictionary:dict];
            self.displayType = [[self objectOrNilForKey:kAdDisplayType fromDictionary:dict] doubleValue];
            self.label = [self objectOrNilForKey:kAdLabel fromDictionary:dict];
            self.displayImage = [self objectOrNilForKey:kAdDisplayImage fromDictionary:dict];
            self.package = [self objectOrNilForKey:kAdPackage fromDictionary:dict];
            self.endTime = [[self objectOrNilForKey:kAdEndTime fromDictionary:dict] doubleValue];
            self.adId = [[self objectOrNilForKey:kAdAdId fromDictionary:dict] doubleValue];
            self.displayImageWidth = [[self objectOrNilForKey:kAdDisplayImageWidth fromDictionary:dict] doubleValue];
            self.ipaUrl = [self objectOrNilForKey:kAdIpaUrl fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[self.logExtra dictionaryRepresentation] forKey:kAdLogExtra];
    [mutableDict setValue:self.source forKey:kAdSource];
    [mutableDict setValue:self.openUrl forKey:kAdOpenUrl];
    [mutableDict setValue:self.title forKey:kAdTitle];
    [mutableDict setValue:self.gifUrl forKey:kAdGifUrl];
    [mutableDict setValue:self.buttonText forKey:kAdButtonText];
    [mutableDict setValue:[NSNumber numberWithDouble:self.displayImageHeight] forKey:kAdDisplayImageHeight];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isAd] forKey:kAdIsAd];
    [mutableDict setValue:self.appleid forKey:kAdAppleid];
    NSMutableArray *tempArrayForTrackUrlList = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.trackUrlList) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForTrackUrlList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForTrackUrlList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForTrackUrlList] forKey:kAdTrackUrlList];
    [mutableDict setValue:[NSNumber numberWithDouble:self.abShowStyle] forKey:kAdAbShowStyle];
    [mutableDict setValue:self.avatarName forKey:kAdAvatarName];
    [mutableDict setValue:[NSNumber numberWithDouble:self.hideIfExists] forKey:kAdHideIfExists];
    [mutableDict setValue:self.trackUrl forKey:kAdTrackUrl];
    [mutableDict setValue:self.avatarUrl forKey:kAdAvatarUrl];
    [mutableDict setValue:self.webUrl forKey:kAdWebUrl];
    [mutableDict setValue:self.downloadUrl forKey:kAdDownloadUrl];
    [mutableDict setValue:self.type forKey:kAdType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.adIdentifier] forKey:kAdId];
    [mutableDict setValue:self.displayInfo forKey:kAdDisplayInfo];
    [mutableDict setValue:[NSNumber numberWithDouble:self.displayType] forKey:kAdDisplayType];
    [mutableDict setValue:self.label forKey:kAdLabel];
    [mutableDict setValue:self.displayImage forKey:kAdDisplayImage];
    [mutableDict setValue:self.package forKey:kAdPackage];
    [mutableDict setValue:[NSNumber numberWithDouble:self.endTime] forKey:kAdEndTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.adId] forKey:kAdAdId];
    [mutableDict setValue:[NSNumber numberWithDouble:self.displayImageWidth] forKey:kAdDisplayImageWidth];
    [mutableDict setValue:self.ipaUrl forKey:kAdIpaUrl];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.logExtra = [aDecoder decodeObjectForKey:kAdLogExtra];
    self.source = [aDecoder decodeObjectForKey:kAdSource];
    self.openUrl = [aDecoder decodeObjectForKey:kAdOpenUrl];
    self.title = [aDecoder decodeObjectForKey:kAdTitle];
    self.gifUrl = [aDecoder decodeObjectForKey:kAdGifUrl];
    self.buttonText = [aDecoder decodeObjectForKey:kAdButtonText];
    self.displayImageHeight = [aDecoder decodeDoubleForKey:kAdDisplayImageHeight];
    self.isAd = [aDecoder decodeDoubleForKey:kAdIsAd];
    self.appleid = [aDecoder decodeObjectForKey:kAdAppleid];
    self.trackUrlList = [aDecoder decodeObjectForKey:kAdTrackUrlList];
    self.abShowStyle = [aDecoder decodeDoubleForKey:kAdAbShowStyle];
    self.avatarName = [aDecoder decodeObjectForKey:kAdAvatarName];
    self.hideIfExists = [aDecoder decodeDoubleForKey:kAdHideIfExists];
    self.trackUrl = [aDecoder decodeObjectForKey:kAdTrackUrl];
    self.avatarUrl = [aDecoder decodeObjectForKey:kAdAvatarUrl];
    self.webUrl = [aDecoder decodeObjectForKey:kAdWebUrl];
    self.downloadUrl = [aDecoder decodeObjectForKey:kAdDownloadUrl];
    self.type = [aDecoder decodeObjectForKey:kAdType];
    self.adIdentifier = [aDecoder decodeDoubleForKey:kAdId];
    self.displayInfo = [aDecoder decodeObjectForKey:kAdDisplayInfo];
    self.displayType = [aDecoder decodeDoubleForKey:kAdDisplayType];
    self.label = [aDecoder decodeObjectForKey:kAdLabel];
    self.displayImage = [aDecoder decodeObjectForKey:kAdDisplayImage];
    self.package = [aDecoder decodeObjectForKey:kAdPackage];
    self.endTime = [aDecoder decodeDoubleForKey:kAdEndTime];
    self.adId = [aDecoder decodeDoubleForKey:kAdAdId];
    self.displayImageWidth = [aDecoder decodeDoubleForKey:kAdDisplayImageWidth];
    self.ipaUrl = [aDecoder decodeObjectForKey:kAdIpaUrl];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_logExtra forKey:kAdLogExtra];
    [aCoder encodeObject:_source forKey:kAdSource];
    [aCoder encodeObject:_openUrl forKey:kAdOpenUrl];
    [aCoder encodeObject:_title forKey:kAdTitle];
    [aCoder encodeObject:_gifUrl forKey:kAdGifUrl];
    [aCoder encodeObject:_buttonText forKey:kAdButtonText];
    [aCoder encodeDouble:_displayImageHeight forKey:kAdDisplayImageHeight];
    [aCoder encodeDouble:_isAd forKey:kAdIsAd];
    [aCoder encodeObject:_appleid forKey:kAdAppleid];
    [aCoder encodeObject:_trackUrlList forKey:kAdTrackUrlList];
    [aCoder encodeDouble:_abShowStyle forKey:kAdAbShowStyle];
    [aCoder encodeObject:_avatarName forKey:kAdAvatarName];
    [aCoder encodeDouble:_hideIfExists forKey:kAdHideIfExists];
    [aCoder encodeObject:_trackUrl forKey:kAdTrackUrl];
    [aCoder encodeObject:_avatarUrl forKey:kAdAvatarUrl];
    [aCoder encodeObject:_webUrl forKey:kAdWebUrl];
    [aCoder encodeObject:_downloadUrl forKey:kAdDownloadUrl];
    [aCoder encodeObject:_type forKey:kAdType];
    [aCoder encodeDouble:_adIdentifier forKey:kAdId];
    [aCoder encodeObject:_displayInfo forKey:kAdDisplayInfo];
    [aCoder encodeDouble:_displayType forKey:kAdDisplayType];
    [aCoder encodeObject:_label forKey:kAdLabel];
    [aCoder encodeObject:_displayImage forKey:kAdDisplayImage];
    [aCoder encodeObject:_package forKey:kAdPackage];
    [aCoder encodeDouble:_endTime forKey:kAdEndTime];
    [aCoder encodeDouble:_adId forKey:kAdAdId];
    [aCoder encodeDouble:_displayImageWidth forKey:kAdDisplayImageWidth];
    [aCoder encodeObject:_ipaUrl forKey:kAdIpaUrl];
}

- (id)copyWithZone:(NSZone *)zone {
    Ad *copy = [[Ad alloc] init];
    
    
    
    if (copy) {

        copy.logExtra = [self.logExtra copyWithZone:zone];
        copy.source = [self.source copyWithZone:zone];
        copy.openUrl = [self.openUrl copyWithZone:zone];
        copy.title = [self.title copyWithZone:zone];
        copy.gifUrl = [self.gifUrl copyWithZone:zone];
        copy.buttonText = [self.buttonText copyWithZone:zone];
        copy.displayImageHeight = self.displayImageHeight;
        copy.isAd = self.isAd;
        copy.appleid = [self.appleid copyWithZone:zone];
        copy.trackUrlList = [self.trackUrlList copyWithZone:zone];
        copy.abShowStyle = self.abShowStyle;
        copy.avatarName = [self.avatarName copyWithZone:zone];
        copy.hideIfExists = self.hideIfExists;
        copy.trackUrl = [self.trackUrl copyWithZone:zone];
        copy.avatarUrl = [self.avatarUrl copyWithZone:zone];
        copy.webUrl = [self.webUrl copyWithZone:zone];
        copy.downloadUrl = [self.downloadUrl copyWithZone:zone];
        copy.type = [self.type copyWithZone:zone];
        copy.adIdentifier = self.adIdentifier;
        copy.displayInfo = [self.displayInfo copyWithZone:zone];
        copy.displayType = self.displayType;
        copy.label = [self.label copyWithZone:zone];
        copy.displayImage = [self.displayImage copyWithZone:zone];
        copy.package = [self.package copyWithZone:zone];
        copy.endTime = self.endTime;
        copy.adId = self.adId;
        copy.displayImageWidth = self.displayImageWidth;
        copy.ipaUrl = [self.ipaUrl copyWithZone:zone];
    }
    
    return copy;
}


@end
