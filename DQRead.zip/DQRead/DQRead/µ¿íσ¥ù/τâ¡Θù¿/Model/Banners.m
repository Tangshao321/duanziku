//
//  Banners.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "Banners.h"
#import "BannerUrl.h"


NSString *const kBannersSchemaUrl = @"schema_url";
NSString *const kBannersTargetUsers = @"target_users";
NSString *const kBannersBannerUrl = @"banner_url";


@interface Banners ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Banners

@synthesize schemaUrl = _schemaUrl;
@synthesize targetUsers = _targetUsers;
@synthesize bannerUrl = _bannerUrl;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.schemaUrl = [self objectOrNilForKey:kBannersSchemaUrl fromDictionary:dict];
            self.targetUsers = [self objectOrNilForKey:kBannersTargetUsers fromDictionary:dict];
            self.bannerUrl = [BannerUrl modelObjectWithDictionary:[dict objectForKey:kBannersBannerUrl]];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.schemaUrl forKey:kBannersSchemaUrl];
    NSMutableArray *tempArrayForTargetUsers = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.targetUsers) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForTargetUsers addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForTargetUsers addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForTargetUsers] forKey:kBannersTargetUsers];
    [mutableDict setValue:[self.bannerUrl dictionaryRepresentation] forKey:kBannersBannerUrl];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.schemaUrl = [aDecoder decodeObjectForKey:kBannersSchemaUrl];
    self.targetUsers = [aDecoder decodeObjectForKey:kBannersTargetUsers];
    self.bannerUrl = [aDecoder decodeObjectForKey:kBannersBannerUrl];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_schemaUrl forKey:kBannersSchemaUrl];
    [aCoder encodeObject:_targetUsers forKey:kBannersTargetUsers];
    [aCoder encodeObject:_bannerUrl forKey:kBannersBannerUrl];
}

- (id)copyWithZone:(NSZone *)zone {
    Banners *copy = [[Banners alloc] init];
    
    
    
    if (copy) {

        copy.schemaUrl = [self.schemaUrl copyWithZone:zone];
        copy.targetUsers = [self.targetUsers copyWithZone:zone];
        copy.bannerUrl = [self.bannerUrl copyWithZone:zone];
    }
    
    return copy;
}


@end
