//
//  User.m
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "User.h"


NSString *const kUserUserVerified = @"user_verified";
NSString *const kUserUgcCount = @"ugc_count";
NSString *const kUserIsFollowing = @"is_following";
NSString *const kUserFollowers = @"followers";
NSString *const kUserFollowings = @"followings";
NSString *const kUserIsProUser = @"is_pro_user";
NSString *const kUserUserId = @"user_id";
NSString *const kUserName = @"name";
NSString *const kUserAvatarUrl = @"avatar_url";


@interface User ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation User

@synthesize userVerified = _userVerified;
@synthesize ugcCount = _ugcCount;
@synthesize isFollowing = _isFollowing;
@synthesize followers = _followers;
@synthesize followings = _followings;
@synthesize isProUser = _isProUser;
@synthesize userId = _userId;
@synthesize name = _name;
@synthesize avatarUrl = _avatarUrl;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.userVerified = [[self objectOrNilForKey:kUserUserVerified fromDictionary:dict] doubleValue];
            self.ugcCount = [[self objectOrNilForKey:kUserUgcCount fromDictionary:dict] doubleValue];
            self.isFollowing = [[self objectOrNilForKey:kUserIsFollowing fromDictionary:dict] doubleValue];
            self.followers = [[self objectOrNilForKey:kUserFollowers fromDictionary:dict] doubleValue];
            self.followings = [[self objectOrNilForKey:kUserFollowings fromDictionary:dict] doubleValue];
            self.isProUser = [[self objectOrNilForKey:kUserIsProUser fromDictionary:dict] doubleValue];
            self.userId = [[self objectOrNilForKey:kUserUserId fromDictionary:dict] doubleValue];
            self.name = [self objectOrNilForKey:kUserName fromDictionary:dict];
            self.avatarUrl = [self objectOrNilForKey:kUserAvatarUrl fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[NSNumber numberWithDouble:self.userVerified] forKey:kUserUserVerified];
    [mutableDict setValue:[NSNumber numberWithDouble:self.ugcCount] forKey:kUserUgcCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isFollowing] forKey:kUserIsFollowing];
    [mutableDict setValue:[NSNumber numberWithDouble:self.followers] forKey:kUserFollowers];
    [mutableDict setValue:[NSNumber numberWithDouble:self.followings] forKey:kUserFollowings];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isProUser] forKey:kUserIsProUser];
    [mutableDict setValue:[NSNumber numberWithDouble:self.userId] forKey:kUserUserId];
    [mutableDict setValue:self.name forKey:kUserName];
    [mutableDict setValue:self.avatarUrl forKey:kUserAvatarUrl];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.userVerified = [aDecoder decodeDoubleForKey:kUserUserVerified];
    self.ugcCount = [aDecoder decodeDoubleForKey:kUserUgcCount];
    self.isFollowing = [aDecoder decodeDoubleForKey:kUserIsFollowing];
    self.followers = [aDecoder decodeDoubleForKey:kUserFollowers];
    self.followings = [aDecoder decodeDoubleForKey:kUserFollowings];
    self.isProUser = [aDecoder decodeDoubleForKey:kUserIsProUser];
    self.userId = [aDecoder decodeDoubleForKey:kUserUserId];
    self.name = [aDecoder decodeObjectForKey:kUserName];
    self.avatarUrl = [aDecoder decodeObjectForKey:kUserAvatarUrl];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeDouble:_userVerified forKey:kUserUserVerified];
    [aCoder encodeDouble:_ugcCount forKey:kUserUgcCount];
    [aCoder encodeDouble:_isFollowing forKey:kUserIsFollowing];
    [aCoder encodeDouble:_followers forKey:kUserFollowers];
    [aCoder encodeDouble:_followings forKey:kUserFollowings];
    [aCoder encodeDouble:_isProUser forKey:kUserIsProUser];
    [aCoder encodeDouble:_userId forKey:kUserUserId];
    [aCoder encodeObject:_name forKey:kUserName];
    [aCoder encodeObject:_avatarUrl forKey:kUserAvatarUrl];
}

- (id)copyWithZone:(NSZone *)zone {
    User *copy = [[User alloc] init];
    
    
    
    if (copy) {

        copy.userVerified = self.userVerified;
        copy.ugcCount = self.ugcCount;
        copy.isFollowing = self.isFollowing;
        copy.followers = self.followers;
        copy.followings = self.followings;
        copy.isProUser = self.isProUser;
        copy.userId = self.userId;
        copy.name = [self.name copyWithZone:zone];
        copy.avatarUrl = [self.avatarUrl copyWithZone:zone];
    }
    
    return copy;
}


@end
