//
//  TakeList.h
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TakeList : NSObject

//  订阅表名
//  数据表的表名
@property (nonatomic ,strong) NSString  *tableCLassName;
//   数据的表的列名
@property (nonatomic ,strong) NSString *keyObjectId;
@property (nonatomic ,strong) NSString *keyUserTakeId;
@property (nonatomic ,strong) NSString *keyUserTakeCategoryList;
@property (nonatomic ,strong) NSString *keyCreateAt;
@property (nonatomic ,strong) NSString *keyCategoryId;



//  单例
+ (instancetype)sharedTakeList;
@end
