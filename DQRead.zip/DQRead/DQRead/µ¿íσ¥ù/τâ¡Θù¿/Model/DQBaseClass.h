//
//  BaseClass.h
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class RotateBanner, Categories, GodComment;

@interface DQBaseClass : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSArray *myTopCategoryList;
@property (nonatomic, strong) RotateBanner *rotateBanner;
@property (nonatomic, strong) Categories *categories;
@property (nonatomic, strong) GodComment *godComment;
@property (nonatomic, strong) NSArray *myCategoryList;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
