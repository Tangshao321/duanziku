//
//  MyCategoryList.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "MyCategoryList.h"
#import "Extra.h"


NSString *const kMyCategoryListIcon = @"icon";
NSString *const kMyCategoryListIsRecommend = @"is_recommend";
NSString *const kMyCategoryListShareType = @"share_type";
NSString *const kMyCategoryListIsTop = @"is_top";
NSString *const kMyCategoryListId = @"id";
NSString *const kMyCategoryListMixWeight = @"mix_weight";
NSString *const kMyCategoryListIconUrl = @"icon_url";
NSString *const kMyCategoryListTotalUpdates = @"total_updates";
NSString *const kMyCategoryListSmallIconUrl = @"small_icon_url";
NSString *const kMyCategoryListIsRisk = @"is_risk";
NSString *const kMyCategoryListBigCategoryId = @"big_category_id";
NSString *const kMyCategoryListTopStartTime = @"top_start_time";
NSString *const kMyCategoryListType = @"type";
NSString *const kMyCategoryListButtons = @"buttons";
NSString *const kMyCategoryListAllowText = @"allow_text";
NSString *const kMyCategoryListExtra = @"extra";
NSString *const kMyCategoryListTag = @"tag";
NSString *const kMyCategoryListIntro = @"intro";
NSString *const kMyCategoryListPriority = @"priority";
NSString *const kMyCategoryListPostRuleId = @"post_rule_id";
NSString *const kMyCategoryListSubscribeCount = @"subscribe_count";
NSString *const kMyCategoryListAllowMultiImage = @"allow_multi_image";
NSString *const kMyCategoryListName = @"name";
NSString *const kMyCategoryListSmallIcon = @"small_icon";
NSString *const kMyCategoryListStatus = @"status";
NSString *const kMyCategoryListTodayUpdates = @"today_updates";
NSString *const kMyCategoryListTopEndTime = @"top_end_time";
NSString *const kMyCategoryListVisible = @"visible";
NSString *const kMyCategoryListMaterialBar = @"material_bar";
NSString *const kMyCategoryListAllowGif = @"allow_gif";
NSString *const kMyCategoryListAllowTextAndPic = @"allow_text_and_pic";
NSString *const kMyCategoryListChannels = @"channels";
NSString *const kMyCategoryListAllowVideo = @"allow_video";
NSString *const kMyCategoryListDedup = @"dedup";
NSString *const kMyCategoryListShareUrl = @"share_url";
NSString *const kMyCategoryListPlaceholder = @"placeholder";
NSString *const kMyCategoryListHasTimeliness = @"has_timeliness";


@interface MyCategoryList ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation MyCategoryList

@synthesize icon = _icon;
@synthesize isRecommend = _isRecommend;
@synthesize shareType = _shareType;
@synthesize isTop = _isTop;
@synthesize myCategoryListIdentifier = _myCategoryListIdentifier;
@synthesize mixWeight = _mixWeight;
@synthesize iconUrl = _iconUrl;
@synthesize totalUpdates = _totalUpdates;
@synthesize smallIconUrl = _smallIconUrl;
@synthesize isRisk = _isRisk;
@synthesize bigCategoryId = _bigCategoryId;
@synthesize topStartTime = _topStartTime;
@synthesize type = _type;
@synthesize buttons = _buttons;
@synthesize allowText = _allowText;
@synthesize extra = _extra;
@synthesize tag = _tag;
@synthesize intro = _intro;
@synthesize priority = _priority;
@synthesize postRuleId = _postRuleId;
@synthesize subscribeCount = _subscribeCount;
@synthesize allowMultiImage = _allowMultiImage;
@synthesize name = _name;
@synthesize smallIcon = _smallIcon;
@synthesize status = _status;
@synthesize todayUpdates = _todayUpdates;
@synthesize topEndTime = _topEndTime;
@synthesize visible = _visible;
@synthesize materialBar = _materialBar;
@synthesize allowGif = _allowGif;
@synthesize allowTextAndPic = _allowTextAndPic;
@synthesize channels = _channels;
@synthesize allowVideo = _allowVideo;
@synthesize dedup = _dedup;
@synthesize shareUrl = _shareUrl;
@synthesize placeholder = _placeholder;
@synthesize hasTimeliness = _hasTimeliness;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.icon = [self objectOrNilForKey:kMyCategoryListIcon fromDictionary:dict];
            self.isRecommend = [[self objectOrNilForKey:kMyCategoryListIsRecommend fromDictionary:dict] doubleValue];
            self.shareType = [[self objectOrNilForKey:kMyCategoryListShareType fromDictionary:dict] doubleValue];
            self.isTop = [[self objectOrNilForKey:kMyCategoryListIsTop fromDictionary:dict] doubleValue];
            self.myCategoryListIdentifier = [[self objectOrNilForKey:kMyCategoryListId fromDictionary:dict] doubleValue];
            self.mixWeight = [self objectOrNilForKey:kMyCategoryListMixWeight fromDictionary:dict];
            self.iconUrl = [self objectOrNilForKey:kMyCategoryListIconUrl fromDictionary:dict];
            self.totalUpdates = [[self objectOrNilForKey:kMyCategoryListTotalUpdates fromDictionary:dict] doubleValue];
            self.smallIconUrl = [self objectOrNilForKey:kMyCategoryListSmallIconUrl fromDictionary:dict];
            self.isRisk = [[self objectOrNilForKey:kMyCategoryListIsRisk fromDictionary:dict] doubleValue];
            self.bigCategoryId = [[self objectOrNilForKey:kMyCategoryListBigCategoryId fromDictionary:dict] doubleValue];
            self.topStartTime = [self objectOrNilForKey:kMyCategoryListTopStartTime fromDictionary:dict];
            self.type = [[self objectOrNilForKey:kMyCategoryListType fromDictionary:dict] doubleValue];
            self.buttons = [self objectOrNilForKey:kMyCategoryListButtons fromDictionary:dict];
            self.allowText = [[self objectOrNilForKey:kMyCategoryListAllowText fromDictionary:dict] doubleValue];
            self.extra = [Extra modelObjectWithDictionary:[dict objectForKey:kMyCategoryListExtra]];
            self.tag = [self objectOrNilForKey:kMyCategoryListTag fromDictionary:dict];
            self.intro = [self objectOrNilForKey:kMyCategoryListIntro fromDictionary:dict];
            self.priority = [[self objectOrNilForKey:kMyCategoryListPriority fromDictionary:dict] doubleValue];
            self.postRuleId = [[self objectOrNilForKey:kMyCategoryListPostRuleId fromDictionary:dict] doubleValue];
            self.subscribeCount = [[self objectOrNilForKey:kMyCategoryListSubscribeCount fromDictionary:dict] doubleValue];
            self.allowMultiImage = [[self objectOrNilForKey:kMyCategoryListAllowMultiImage fromDictionary:dict] doubleValue];
            self.name = [self objectOrNilForKey:kMyCategoryListName fromDictionary:dict];
            self.smallIcon = [self objectOrNilForKey:kMyCategoryListSmallIcon fromDictionary:dict];
            self.status = [[self objectOrNilForKey:kMyCategoryListStatus fromDictionary:dict] doubleValue];
            self.todayUpdates = [[self objectOrNilForKey:kMyCategoryListTodayUpdates fromDictionary:dict] doubleValue];
            self.topEndTime = [self objectOrNilForKey:kMyCategoryListTopEndTime fromDictionary:dict];
            self.visible = [[self objectOrNilForKey:kMyCategoryListVisible fromDictionary:dict] doubleValue];
            self.materialBar = [self objectOrNilForKey:kMyCategoryListMaterialBar fromDictionary:dict];
            self.allowGif = [[self objectOrNilForKey:kMyCategoryListAllowGif fromDictionary:dict] doubleValue];
            self.allowTextAndPic = [[self objectOrNilForKey:kMyCategoryListAllowTextAndPic fromDictionary:dict] doubleValue];
            self.channels = [self objectOrNilForKey:kMyCategoryListChannels fromDictionary:dict];
            self.allowVideo = [[self objectOrNilForKey:kMyCategoryListAllowVideo fromDictionary:dict] doubleValue];
            self.dedup = [[self objectOrNilForKey:kMyCategoryListDedup fromDictionary:dict] doubleValue];
            self.shareUrl = [self objectOrNilForKey:kMyCategoryListShareUrl fromDictionary:dict];
            self.placeholder = [self objectOrNilForKey:kMyCategoryListPlaceholder fromDictionary:dict];
            self.hasTimeliness = [[self objectOrNilForKey:kMyCategoryListHasTimeliness fromDictionary:dict] doubleValue];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.icon forKey:kMyCategoryListIcon];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isRecommend] forKey:kMyCategoryListIsRecommend];
    [mutableDict setValue:[NSNumber numberWithDouble:self.shareType] forKey:kMyCategoryListShareType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isTop] forKey:kMyCategoryListIsTop];
    [mutableDict setValue:[NSNumber numberWithDouble:self.myCategoryListIdentifier] forKey:kMyCategoryListId];
    [mutableDict setValue:self.mixWeight forKey:kMyCategoryListMixWeight];
    [mutableDict setValue:self.iconUrl forKey:kMyCategoryListIconUrl];
    [mutableDict setValue:[NSNumber numberWithDouble:self.totalUpdates] forKey:kMyCategoryListTotalUpdates];
    [mutableDict setValue:self.smallIconUrl forKey:kMyCategoryListSmallIconUrl];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isRisk] forKey:kMyCategoryListIsRisk];
    [mutableDict setValue:[NSNumber numberWithDouble:self.bigCategoryId] forKey:kMyCategoryListBigCategoryId];
    [mutableDict setValue:self.topStartTime forKey:kMyCategoryListTopStartTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.type] forKey:kMyCategoryListType];
    [mutableDict setValue:self.buttons forKey:kMyCategoryListButtons];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowText] forKey:kMyCategoryListAllowText];
    [mutableDict setValue:[self.extra dictionaryRepresentation] forKey:kMyCategoryListExtra];
    [mutableDict setValue:self.tag forKey:kMyCategoryListTag];
    [mutableDict setValue:self.intro forKey:kMyCategoryListIntro];
    [mutableDict setValue:[NSNumber numberWithDouble:self.priority] forKey:kMyCategoryListPriority];
    [mutableDict setValue:[NSNumber numberWithDouble:self.postRuleId] forKey:kMyCategoryListPostRuleId];
    [mutableDict setValue:[NSNumber numberWithDouble:self.subscribeCount] forKey:kMyCategoryListSubscribeCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowMultiImage] forKey:kMyCategoryListAllowMultiImage];
    [mutableDict setValue:self.name forKey:kMyCategoryListName];
    [mutableDict setValue:self.smallIcon forKey:kMyCategoryListSmallIcon];
    [mutableDict setValue:[NSNumber numberWithDouble:self.status] forKey:kMyCategoryListStatus];
    [mutableDict setValue:[NSNumber numberWithDouble:self.todayUpdates] forKey:kMyCategoryListTodayUpdates];
    [mutableDict setValue:self.topEndTime forKey:kMyCategoryListTopEndTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.visible] forKey:kMyCategoryListVisible];
    NSMutableArray *tempArrayForMaterialBar = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.materialBar) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForMaterialBar addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForMaterialBar addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForMaterialBar] forKey:kMyCategoryListMaterialBar];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowGif] forKey:kMyCategoryListAllowGif];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowTextAndPic] forKey:kMyCategoryListAllowTextAndPic];
    [mutableDict setValue:self.channels forKey:kMyCategoryListChannels];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowVideo] forKey:kMyCategoryListAllowVideo];
    [mutableDict setValue:[NSNumber numberWithDouble:self.dedup] forKey:kMyCategoryListDedup];
    [mutableDict setValue:self.shareUrl forKey:kMyCategoryListShareUrl];
    [mutableDict setValue:self.placeholder forKey:kMyCategoryListPlaceholder];
    [mutableDict setValue:[NSNumber numberWithDouble:self.hasTimeliness] forKey:kMyCategoryListHasTimeliness];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.icon = [aDecoder decodeObjectForKey:kMyCategoryListIcon];
    self.isRecommend = [aDecoder decodeDoubleForKey:kMyCategoryListIsRecommend];
    self.shareType = [aDecoder decodeDoubleForKey:kMyCategoryListShareType];
    self.isTop = [aDecoder decodeDoubleForKey:kMyCategoryListIsTop];
    self.myCategoryListIdentifier = [aDecoder decodeDoubleForKey:kMyCategoryListId];
    self.mixWeight = [aDecoder decodeObjectForKey:kMyCategoryListMixWeight];
    self.iconUrl = [aDecoder decodeObjectForKey:kMyCategoryListIconUrl];
    self.totalUpdates = [aDecoder decodeDoubleForKey:kMyCategoryListTotalUpdates];
    self.smallIconUrl = [aDecoder decodeObjectForKey:kMyCategoryListSmallIconUrl];
    self.isRisk = [aDecoder decodeDoubleForKey:kMyCategoryListIsRisk];
    self.bigCategoryId = [aDecoder decodeDoubleForKey:kMyCategoryListBigCategoryId];
    self.topStartTime = [aDecoder decodeObjectForKey:kMyCategoryListTopStartTime];
    self.type = [aDecoder decodeDoubleForKey:kMyCategoryListType];
    self.buttons = [aDecoder decodeObjectForKey:kMyCategoryListButtons];
    self.allowText = [aDecoder decodeDoubleForKey:kMyCategoryListAllowText];
    self.extra = [aDecoder decodeObjectForKey:kMyCategoryListExtra];
    self.tag = [aDecoder decodeObjectForKey:kMyCategoryListTag];
    self.intro = [aDecoder decodeObjectForKey:kMyCategoryListIntro];
    self.priority = [aDecoder decodeDoubleForKey:kMyCategoryListPriority];
    self.postRuleId = [aDecoder decodeDoubleForKey:kMyCategoryListPostRuleId];
    self.subscribeCount = [aDecoder decodeDoubleForKey:kMyCategoryListSubscribeCount];
    self.allowMultiImage = [aDecoder decodeDoubleForKey:kMyCategoryListAllowMultiImage];
    self.name = [aDecoder decodeObjectForKey:kMyCategoryListName];
    self.smallIcon = [aDecoder decodeObjectForKey:kMyCategoryListSmallIcon];
    self.status = [aDecoder decodeDoubleForKey:kMyCategoryListStatus];
    self.todayUpdates = [aDecoder decodeDoubleForKey:kMyCategoryListTodayUpdates];
    self.topEndTime = [aDecoder decodeObjectForKey:kMyCategoryListTopEndTime];
    self.visible = [aDecoder decodeDoubleForKey:kMyCategoryListVisible];
    self.materialBar = [aDecoder decodeObjectForKey:kMyCategoryListMaterialBar];
    self.allowGif = [aDecoder decodeDoubleForKey:kMyCategoryListAllowGif];
    self.allowTextAndPic = [aDecoder decodeDoubleForKey:kMyCategoryListAllowTextAndPic];
    self.channels = [aDecoder decodeObjectForKey:kMyCategoryListChannels];
    self.allowVideo = [aDecoder decodeDoubleForKey:kMyCategoryListAllowVideo];
    self.dedup = [aDecoder decodeDoubleForKey:kMyCategoryListDedup];
    self.shareUrl = [aDecoder decodeObjectForKey:kMyCategoryListShareUrl];
    self.placeholder = [aDecoder decodeObjectForKey:kMyCategoryListPlaceholder];
    self.hasTimeliness = [aDecoder decodeDoubleForKey:kMyCategoryListHasTimeliness];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_icon forKey:kMyCategoryListIcon];
    [aCoder encodeDouble:_isRecommend forKey:kMyCategoryListIsRecommend];
    [aCoder encodeDouble:_shareType forKey:kMyCategoryListShareType];
    [aCoder encodeDouble:_isTop forKey:kMyCategoryListIsTop];
    [aCoder encodeDouble:_myCategoryListIdentifier forKey:kMyCategoryListId];
    [aCoder encodeObject:_mixWeight forKey:kMyCategoryListMixWeight];
    [aCoder encodeObject:_iconUrl forKey:kMyCategoryListIconUrl];
    [aCoder encodeDouble:_totalUpdates forKey:kMyCategoryListTotalUpdates];
    [aCoder encodeObject:_smallIconUrl forKey:kMyCategoryListSmallIconUrl];
    [aCoder encodeDouble:_isRisk forKey:kMyCategoryListIsRisk];
    [aCoder encodeDouble:_bigCategoryId forKey:kMyCategoryListBigCategoryId];
    [aCoder encodeObject:_topStartTime forKey:kMyCategoryListTopStartTime];
    [aCoder encodeDouble:_type forKey:kMyCategoryListType];
    [aCoder encodeObject:_buttons forKey:kMyCategoryListButtons];
    [aCoder encodeDouble:_allowText forKey:kMyCategoryListAllowText];
    [aCoder encodeObject:_extra forKey:kMyCategoryListExtra];
    [aCoder encodeObject:_tag forKey:kMyCategoryListTag];
    [aCoder encodeObject:_intro forKey:kMyCategoryListIntro];
    [aCoder encodeDouble:_priority forKey:kMyCategoryListPriority];
    [aCoder encodeDouble:_postRuleId forKey:kMyCategoryListPostRuleId];
    [aCoder encodeDouble:_subscribeCount forKey:kMyCategoryListSubscribeCount];
    [aCoder encodeDouble:_allowMultiImage forKey:kMyCategoryListAllowMultiImage];
    [aCoder encodeObject:_name forKey:kMyCategoryListName];
    [aCoder encodeObject:_smallIcon forKey:kMyCategoryListSmallIcon];
    [aCoder encodeDouble:_status forKey:kMyCategoryListStatus];
    [aCoder encodeDouble:_todayUpdates forKey:kMyCategoryListTodayUpdates];
    [aCoder encodeObject:_topEndTime forKey:kMyCategoryListTopEndTime];
    [aCoder encodeDouble:_visible forKey:kMyCategoryListVisible];
    [aCoder encodeObject:_materialBar forKey:kMyCategoryListMaterialBar];
    [aCoder encodeDouble:_allowGif forKey:kMyCategoryListAllowGif];
    [aCoder encodeDouble:_allowTextAndPic forKey:kMyCategoryListAllowTextAndPic];
    [aCoder encodeObject:_channels forKey:kMyCategoryListChannels];
    [aCoder encodeDouble:_allowVideo forKey:kMyCategoryListAllowVideo];
    [aCoder encodeDouble:_dedup forKey:kMyCategoryListDedup];
    [aCoder encodeObject:_shareUrl forKey:kMyCategoryListShareUrl];
    [aCoder encodeObject:_placeholder forKey:kMyCategoryListPlaceholder];
    [aCoder encodeDouble:_hasTimeliness forKey:kMyCategoryListHasTimeliness];
}

- (id)copyWithZone:(NSZone *)zone {
    MyCategoryList *copy = [[MyCategoryList alloc] init];
    
    
    
    if (copy) {

        copy.icon = [self.icon copyWithZone:zone];
        copy.isRecommend = self.isRecommend;
        copy.shareType = self.shareType;
        copy.isTop = self.isTop;
        copy.myCategoryListIdentifier = self.myCategoryListIdentifier;
        copy.mixWeight = [self.mixWeight copyWithZone:zone];
        copy.iconUrl = [self.iconUrl copyWithZone:zone];
        copy.totalUpdates = self.totalUpdates;
        copy.smallIconUrl = [self.smallIconUrl copyWithZone:zone];
        copy.isRisk = self.isRisk;
        copy.bigCategoryId = self.bigCategoryId;
        copy.topStartTime = [self.topStartTime copyWithZone:zone];
        copy.type = self.type;
        copy.buttons = [self.buttons copyWithZone:zone];
        copy.allowText = self.allowText;
        copy.extra = [self.extra copyWithZone:zone];
        copy.tag = [self.tag copyWithZone:zone];
        copy.intro = [self.intro copyWithZone:zone];
        copy.priority = self.priority;
        copy.postRuleId = self.postRuleId;
        copy.subscribeCount = self.subscribeCount;
        copy.allowMultiImage = self.allowMultiImage;
        copy.name = [self.name copyWithZone:zone];
        copy.smallIcon = [self.smallIcon copyWithZone:zone];
        copy.status = self.status;
        copy.todayUpdates = self.todayUpdates;
        copy.topEndTime = [self.topEndTime copyWithZone:zone];
        copy.visible = self.visible;
        copy.materialBar = [self.materialBar copyWithZone:zone];
        copy.allowGif = self.allowGif;
        copy.allowTextAndPic = self.allowTextAndPic;
        copy.channels = [self.channels copyWithZone:zone];
        copy.allowVideo = self.allowVideo;
        copy.dedup = self.dedup;
        copy.shareUrl = [self.shareUrl copyWithZone:zone];
        copy.placeholder = [self.placeholder copyWithZone:zone];
        copy.hasTimeliness = self.hasTimeliness;
    }
    
    return copy;
}


@end
