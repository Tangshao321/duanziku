//
//  BannerUrl.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "BannerUrl.h"
#import "DQUrlList.h"


NSString *const kBannerUrlId = @"id";
NSString *const kBannerUrlTitle = @"title";
NSString *const kBannerUrlUrlList = @"url_list";
NSString *const kBannerUrlHeight = @"height";
NSString *const kBannerUrlUri = @"uri";
NSString *const kBannerUrlWidth = @"width";


@interface BannerUrl ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation BannerUrl

@synthesize bannerUrlIdentifier = _bannerUrlIdentifier;
@synthesize title = _title;
@synthesize urlList = _urlList;
@synthesize height = _height;
@synthesize uri = _uri;
@synthesize width = _width;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.bannerUrlIdentifier = [[self objectOrNilForKey:kBannerUrlId fromDictionary:dict] doubleValue];
            self.title = [self objectOrNilForKey:kBannerUrlTitle fromDictionary:dict];
    NSObject *receivedUrlList = [dict objectForKey:kBannerUrlUrlList];
    NSMutableArray *parsedUrlList = [NSMutableArray array];
    
    if ([receivedUrlList isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedUrlList) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedUrlList addObject:[DQUrlList modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedUrlList isKindOfClass:[NSDictionary class]]) {
       [parsedUrlList addObject:[DQUrlList modelObjectWithDictionary:(NSDictionary *)receivedUrlList]];
    }

    self.urlList = [NSArray arrayWithArray:parsedUrlList];
            self.height = [[self objectOrNilForKey:kBannerUrlHeight fromDictionary:dict] doubleValue];
            self.uri = [self objectOrNilForKey:kBannerUrlUri fromDictionary:dict];
            self.width = [[self objectOrNilForKey:kBannerUrlWidth fromDictionary:dict] doubleValue];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[NSNumber numberWithDouble:self.bannerUrlIdentifier] forKey:kBannerUrlId];
    [mutableDict setValue:self.title forKey:kBannerUrlTitle];
    NSMutableArray *tempArrayForUrlList = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.urlList) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForUrlList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForUrlList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForUrlList] forKey:kBannerUrlUrlList];
    [mutableDict setValue:[NSNumber numberWithDouble:self.height] forKey:kBannerUrlHeight];
    [mutableDict setValue:self.uri forKey:kBannerUrlUri];
    [mutableDict setValue:[NSNumber numberWithDouble:self.width] forKey:kBannerUrlWidth];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.bannerUrlIdentifier = [aDecoder decodeDoubleForKey:kBannerUrlId];
    self.title = [aDecoder decodeObjectForKey:kBannerUrlTitle];
    self.urlList = [aDecoder decodeObjectForKey:kBannerUrlUrlList];
    self.height = [aDecoder decodeDoubleForKey:kBannerUrlHeight];
    self.uri = [aDecoder decodeObjectForKey:kBannerUrlUri];
    self.width = [aDecoder decodeDoubleForKey:kBannerUrlWidth];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeDouble:_bannerUrlIdentifier forKey:kBannerUrlId];
    [aCoder encodeObject:_title forKey:kBannerUrlTitle];
    [aCoder encodeObject:_urlList forKey:kBannerUrlUrlList];
    [aCoder encodeDouble:_height forKey:kBannerUrlHeight];
    [aCoder encodeObject:_uri forKey:kBannerUrlUri];
    [aCoder encodeDouble:_width forKey:kBannerUrlWidth];
}

- (id)copyWithZone:(NSZone *)zone {
    BannerUrl *copy = [[BannerUrl alloc] init];
    
    
    
    if (copy) {

        copy.bannerUrlIdentifier = self.bannerUrlIdentifier;
        copy.title = [self.title copyWithZone:zone];
        copy.urlList = [self.urlList copyWithZone:zone];
        copy.height = self.height;
        copy.uri = [self.uri copyWithZone:zone];
        copy.width = self.width;
    }
    
    return copy;
}


@end
