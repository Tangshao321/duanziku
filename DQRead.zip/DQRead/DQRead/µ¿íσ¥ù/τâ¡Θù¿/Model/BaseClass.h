//
//  BaseClass.h
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Group, Ad;

@interface BaseClass : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) Group *group;
@property (nonatomic, assign) double displayTime;
@property (nonatomic, strong) Ad *ad;
@property (nonatomic, assign) double type;
@property (nonatomic, assign) double onlineTime;
@property (nonatomic, strong) NSArray *comments;

//  cell的高度
@property (nonatomic, assign) CGFloat CellHeight;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
