//
//  BaseClass.m
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "BaseClass.h"
#import "Group.h"
#import "Ad.h"


NSString *const kBaseClassGroup = @"group";
NSString *const kBaseClassDisplayTime = @"display_time";
NSString *const kBaseClassAd = @"ad";
NSString *const kBaseClassType = @"type";
NSString *const kBaseClassOnlineTime = @"online_time";
NSString *const kBaseClassComments = @"comments";


@interface BaseClass ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation BaseClass

@synthesize group = _group;
@synthesize displayTime = _displayTime;
@synthesize ad = _ad;
@synthesize type = _type;
@synthesize onlineTime = _onlineTime;
@synthesize comments = _comments;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.group = [Group modelObjectWithDictionary:[dict objectForKey:kBaseClassGroup]];
            self.displayTime = [[self objectOrNilForKey:kBaseClassDisplayTime fromDictionary:dict] doubleValue];
            self.ad = [Ad modelObjectWithDictionary:[dict objectForKey:kBaseClassAd]];
            self.type = [[self objectOrNilForKey:kBaseClassType fromDictionary:dict] doubleValue];
            self.onlineTime = [[self objectOrNilForKey:kBaseClassOnlineTime fromDictionary:dict] doubleValue];
            self.comments = [self objectOrNilForKey:kBaseClassComments fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[self.group dictionaryRepresentation] forKey:kBaseClassGroup];
    [mutableDict setValue:[NSNumber numberWithDouble:self.displayTime] forKey:kBaseClassDisplayTime];
    [mutableDict setValue:[self.ad dictionaryRepresentation] forKey:kBaseClassAd];
    [mutableDict setValue:[NSNumber numberWithDouble:self.type] forKey:kBaseClassType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.onlineTime] forKey:kBaseClassOnlineTime];
    NSMutableArray *tempArrayForComments = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.comments) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForComments addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForComments addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForComments] forKey:kBaseClassComments];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.group = [aDecoder decodeObjectForKey:kBaseClassGroup];
    self.displayTime = [aDecoder decodeDoubleForKey:kBaseClassDisplayTime];
    self.ad = [aDecoder decodeObjectForKey:kBaseClassAd];
    self.type = [aDecoder decodeDoubleForKey:kBaseClassType];
    self.onlineTime = [aDecoder decodeDoubleForKey:kBaseClassOnlineTime];
    self.comments = [aDecoder decodeObjectForKey:kBaseClassComments];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_group forKey:kBaseClassGroup];
    [aCoder encodeDouble:_displayTime forKey:kBaseClassDisplayTime];
    [aCoder encodeObject:_ad forKey:kBaseClassAd];
    [aCoder encodeDouble:_type forKey:kBaseClassType];
    [aCoder encodeDouble:_onlineTime forKey:kBaseClassOnlineTime];
    [aCoder encodeObject:_comments forKey:kBaseClassComments];
}

- (id)copyWithZone:(NSZone *)zone {
    BaseClass *copy = [[BaseClass alloc] init];
    
    
    
    if (copy) {

        copy.group = [self.group copyWithZone:zone];
        copy.displayTime = self.displayTime;
        copy.ad = [self.ad copyWithZone:zone];
        copy.type = self.type;
        copy.onlineTime = self.onlineTime;
        copy.comments = [self.comments copyWithZone:zone];
    }
    
    return copy;
}


@end
