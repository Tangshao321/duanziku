//
//  Extra.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "Extra.h"


NSString *const kExtraTopEndTime = @"top_end_time";
NSString *const kExtraDefaultLabelIds = @"default_label_ids";
NSString *const kExtraHeatHours = @"heat_hours";
NSString *const kExtraLabelIds = @"label_ids";
NSString *const kExtraIsTop = @"is_top";
NSString *const kExtraHeatStartTime = @"heat_start_time";
NSString *const kExtraMixWeight = @"mix_weight";
NSString *const kExtraNeedHeat = @"need_heat";
NSString *const kExtraMaterialBar = @"material_bar";
NSString *const kExtraHasTimeliness = @"has_timeliness";
NSString *const kExtraTopStartTime = @"top_start_time";
NSString *const kExtraHeatEndTime = @"heat_end_time";
NSString *const kExtraHeatDays = @"heat_days";
NSString *const kExtraIsRisk = @"is_risk";
NSString *const kExtraBindMaterialBar = @"bind_material_bar";


@interface Extra ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Extra

@synthesize topEndTime = _topEndTime;
@synthesize defaultLabelIds = _defaultLabelIds;
@synthesize heatHours = _heatHours;
@synthesize labelIds = _labelIds;
@synthesize isTop = _isTop;
@synthesize heatStartTime = _heatStartTime;
@synthesize mixWeight = _mixWeight;
@synthesize needHeat = _needHeat;
@synthesize materialBar = _materialBar;
@synthesize hasTimeliness = _hasTimeliness;
@synthesize topStartTime = _topStartTime;
@synthesize heatEndTime = _heatEndTime;
@synthesize heatDays = _heatDays;
@synthesize isRisk = _isRisk;
@synthesize bindMaterialBar = _bindMaterialBar;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.topEndTime = [self objectOrNilForKey:kExtraTopEndTime fromDictionary:dict];
            self.defaultLabelIds = [self objectOrNilForKey:kExtraDefaultLabelIds fromDictionary:dict];
            self.heatHours = [self objectOrNilForKey:kExtraHeatHours fromDictionary:dict];
            self.labelIds = [self objectOrNilForKey:kExtraLabelIds fromDictionary:dict];
            self.isTop = [[self objectOrNilForKey:kExtraIsTop fromDictionary:dict] boolValue];
            self.heatStartTime = [self objectOrNilForKey:kExtraHeatStartTime fromDictionary:dict];
            self.mixWeight = [self objectOrNilForKey:kExtraMixWeight fromDictionary:dict];
            self.needHeat = [[self objectOrNilForKey:kExtraNeedHeat fromDictionary:dict] boolValue];
            self.materialBar = [self objectOrNilForKey:kExtraMaterialBar fromDictionary:dict];
            self.hasTimeliness = [[self objectOrNilForKey:kExtraHasTimeliness fromDictionary:dict] boolValue];
            self.topStartTime = [self objectOrNilForKey:kExtraTopStartTime fromDictionary:dict];
            self.heatEndTime = [self objectOrNilForKey:kExtraHeatEndTime fromDictionary:dict];
            self.heatDays = [self objectOrNilForKey:kExtraHeatDays fromDictionary:dict];
            self.isRisk = [[self objectOrNilForKey:kExtraIsRisk fromDictionary:dict] boolValue];
            self.bindMaterialBar = [self objectOrNilForKey:kExtraBindMaterialBar fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.topEndTime forKey:kExtraTopEndTime];
    NSMutableArray *tempArrayForDefaultLabelIds = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.defaultLabelIds) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForDefaultLabelIds addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForDefaultLabelIds addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForDefaultLabelIds] forKey:kExtraDefaultLabelIds];
    [mutableDict setValue:self.heatHours forKey:kExtraHeatHours];
    NSMutableArray *tempArrayForLabelIds = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.labelIds) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForLabelIds addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForLabelIds addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForLabelIds] forKey:kExtraLabelIds];
    [mutableDict setValue:[NSNumber numberWithBool:self.isTop] forKey:kExtraIsTop];
    [mutableDict setValue:self.heatStartTime forKey:kExtraHeatStartTime];
    [mutableDict setValue:self.mixWeight forKey:kExtraMixWeight];
    [mutableDict setValue:[NSNumber numberWithBool:self.needHeat] forKey:kExtraNeedHeat];
    NSMutableArray *tempArrayForMaterialBar = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.materialBar) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForMaterialBar addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForMaterialBar addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForMaterialBar] forKey:kExtraMaterialBar];
    [mutableDict setValue:[NSNumber numberWithBool:self.hasTimeliness] forKey:kExtraHasTimeliness];
    [mutableDict setValue:self.topStartTime forKey:kExtraTopStartTime];
    [mutableDict setValue:self.heatEndTime forKey:kExtraHeatEndTime];
    [mutableDict setValue:self.heatDays forKey:kExtraHeatDays];
    [mutableDict setValue:[NSNumber numberWithBool:self.isRisk] forKey:kExtraIsRisk];
    NSMutableArray *tempArrayForBindMaterialBar = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.bindMaterialBar) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForBindMaterialBar addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForBindMaterialBar addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForBindMaterialBar] forKey:kExtraBindMaterialBar];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.topEndTime = [aDecoder decodeObjectForKey:kExtraTopEndTime];
    self.defaultLabelIds = [aDecoder decodeObjectForKey:kExtraDefaultLabelIds];
    self.heatHours = [aDecoder decodeObjectForKey:kExtraHeatHours];
    self.labelIds = [aDecoder decodeObjectForKey:kExtraLabelIds];
    self.isTop = [aDecoder decodeBoolForKey:kExtraIsTop];
    self.heatStartTime = [aDecoder decodeObjectForKey:kExtraHeatStartTime];
    self.mixWeight = [aDecoder decodeObjectForKey:kExtraMixWeight];
    self.needHeat = [aDecoder decodeBoolForKey:kExtraNeedHeat];
    self.materialBar = [aDecoder decodeObjectForKey:kExtraMaterialBar];
    self.hasTimeliness = [aDecoder decodeBoolForKey:kExtraHasTimeliness];
    self.topStartTime = [aDecoder decodeObjectForKey:kExtraTopStartTime];
    self.heatEndTime = [aDecoder decodeObjectForKey:kExtraHeatEndTime];
    self.heatDays = [aDecoder decodeObjectForKey:kExtraHeatDays];
    self.isRisk = [aDecoder decodeBoolForKey:kExtraIsRisk];
    self.bindMaterialBar = [aDecoder decodeObjectForKey:kExtraBindMaterialBar];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_topEndTime forKey:kExtraTopEndTime];
    [aCoder encodeObject:_defaultLabelIds forKey:kExtraDefaultLabelIds];
    [aCoder encodeObject:_heatHours forKey:kExtraHeatHours];
    [aCoder encodeObject:_labelIds forKey:kExtraLabelIds];
    [aCoder encodeBool:_isTop forKey:kExtraIsTop];
    [aCoder encodeObject:_heatStartTime forKey:kExtraHeatStartTime];
    [aCoder encodeObject:_mixWeight forKey:kExtraMixWeight];
    [aCoder encodeBool:_needHeat forKey:kExtraNeedHeat];
    [aCoder encodeObject:_materialBar forKey:kExtraMaterialBar];
    [aCoder encodeBool:_hasTimeliness forKey:kExtraHasTimeliness];
    [aCoder encodeObject:_topStartTime forKey:kExtraTopStartTime];
    [aCoder encodeObject:_heatEndTime forKey:kExtraHeatEndTime];
    [aCoder encodeObject:_heatDays forKey:kExtraHeatDays];
    [aCoder encodeBool:_isRisk forKey:kExtraIsRisk];
    [aCoder encodeObject:_bindMaterialBar forKey:kExtraBindMaterialBar];
}

- (id)copyWithZone:(NSZone *)zone {
    Extra *copy = [[Extra alloc] init];
    
    
    
    if (copy) {

        copy.topEndTime = [self.topEndTime copyWithZone:zone];
        copy.defaultLabelIds = [self.defaultLabelIds copyWithZone:zone];
        copy.heatHours = [self.heatHours copyWithZone:zone];
        copy.labelIds = [self.labelIds copyWithZone:zone];
        copy.isTop = self.isTop;
        copy.heatStartTime = [self.heatStartTime copyWithZone:zone];
        copy.mixWeight = [self.mixWeight copyWithZone:zone];
        copy.needHeat = self.needHeat;
        copy.materialBar = [self.materialBar copyWithZone:zone];
        copy.hasTimeliness = self.hasTimeliness;
        copy.topStartTime = [self.topStartTime copyWithZone:zone];
        copy.heatEndTime = [self.heatEndTime copyWithZone:zone];
        copy.heatDays = [self.heatDays copyWithZone:zone];
        copy.isRisk = self.isRisk;
        copy.bindMaterialBar = [self.bindMaterialBar copyWithZone:zone];
    }
    
    return copy;
}


@end
