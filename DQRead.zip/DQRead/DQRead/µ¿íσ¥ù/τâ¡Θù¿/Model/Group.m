//
//  Group.m
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "Group.h"
#import "MiddleImage.h"
#import "ThumbImageList.h"
#import "User.h"
#import "DislikeReason.h"
#import "NeihanHotLink.h"
#import "LargeImage.h"
#import "Activity.h"
#import "LargeImageList.h"


NSString *const kGroupAllowDislike = @"allow_dislike";
NSString *const kGroupIsMultiImage = @"is_multi_image";
NSString *const kGroupShareType = @"share_type";
NSString *const kGroupId = @"id";
NSString *const kGroupUserBury = @"user_bury";
NSString *const kGroupMinScreenWidthPercent = @"min_screen_width_percent";
NSString *const kGroupNeihanHotEndTime = @"neihan_hot_end_time";
NSString *const kGroupQuickComment = @"quick_comment";
NSString *const kGroupMiddleImage = @"middle_image";
NSString *const kGroupBuryCount = @"bury_count";
NSString *const kGroupText = @"text";
NSString *const kGroupLabel = @"label";
NSString *const kGroupNeihanHotStartTime = @"neihan_hot_start_time";
NSString *const kGroupShareCount = @"share_count";
NSString *const kGroupCategoryVisible = @"category_visible";
NSString *const kGroupHasComments = @"has_comments";
NSString *const kGroupType = @"type";
NSString *const kGroupIsNeihanHot = @"is_neihan_hot";
NSString *const kGroupThumbImageList = @"thumb_image_list";
NSString *const kGroupUserFavorite = @"user_favorite";
NSString *const kGroupUserDigg = @"user_digg";
NSString *const kGroupCategoryName = @"category_name";
NSString *const kGroupCreateTime = @"create_time";
NSString *const kGroupCategoryType = @"category_type";
NSString *const kGroupUser = @"user";
NSString *const kGroupDislikeReason = @"dislike_reason";
NSString *const kGroupFavoriteCount = @"favorite_count";
NSString *const kGroupIsCanShare = @"is_can_share";
NSString *const kGroupIdStr = @"id_str";
NSString *const kGroupStatusDesc = @"status_desc";
NSString *const kGroupDiggCount = @"digg_count";
NSString *const kGroupStatus = @"status";
NSString *const kGroupNeihanHotLink = @"neihan_hot_link";
NSString *const kGroupCommentCount = @"comment_count";
NSString *const kGroupMaxScreenWidthPercent = @"max_screen_width_percent";
NSString *const kGroupLargeImage = @"large_image";
NSString *const kGroupActivity = @"activity";
NSString *const kGroupContent = @"content";
NSString *const kGroupUserRepin = @"user_repin";
NSString *const kGroupImageStatus = @"image_status";
NSString *const kGroupIsAnonymous = @"is_anonymous";
NSString *const kGroupGroupId = @"group_id";
NSString *const kGroupDisplayType = @"display_type";
NSString *const kGroupGoDetailCount = @"go_detail_count";
NSString *const kGroupShareUrl = @"share_url";
NSString *const kGroupCategoryId = @"category_id";
NSString *const kGroupMediaType = @"media_type";
NSString *const kGroupLargeImageList = @"large_image_list";
NSString *const kGroupOnlineTime = @"online_time";
NSString *const kGroupRepinCount = @"repin_count";
NSString *const kGroupHasHotComments = @"has_hot_comments";


@interface Group ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Group

@synthesize allowDislike = _allowDislike;
@synthesize isMultiImage = _isMultiImage;
@synthesize shareType = _shareType;
@synthesize groupIdentifier = _groupIdentifier;
@synthesize userBury = _userBury;
@synthesize minScreenWidthPercent = _minScreenWidthPercent;
@synthesize neihanHotEndTime = _neihanHotEndTime;
@synthesize quickComment = _quickComment;
@synthesize middleImage = _middleImage;
@synthesize buryCount = _buryCount;
@synthesize text = _text;
@synthesize label = _label;
@synthesize neihanHotStartTime = _neihanHotStartTime;
@synthesize shareCount = _shareCount;
@synthesize categoryVisible = _categoryVisible;
@synthesize hasComments = _hasComments;
@synthesize type = _type;
@synthesize isNeihanHot = _isNeihanHot;
@synthesize thumbImageList = _thumbImageList;
@synthesize userFavorite = _userFavorite;
@synthesize userDigg = _userDigg;
@synthesize categoryName = _categoryName;
@synthesize createTime = _createTime;
@synthesize categoryType = _categoryType;
@synthesize user = _user;
@synthesize dislikeReason = _dislikeReason;
@synthesize favoriteCount = _favoriteCount;
@synthesize isCanShare = _isCanShare;
@synthesize idStr = _idStr;
@synthesize statusDesc = _statusDesc;
@synthesize diggCount = _diggCount;
@synthesize status = _status;
@synthesize neihanHotLink = _neihanHotLink;
@synthesize commentCount = _commentCount;
@synthesize maxScreenWidthPercent = _maxScreenWidthPercent;
@synthesize largeImage = _largeImage;
@synthesize activity = _activity;
@synthesize content = _content;
@synthesize userRepin = _userRepin;
@synthesize imageStatus = _imageStatus;
@synthesize isAnonymous = _isAnonymous;
@synthesize groupId = _groupId;
@synthesize displayType = _displayType;
@synthesize goDetailCount = _goDetailCount;
@synthesize shareUrl = _shareUrl;
@synthesize categoryId = _categoryId;
@synthesize mediaType = _mediaType;
@synthesize largeImageList = _largeImageList;
@synthesize onlineTime = _onlineTime;
@synthesize repinCount = _repinCount;
@synthesize hasHotComments = _hasHotComments;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.allowDislike = [[self objectOrNilForKey:kGroupAllowDislike fromDictionary:dict] doubleValue];
            self.isMultiImage = [[self objectOrNilForKey:kGroupIsMultiImage fromDictionary:dict] doubleValue];
            self.shareType = [[self objectOrNilForKey:kGroupShareType fromDictionary:dict] doubleValue];
            self.groupIdentifier = [[self objectOrNilForKey:kGroupId fromDictionary:dict] doubleValue];
            self.userBury = [[self objectOrNilForKey:kGroupUserBury fromDictionary:dict] doubleValue];
            self.minScreenWidthPercent = [[self objectOrNilForKey:kGroupMinScreenWidthPercent fromDictionary:dict] doubleValue];
            self.neihanHotEndTime = [self objectOrNilForKey:kGroupNeihanHotEndTime fromDictionary:dict];
            self.quickComment = [[self objectOrNilForKey:kGroupQuickComment fromDictionary:dict] doubleValue];
            self.middleImage = [MiddleImage modelObjectWithDictionary:[dict objectForKey:kGroupMiddleImage]];
            self.buryCount = [[self objectOrNilForKey:kGroupBuryCount fromDictionary:dict] doubleValue];
            self.text = [self objectOrNilForKey:kGroupText fromDictionary:dict];
            self.label = [[self objectOrNilForKey:kGroupLabel fromDictionary:dict] doubleValue];
            self.neihanHotStartTime = [self objectOrNilForKey:kGroupNeihanHotStartTime fromDictionary:dict];
            self.shareCount = [[self objectOrNilForKey:kGroupShareCount fromDictionary:dict] doubleValue];
            self.categoryVisible = [[self objectOrNilForKey:kGroupCategoryVisible fromDictionary:dict] doubleValue];
            self.hasComments = [[self objectOrNilForKey:kGroupHasComments fromDictionary:dict] doubleValue];
            self.type = [[self objectOrNilForKey:kGroupType fromDictionary:dict] doubleValue];
            self.isNeihanHot = [[self objectOrNilForKey:kGroupIsNeihanHot fromDictionary:dict] doubleValue];
    NSObject *receivedThumbImageList = [dict objectForKey:kGroupThumbImageList];
    NSMutableArray *parsedThumbImageList = [NSMutableArray array];
    
    if ([receivedThumbImageList isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedThumbImageList) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedThumbImageList addObject:[ThumbImageList modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedThumbImageList isKindOfClass:[NSDictionary class]]) {
       [parsedThumbImageList addObject:[ThumbImageList modelObjectWithDictionary:(NSDictionary *)receivedThumbImageList]];
    }

    self.thumbImageList = [NSArray arrayWithArray:parsedThumbImageList];
            self.userFavorite = [[self objectOrNilForKey:kGroupUserFavorite fromDictionary:dict] doubleValue];
            self.userDigg = [[self objectOrNilForKey:kGroupUserDigg fromDictionary:dict] doubleValue];
            self.categoryName = [self objectOrNilForKey:kGroupCategoryName fromDictionary:dict];
            self.createTime = [[self objectOrNilForKey:kGroupCreateTime fromDictionary:dict] doubleValue];
            self.categoryType = [[self objectOrNilForKey:kGroupCategoryType fromDictionary:dict] doubleValue];
            self.user = [User modelObjectWithDictionary:[dict objectForKey:kGroupUser]];
    NSObject *receivedDislikeReason = [dict objectForKey:kGroupDislikeReason];
    NSMutableArray *parsedDislikeReason = [NSMutableArray array];
    
    if ([receivedDislikeReason isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedDislikeReason) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedDislikeReason addObject:[DislikeReason modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedDislikeReason isKindOfClass:[NSDictionary class]]) {
       [parsedDislikeReason addObject:[DislikeReason modelObjectWithDictionary:(NSDictionary *)receivedDislikeReason]];
    }

    self.dislikeReason = [NSArray arrayWithArray:parsedDislikeReason];
            self.favoriteCount = [[self objectOrNilForKey:kGroupFavoriteCount fromDictionary:dict] doubleValue];
            self.isCanShare = [[self objectOrNilForKey:kGroupIsCanShare fromDictionary:dict] doubleValue];
            self.idStr = [self objectOrNilForKey:kGroupIdStr fromDictionary:dict];
            self.statusDesc = [self objectOrNilForKey:kGroupStatusDesc fromDictionary:dict];
            self.diggCount = [[self objectOrNilForKey:kGroupDiggCount fromDictionary:dict] doubleValue];
            self.status = [[self objectOrNilForKey:kGroupStatus fromDictionary:dict] doubleValue];
            self.neihanHotLink = [NeihanHotLink modelObjectWithDictionary:[dict objectForKey:kGroupNeihanHotLink]];
            self.commentCount = [[self objectOrNilForKey:kGroupCommentCount fromDictionary:dict] doubleValue];
            self.maxScreenWidthPercent = [[self objectOrNilForKey:kGroupMaxScreenWidthPercent fromDictionary:dict] doubleValue];
            self.largeImage = [LargeImage modelObjectWithDictionary:[dict objectForKey:kGroupLargeImage]];
            self.activity = [Activity modelObjectWithDictionary:[dict objectForKey:kGroupActivity]];
            self.content = [self objectOrNilForKey:kGroupContent fromDictionary:dict];
            self.userRepin = [[self objectOrNilForKey:kGroupUserRepin fromDictionary:dict] doubleValue];
            self.imageStatus = [[self objectOrNilForKey:kGroupImageStatus fromDictionary:dict] doubleValue];
            self.isAnonymous = [[self objectOrNilForKey:kGroupIsAnonymous fromDictionary:dict] doubleValue];
            self.groupId = [[self objectOrNilForKey:kGroupGroupId fromDictionary:dict] doubleValue];
            self.displayType = [[self objectOrNilForKey:kGroupDisplayType fromDictionary:dict] doubleValue];
            self.goDetailCount = [[self objectOrNilForKey:kGroupGoDetailCount fromDictionary:dict] doubleValue];
            self.shareUrl = [self objectOrNilForKey:kGroupShareUrl fromDictionary:dict];
            self.categoryId = [[self objectOrNilForKey:kGroupCategoryId fromDictionary:dict] doubleValue];
            self.mediaType = [[self objectOrNilForKey:kGroupMediaType fromDictionary:dict] doubleValue];
    NSObject *receivedLargeImageList = [dict objectForKey:kGroupLargeImageList];
    NSMutableArray *parsedLargeImageList = [NSMutableArray array];
    
    if ([receivedLargeImageList isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedLargeImageList) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedLargeImageList addObject:[LargeImageList modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedLargeImageList isKindOfClass:[NSDictionary class]]) {
       [parsedLargeImageList addObject:[LargeImageList modelObjectWithDictionary:(NSDictionary *)receivedLargeImageList]];
    }

    self.largeImageList = [NSArray arrayWithArray:parsedLargeImageList];
            self.onlineTime = [[self objectOrNilForKey:kGroupOnlineTime fromDictionary:dict] doubleValue];
            self.repinCount = [[self objectOrNilForKey:kGroupRepinCount fromDictionary:dict] doubleValue];
            self.hasHotComments = [[self objectOrNilForKey:kGroupHasHotComments fromDictionary:dict] doubleValue];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[NSNumber numberWithDouble:self.allowDislike] forKey:kGroupAllowDislike];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isMultiImage] forKey:kGroupIsMultiImage];
    [mutableDict setValue:[NSNumber numberWithDouble:self.shareType] forKey:kGroupShareType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.groupIdentifier] forKey:kGroupId];
    [mutableDict setValue:[NSNumber numberWithDouble:self.userBury] forKey:kGroupUserBury];
    [mutableDict setValue:[NSNumber numberWithDouble:self.minScreenWidthPercent] forKey:kGroupMinScreenWidthPercent];
    [mutableDict setValue:self.neihanHotEndTime forKey:kGroupNeihanHotEndTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.quickComment] forKey:kGroupQuickComment];
    [mutableDict setValue:[self.middleImage dictionaryRepresentation] forKey:kGroupMiddleImage];
    [mutableDict setValue:[NSNumber numberWithDouble:self.buryCount] forKey:kGroupBuryCount];
    [mutableDict setValue:self.text forKey:kGroupText];
    [mutableDict setValue:[NSNumber numberWithDouble:self.label] forKey:kGroupLabel];
    [mutableDict setValue:self.neihanHotStartTime forKey:kGroupNeihanHotStartTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.shareCount] forKey:kGroupShareCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.categoryVisible] forKey:kGroupCategoryVisible];
    [mutableDict setValue:[NSNumber numberWithDouble:self.hasComments] forKey:kGroupHasComments];
    [mutableDict setValue:[NSNumber numberWithDouble:self.type] forKey:kGroupType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isNeihanHot] forKey:kGroupIsNeihanHot];
    NSMutableArray *tempArrayForThumbImageList = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.thumbImageList) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForThumbImageList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForThumbImageList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForThumbImageList] forKey:kGroupThumbImageList];
    [mutableDict setValue:[NSNumber numberWithDouble:self.userFavorite] forKey:kGroupUserFavorite];
    [mutableDict setValue:[NSNumber numberWithDouble:self.userDigg] forKey:kGroupUserDigg];
    [mutableDict setValue:self.categoryName forKey:kGroupCategoryName];
    [mutableDict setValue:[NSNumber numberWithDouble:self.createTime] forKey:kGroupCreateTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.categoryType] forKey:kGroupCategoryType];
    [mutableDict setValue:[self.user dictionaryRepresentation] forKey:kGroupUser];
    NSMutableArray *tempArrayForDislikeReason = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.dislikeReason) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForDislikeReason addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForDislikeReason addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForDislikeReason] forKey:kGroupDislikeReason];
    [mutableDict setValue:[NSNumber numberWithDouble:self.favoriteCount] forKey:kGroupFavoriteCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isCanShare] forKey:kGroupIsCanShare];
    [mutableDict setValue:self.idStr forKey:kGroupIdStr];
    [mutableDict setValue:self.statusDesc forKey:kGroupStatusDesc];
    [mutableDict setValue:[NSNumber numberWithDouble:self.diggCount] forKey:kGroupDiggCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.status] forKey:kGroupStatus];
    [mutableDict setValue:[self.neihanHotLink dictionaryRepresentation] forKey:kGroupNeihanHotLink];
    [mutableDict setValue:[NSNumber numberWithDouble:self.commentCount] forKey:kGroupCommentCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.maxScreenWidthPercent] forKey:kGroupMaxScreenWidthPercent];
    [mutableDict setValue:[self.largeImage dictionaryRepresentation] forKey:kGroupLargeImage];
    [mutableDict setValue:[self.activity dictionaryRepresentation] forKey:kGroupActivity];
    [mutableDict setValue:self.content forKey:kGroupContent];
    [mutableDict setValue:[NSNumber numberWithDouble:self.userRepin] forKey:kGroupUserRepin];
    [mutableDict setValue:[NSNumber numberWithDouble:self.imageStatus] forKey:kGroupImageStatus];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isAnonymous] forKey:kGroupIsAnonymous];
    [mutableDict setValue:[NSNumber numberWithDouble:self.groupId] forKey:kGroupGroupId];
    [mutableDict setValue:[NSNumber numberWithDouble:self.displayType] forKey:kGroupDisplayType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.goDetailCount] forKey:kGroupGoDetailCount];
    [mutableDict setValue:self.shareUrl forKey:kGroupShareUrl];
    [mutableDict setValue:[NSNumber numberWithDouble:self.categoryId] forKey:kGroupCategoryId];
    [mutableDict setValue:[NSNumber numberWithDouble:self.mediaType] forKey:kGroupMediaType];
    NSMutableArray *tempArrayForLargeImageList = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.largeImageList) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForLargeImageList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForLargeImageList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForLargeImageList] forKey:kGroupLargeImageList];
    [mutableDict setValue:[NSNumber numberWithDouble:self.onlineTime] forKey:kGroupOnlineTime];
    [mutableDict setValue:[NSNumber numberWithDouble:self.repinCount] forKey:kGroupRepinCount];
    [mutableDict setValue:[NSNumber numberWithDouble:self.hasHotComments] forKey:kGroupHasHotComments];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.allowDislike = [aDecoder decodeDoubleForKey:kGroupAllowDislike];
    self.isMultiImage = [aDecoder decodeDoubleForKey:kGroupIsMultiImage];
    self.shareType = [aDecoder decodeDoubleForKey:kGroupShareType];
    self.groupIdentifier = [aDecoder decodeDoubleForKey:kGroupId];
    self.userBury = [aDecoder decodeDoubleForKey:kGroupUserBury];
    self.minScreenWidthPercent = [aDecoder decodeDoubleForKey:kGroupMinScreenWidthPercent];
    self.neihanHotEndTime = [aDecoder decodeObjectForKey:kGroupNeihanHotEndTime];
    self.quickComment = [aDecoder decodeDoubleForKey:kGroupQuickComment];
    self.middleImage = [aDecoder decodeObjectForKey:kGroupMiddleImage];
    self.buryCount = [aDecoder decodeDoubleForKey:kGroupBuryCount];
    self.text = [aDecoder decodeObjectForKey:kGroupText];
    self.label = [aDecoder decodeDoubleForKey:kGroupLabel];
    self.neihanHotStartTime = [aDecoder decodeObjectForKey:kGroupNeihanHotStartTime];
    self.shareCount = [aDecoder decodeDoubleForKey:kGroupShareCount];
    self.categoryVisible = [aDecoder decodeDoubleForKey:kGroupCategoryVisible];
    self.hasComments = [aDecoder decodeDoubleForKey:kGroupHasComments];
    self.type = [aDecoder decodeDoubleForKey:kGroupType];
    self.isNeihanHot = [aDecoder decodeDoubleForKey:kGroupIsNeihanHot];
    self.thumbImageList = [aDecoder decodeObjectForKey:kGroupThumbImageList];
    self.userFavorite = [aDecoder decodeDoubleForKey:kGroupUserFavorite];
    self.userDigg = [aDecoder decodeDoubleForKey:kGroupUserDigg];
    self.categoryName = [aDecoder decodeObjectForKey:kGroupCategoryName];
    self.createTime = [aDecoder decodeDoubleForKey:kGroupCreateTime];
    self.categoryType = [aDecoder decodeDoubleForKey:kGroupCategoryType];
    self.user = [aDecoder decodeObjectForKey:kGroupUser];
    self.dislikeReason = [aDecoder decodeObjectForKey:kGroupDislikeReason];
    self.favoriteCount = [aDecoder decodeDoubleForKey:kGroupFavoriteCount];
    self.isCanShare = [aDecoder decodeDoubleForKey:kGroupIsCanShare];
    self.idStr = [aDecoder decodeObjectForKey:kGroupIdStr];
    self.statusDesc = [aDecoder decodeObjectForKey:kGroupStatusDesc];
    self.diggCount = [aDecoder decodeDoubleForKey:kGroupDiggCount];
    self.status = [aDecoder decodeDoubleForKey:kGroupStatus];
    self.neihanHotLink = [aDecoder decodeObjectForKey:kGroupNeihanHotLink];
    self.commentCount = [aDecoder decodeDoubleForKey:kGroupCommentCount];
    self.maxScreenWidthPercent = [aDecoder decodeDoubleForKey:kGroupMaxScreenWidthPercent];
    self.largeImage = [aDecoder decodeObjectForKey:kGroupLargeImage];
    self.activity = [aDecoder decodeObjectForKey:kGroupActivity];
    self.content = [aDecoder decodeObjectForKey:kGroupContent];
    self.userRepin = [aDecoder decodeDoubleForKey:kGroupUserRepin];
    self.imageStatus = [aDecoder decodeDoubleForKey:kGroupImageStatus];
    self.isAnonymous = [aDecoder decodeDoubleForKey:kGroupIsAnonymous];
    self.groupId = [aDecoder decodeDoubleForKey:kGroupGroupId];
    self.displayType = [aDecoder decodeDoubleForKey:kGroupDisplayType];
    self.goDetailCount = [aDecoder decodeDoubleForKey:kGroupGoDetailCount];
    self.shareUrl = [aDecoder decodeObjectForKey:kGroupShareUrl];
    self.categoryId = [aDecoder decodeDoubleForKey:kGroupCategoryId];
    self.mediaType = [aDecoder decodeDoubleForKey:kGroupMediaType];
    self.largeImageList = [aDecoder decodeObjectForKey:kGroupLargeImageList];
    self.onlineTime = [aDecoder decodeDoubleForKey:kGroupOnlineTime];
    self.repinCount = [aDecoder decodeDoubleForKey:kGroupRepinCount];
    self.hasHotComments = [aDecoder decodeDoubleForKey:kGroupHasHotComments];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeDouble:_allowDislike forKey:kGroupAllowDislike];
    [aCoder encodeDouble:_isMultiImage forKey:kGroupIsMultiImage];
    [aCoder encodeDouble:_shareType forKey:kGroupShareType];
    [aCoder encodeDouble:_groupIdentifier forKey:kGroupId];
    [aCoder encodeDouble:_userBury forKey:kGroupUserBury];
    [aCoder encodeDouble:_minScreenWidthPercent forKey:kGroupMinScreenWidthPercent];
    [aCoder encodeObject:_neihanHotEndTime forKey:kGroupNeihanHotEndTime];
    [aCoder encodeDouble:_quickComment forKey:kGroupQuickComment];
    [aCoder encodeObject:_middleImage forKey:kGroupMiddleImage];
    [aCoder encodeDouble:_buryCount forKey:kGroupBuryCount];
    [aCoder encodeObject:_text forKey:kGroupText];
    [aCoder encodeDouble:_label forKey:kGroupLabel];
    [aCoder encodeObject:_neihanHotStartTime forKey:kGroupNeihanHotStartTime];
    [aCoder encodeDouble:_shareCount forKey:kGroupShareCount];
    [aCoder encodeDouble:_categoryVisible forKey:kGroupCategoryVisible];
    [aCoder encodeDouble:_hasComments forKey:kGroupHasComments];
    [aCoder encodeDouble:_type forKey:kGroupType];
    [aCoder encodeDouble:_isNeihanHot forKey:kGroupIsNeihanHot];
    [aCoder encodeObject:_thumbImageList forKey:kGroupThumbImageList];
    [aCoder encodeDouble:_userFavorite forKey:kGroupUserFavorite];
    [aCoder encodeDouble:_userDigg forKey:kGroupUserDigg];
    [aCoder encodeObject:_categoryName forKey:kGroupCategoryName];
    [aCoder encodeDouble:_createTime forKey:kGroupCreateTime];
    [aCoder encodeDouble:_categoryType forKey:kGroupCategoryType];
    [aCoder encodeObject:_user forKey:kGroupUser];
    [aCoder encodeObject:_dislikeReason forKey:kGroupDislikeReason];
    [aCoder encodeDouble:_favoriteCount forKey:kGroupFavoriteCount];
    [aCoder encodeDouble:_isCanShare forKey:kGroupIsCanShare];
    [aCoder encodeObject:_idStr forKey:kGroupIdStr];
    [aCoder encodeObject:_statusDesc forKey:kGroupStatusDesc];
    [aCoder encodeDouble:_diggCount forKey:kGroupDiggCount];
    [aCoder encodeDouble:_status forKey:kGroupStatus];
    [aCoder encodeObject:_neihanHotLink forKey:kGroupNeihanHotLink];
    [aCoder encodeDouble:_commentCount forKey:kGroupCommentCount];
    [aCoder encodeDouble:_maxScreenWidthPercent forKey:kGroupMaxScreenWidthPercent];
    [aCoder encodeObject:_largeImage forKey:kGroupLargeImage];
    [aCoder encodeObject:_activity forKey:kGroupActivity];
    [aCoder encodeObject:_content forKey:kGroupContent];
    [aCoder encodeDouble:_userRepin forKey:kGroupUserRepin];
    [aCoder encodeDouble:_imageStatus forKey:kGroupImageStatus];
    [aCoder encodeDouble:_isAnonymous forKey:kGroupIsAnonymous];
    [aCoder encodeDouble:_groupId forKey:kGroupGroupId];
    [aCoder encodeDouble:_displayType forKey:kGroupDisplayType];
    [aCoder encodeDouble:_goDetailCount forKey:kGroupGoDetailCount];
    [aCoder encodeObject:_shareUrl forKey:kGroupShareUrl];
    [aCoder encodeDouble:_categoryId forKey:kGroupCategoryId];
    [aCoder encodeDouble:_mediaType forKey:kGroupMediaType];
    [aCoder encodeObject:_largeImageList forKey:kGroupLargeImageList];
    [aCoder encodeDouble:_onlineTime forKey:kGroupOnlineTime];
    [aCoder encodeDouble:_repinCount forKey:kGroupRepinCount];
    [aCoder encodeDouble:_hasHotComments forKey:kGroupHasHotComments];
}

- (id)copyWithZone:(NSZone *)zone {
    Group *copy = [[Group alloc] init];
    
    if (copy) {
        copy.allowDislike = self.allowDislike;
        copy.isMultiImage = self.isMultiImage;
        copy.shareType = self.shareType;
        copy.groupIdentifier = self.groupIdentifier;
        copy.userBury = self.userBury;
        copy.minScreenWidthPercent = self.minScreenWidthPercent;
        copy.neihanHotEndTime = [self.neihanHotEndTime copyWithZone:zone];
        copy.quickComment = self.quickComment;
        copy.middleImage = [self.middleImage copyWithZone:zone];
        copy.buryCount = self.buryCount;
        copy.text = [self.text copyWithZone:zone];
        copy.label = self.label;
        copy.neihanHotStartTime = [self.neihanHotStartTime copyWithZone:zone];
        copy.shareCount = self.shareCount;
        copy.categoryVisible = self.categoryVisible;
        copy.hasComments = self.hasComments;
        copy.type = self.type;
        copy.isNeihanHot = self.isNeihanHot;
        copy.thumbImageList = [self.thumbImageList copyWithZone:zone];
        copy.userFavorite = self.userFavorite;
        copy.userDigg = self.userDigg;
        copy.categoryName = [self.categoryName copyWithZone:zone];
        copy.createTime = self.createTime;
        copy.categoryType = self.categoryType;
        copy.user = [self.user copyWithZone:zone];
        copy.dislikeReason = [self.dislikeReason copyWithZone:zone];
        copy.favoriteCount = self.favoriteCount;
        copy.isCanShare = self.isCanShare;
        copy.idStr = [self.idStr copyWithZone:zone];
        copy.statusDesc = [self.statusDesc copyWithZone:zone];
        copy.diggCount = self.diggCount;
        copy.status = self.status;
        copy.neihanHotLink = [self.neihanHotLink copyWithZone:zone];
        copy.commentCount = self.commentCount;
        copy.maxScreenWidthPercent = self.maxScreenWidthPercent;
        copy.largeImage = [self.largeImage copyWithZone:zone];
        copy.activity = [self.activity copyWithZone:zone];
        copy.content = [self.content copyWithZone:zone];
        copy.userRepin = self.userRepin;
        copy.imageStatus = self.imageStatus;
        copy.isAnonymous = self.isAnonymous;
        copy.groupId = self.groupId;
        copy.displayType = self.displayType;
        copy.goDetailCount = self.goDetailCount;
        copy.shareUrl = [self.shareUrl copyWithZone:zone];
        copy.categoryId = self.categoryId;
        copy.mediaType = self.mediaType;
        copy.largeImageList = [self.largeImageList copyWithZone:zone];
        copy.onlineTime = self.onlineTime;
        copy.repinCount = self.repinCount;
        copy.hasHotComments = self.hasHotComments;
    }
    
    return copy;
}


//  内容高度
- (CGFloat)heightForsContent{
    return [self.content heightForWidth:SCREEN_WIDTH - 2 * DQAdaption(35) andFont:DQAFont(28)];
}
@end
