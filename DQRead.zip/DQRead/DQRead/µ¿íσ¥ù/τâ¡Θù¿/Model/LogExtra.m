//
//  LogExtra.m
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "LogExtra.h"


NSString *const kLogExtraAdPrice = @"ad_price";
NSString *const kLogExtraRit = @"rit";
NSString *const kLogExtraReqId = @"req_id";
NSString *const kLogExtraConvertId = @"convert_id";


@interface LogExtra ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation LogExtra

@synthesize adPrice = _adPrice;
@synthesize rit = _rit;
@synthesize reqId = _reqId;
@synthesize convertId = _convertId;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.adPrice = [self objectOrNilForKey:kLogExtraAdPrice fromDictionary:dict];
            self.rit = [[self objectOrNilForKey:kLogExtraRit fromDictionary:dict] doubleValue];
            self.reqId = [self objectOrNilForKey:kLogExtraReqId fromDictionary:dict];
            self.convertId = [[self objectOrNilForKey:kLogExtraConvertId fromDictionary:dict] doubleValue];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.adPrice forKey:kLogExtraAdPrice];
    [mutableDict setValue:[NSNumber numberWithDouble:self.rit] forKey:kLogExtraRit];
    [mutableDict setValue:self.reqId forKey:kLogExtraReqId];
    [mutableDict setValue:[NSNumber numberWithDouble:self.convertId] forKey:kLogExtraConvertId];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.adPrice = [aDecoder decodeObjectForKey:kLogExtraAdPrice];
    self.rit = [aDecoder decodeDoubleForKey:kLogExtraRit];
    self.reqId = [aDecoder decodeObjectForKey:kLogExtraReqId];
    self.convertId = [aDecoder decodeDoubleForKey:kLogExtraConvertId];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_adPrice forKey:kLogExtraAdPrice];
    [aCoder encodeDouble:_rit forKey:kLogExtraRit];
    [aCoder encodeObject:_reqId forKey:kLogExtraReqId];
    [aCoder encodeDouble:_convertId forKey:kLogExtraConvertId];
}

- (id)copyWithZone:(NSZone *)zone {
    LogExtra *copy = [[LogExtra alloc] init];
    
    
    
    if (copy) {

        copy.adPrice = [self.adPrice copyWithZone:zone];
        copy.rit = self.rit;
        copy.reqId = [self.reqId copyWithZone:zone];
        copy.convertId = self.convertId;
    }
    
    return copy;
}


@end
