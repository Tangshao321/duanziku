//
//  DislikeReason.m
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "DislikeReason.h"


NSString *const kDislikeReasonType = @"type";
NSString *const kDislikeReasonId = @"id";
NSString *const kDislikeReasonTitle = @"title";


@interface DislikeReason ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation DislikeReason

@synthesize type = _type;
@synthesize dislikeReasonIdentifier = _dislikeReasonIdentifier;
@synthesize title = _title;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.type = [[self objectOrNilForKey:kDislikeReasonType fromDictionary:dict] doubleValue];
            self.dislikeReasonIdentifier = [[self objectOrNilForKey:kDislikeReasonId fromDictionary:dict] doubleValue];
            self.title = [self objectOrNilForKey:kDislikeReasonTitle fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[NSNumber numberWithDouble:self.type] forKey:kDislikeReasonType];
    [mutableDict setValue:[NSNumber numberWithDouble:self.dislikeReasonIdentifier] forKey:kDislikeReasonId];
    [mutableDict setValue:self.title forKey:kDislikeReasonTitle];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.type = [aDecoder decodeDoubleForKey:kDislikeReasonType];
    self.dislikeReasonIdentifier = [aDecoder decodeDoubleForKey:kDislikeReasonId];
    self.title = [aDecoder decodeObjectForKey:kDislikeReasonTitle];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeDouble:_type forKey:kDislikeReasonType];
    [aCoder encodeDouble:_dislikeReasonIdentifier forKey:kDislikeReasonId];
    [aCoder encodeObject:_title forKey:kDislikeReasonTitle];
}

- (id)copyWithZone:(NSZone *)zone {
    DislikeReason *copy = [[DislikeReason alloc] init];
    
    
    
    if (copy) {

        copy.type = self.type;
        copy.dislikeReasonIdentifier = self.dislikeReasonIdentifier;
        copy.title = [self.title copyWithZone:zone];
    }
    
    return copy;
}


@end
