//
//  GodComment.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "GodComment.h"


NSString *const kGodCommentIcon = @"icon";
NSString *const kGodCommentCount = @"count";
NSString *const kGodCommentIntro = @"intro";
NSString *const kGodCommentName = @"name";


@interface GodComment ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation GodComment

@synthesize icon = _icon;
@synthesize count = _count;
@synthesize intro = _intro;
@synthesize name = _name;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.icon = [self objectOrNilForKey:kGodCommentIcon fromDictionary:dict];
            self.count = [[self objectOrNilForKey:kGodCommentCount fromDictionary:dict] doubleValue];
            self.intro = [self objectOrNilForKey:kGodCommentIntro fromDictionary:dict];
            self.name = [self objectOrNilForKey:kGodCommentName fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.icon forKey:kGodCommentIcon];
    [mutableDict setValue:[NSNumber numberWithDouble:self.count] forKey:kGodCommentCount];
    [mutableDict setValue:self.intro forKey:kGodCommentIntro];
    [mutableDict setValue:self.name forKey:kGodCommentName];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.icon = [aDecoder decodeObjectForKey:kGodCommentIcon];
    self.count = [aDecoder decodeDoubleForKey:kGodCommentCount];
    self.intro = [aDecoder decodeObjectForKey:kGodCommentIntro];
    self.name = [aDecoder decodeObjectForKey:kGodCommentName];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_icon forKey:kGodCommentIcon];
    [aCoder encodeDouble:_count forKey:kGodCommentCount];
    [aCoder encodeObject:_intro forKey:kGodCommentIntro];
    [aCoder encodeObject:_name forKey:kGodCommentName];
}

- (id)copyWithZone:(NSZone *)zone {
    GodComment *copy = [[GodComment alloc] init];
    
    
    
    if (copy) {

        copy.icon = [self.icon copyWithZone:zone];
        copy.count = self.count;
        copy.intro = [self.intro copyWithZone:zone];
        copy.name = [self.name copyWithZone:zone];
    }
    
    return copy;
}


@end
