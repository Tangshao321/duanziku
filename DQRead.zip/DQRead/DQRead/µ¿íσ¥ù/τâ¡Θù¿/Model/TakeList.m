//
//  TakeList.m
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "TakeList.h"

@implementation TakeList
+ (instancetype)sharedTakeList
{
    static TakeList *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[[self class] alloc]init];
        instance.tableCLassName = @"takeList";
        instance.keyCreateAt = @"createdAt";
        instance.keyUserTakeId = @"userTakeId";
        instance.keyObjectId = @"objectId";
        instance.keyUserTakeCategoryList = @"userTakeCategoryList";
        instance.keyCategoryId = @"categoryId";
    });
    return instance;
}



@end
