//
//  BaseClass.m
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "DQBaseClass.h"
#import "MyTopCategoryList.h"
#import "RotateBanner.h"
#import "Categories.h"
#import "GodComment.h"
#import "MyCategoryList.h"


NSString *const kBaseClassMyTopCategoryList = @"my_top_category_list";
NSString *const kBaseClassRotateBanner = @"rotate_banner";
NSString *const kBaseClassCategories = @"categories";
NSString *const kBaseClassGodComment = @"god_comment";
NSString *const kBaseClassMyCategoryList = @"my_category_list";


@interface DQBaseClass ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation DQBaseClass

@synthesize myTopCategoryList = _myTopCategoryList;
@synthesize rotateBanner = _rotateBanner;
@synthesize categories = _categories;
@synthesize godComment = _godComment;
@synthesize myCategoryList = _myCategoryList;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
    NSObject *receivedMyTopCategoryList = [dict objectForKey:kBaseClassMyTopCategoryList];
    NSMutableArray *parsedMyTopCategoryList = [NSMutableArray array];
    
    if ([receivedMyTopCategoryList isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedMyTopCategoryList) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedMyTopCategoryList addObject:[MyTopCategoryList modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedMyTopCategoryList isKindOfClass:[NSDictionary class]]) {
       [parsedMyTopCategoryList addObject:[MyTopCategoryList modelObjectWithDictionary:(NSDictionary *)receivedMyTopCategoryList]];
    }

    self.myTopCategoryList = [NSArray arrayWithArray:parsedMyTopCategoryList];
            self.rotateBanner = [RotateBanner modelObjectWithDictionary:[dict objectForKey:kBaseClassRotateBanner]];
            self.categories = [Categories modelObjectWithDictionary:[dict objectForKey:kBaseClassCategories]];
            self.godComment = [GodComment modelObjectWithDictionary:[dict objectForKey:kBaseClassGodComment]];
    NSObject *receivedMyCategoryList = [dict objectForKey:kBaseClassMyCategoryList];
    NSMutableArray *parsedMyCategoryList = [NSMutableArray array];
    
    if ([receivedMyCategoryList isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedMyCategoryList) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedMyCategoryList addObject:[MyCategoryList modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedMyCategoryList isKindOfClass:[NSDictionary class]]) {
       [parsedMyCategoryList addObject:[MyCategoryList modelObjectWithDictionary:(NSDictionary *)receivedMyCategoryList]];
    }

    self.myCategoryList = [NSArray arrayWithArray:parsedMyCategoryList];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    NSMutableArray *tempArrayForMyTopCategoryList = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.myTopCategoryList) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForMyTopCategoryList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForMyTopCategoryList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForMyTopCategoryList] forKey:kBaseClassMyTopCategoryList];
    [mutableDict setValue:[self.rotateBanner dictionaryRepresentation] forKey:kBaseClassRotateBanner];
    [mutableDict setValue:[self.categories dictionaryRepresentation] forKey:kBaseClassCategories];
    [mutableDict setValue:[self.godComment dictionaryRepresentation] forKey:kBaseClassGodComment];
    NSMutableArray *tempArrayForMyCategoryList = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.myCategoryList) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForMyCategoryList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForMyCategoryList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForMyCategoryList] forKey:kBaseClassMyCategoryList];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.myTopCategoryList = [aDecoder decodeObjectForKey:kBaseClassMyTopCategoryList];
    self.rotateBanner = [aDecoder decodeObjectForKey:kBaseClassRotateBanner];
    self.categories = [aDecoder decodeObjectForKey:kBaseClassCategories];
    self.godComment = [aDecoder decodeObjectForKey:kBaseClassGodComment];
    self.myCategoryList = [aDecoder decodeObjectForKey:kBaseClassMyCategoryList];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_myTopCategoryList forKey:kBaseClassMyTopCategoryList];
    [aCoder encodeObject:_rotateBanner forKey:kBaseClassRotateBanner];
    [aCoder encodeObject:_categories forKey:kBaseClassCategories];
    [aCoder encodeObject:_godComment forKey:kBaseClassGodComment];
    [aCoder encodeObject:_myCategoryList forKey:kBaseClassMyCategoryList];
}

- (id)copyWithZone:(NSZone *)zone {
    DQBaseClass *copy = [[DQBaseClass alloc] init];
    
    
    
    if (copy) {

        copy.myTopCategoryList = [self.myTopCategoryList copyWithZone:zone];
        copy.rotateBanner = [self.rotateBanner copyWithZone:zone];
        copy.categories = [self.categories copyWithZone:zone];
        copy.godComment = [self.godComment copyWithZone:zone];
        copy.myCategoryList = [self.myCategoryList copyWithZone:zone];
    }
    
    return copy;
}


@end
