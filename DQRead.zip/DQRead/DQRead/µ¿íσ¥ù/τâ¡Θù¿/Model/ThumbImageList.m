//
//  ThumbImageList.m
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "ThumbImageList.h"
#import "UrlList.h"


NSString *const kThumbImageListIsGif = @"is_gif";
NSString *const kThumbImageListHeight = @"height";
NSString *const kThumbImageListUrlList = @"url_list";
NSString *const kThumbImageListWidth = @"width";
NSString *const kThumbImageListUri = @"uri";
NSString *const kThumbImageListUrl = @"url";


@interface ThumbImageList ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation ThumbImageList

@synthesize isGif = _isGif;
@synthesize height = _height;
@synthesize urlList = _urlList;
@synthesize width = _width;
@synthesize uri = _uri;
@synthesize url = _url;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.isGif = [[self objectOrNilForKey:kThumbImageListIsGif fromDictionary:dict] doubleValue];
            self.height = [[self objectOrNilForKey:kThumbImageListHeight fromDictionary:dict] doubleValue];
    NSObject *receivedUrlList = [dict objectForKey:kThumbImageListUrlList];
    NSMutableArray *parsedUrlList = [NSMutableArray array];
    
    if ([receivedUrlList isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedUrlList) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedUrlList addObject:[UrlList modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedUrlList isKindOfClass:[NSDictionary class]]) {
       [parsedUrlList addObject:[UrlList modelObjectWithDictionary:(NSDictionary *)receivedUrlList]];
    }

    self.urlList = [NSArray arrayWithArray:parsedUrlList];
            self.width = [[self objectOrNilForKey:kThumbImageListWidth fromDictionary:dict] doubleValue];
            self.uri = [self objectOrNilForKey:kThumbImageListUri fromDictionary:dict];
            self.url = [self objectOrNilForKey:kThumbImageListUrl fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[NSNumber numberWithDouble:self.isGif] forKey:kThumbImageListIsGif];
    [mutableDict setValue:[NSNumber numberWithDouble:self.height] forKey:kThumbImageListHeight];
    NSMutableArray *tempArrayForUrlList = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.urlList) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForUrlList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForUrlList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForUrlList] forKey:kThumbImageListUrlList];
    [mutableDict setValue:[NSNumber numberWithDouble:self.width] forKey:kThumbImageListWidth];
    [mutableDict setValue:self.uri forKey:kThumbImageListUri];
    [mutableDict setValue:self.url forKey:kThumbImageListUrl];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.isGif = [aDecoder decodeDoubleForKey:kThumbImageListIsGif];
    self.height = [aDecoder decodeDoubleForKey:kThumbImageListHeight];
    self.urlList = [aDecoder decodeObjectForKey:kThumbImageListUrlList];
    self.width = [aDecoder decodeDoubleForKey:kThumbImageListWidth];
    self.uri = [aDecoder decodeObjectForKey:kThumbImageListUri];
    self.url = [aDecoder decodeObjectForKey:kThumbImageListUrl];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeDouble:_isGif forKey:kThumbImageListIsGif];
    [aCoder encodeDouble:_height forKey:kThumbImageListHeight];
    [aCoder encodeObject:_urlList forKey:kThumbImageListUrlList];
    [aCoder encodeDouble:_width forKey:kThumbImageListWidth];
    [aCoder encodeObject:_uri forKey:kThumbImageListUri];
    [aCoder encodeObject:_url forKey:kThumbImageListUrl];
}

- (id)copyWithZone:(NSZone *)zone {
    ThumbImageList *copy = [[ThumbImageList alloc] init];
    
    
    
    if (copy) {

        copy.isGif = self.isGif;
        copy.height = self.height;
        copy.urlList = [self.urlList copyWithZone:zone];
        copy.width = self.width;
        copy.uri = [self.uri copyWithZone:zone];
        copy.url = [self.url copyWithZone:zone];
    }
    
    return copy;
}


@end
