//
//  User.h
//
//  Created by kev  on 2016/12/5
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface User : NSObject <NSCoding, NSCopying>

@property (nonatomic, assign) double userVerified;
@property (nonatomic, assign) double ugcCount;
@property (nonatomic, assign) double isFollowing;
@property (nonatomic, assign) double followers;
@property (nonatomic, assign) double followings;
@property (nonatomic, assign) double isProUser;
@property (nonatomic, assign) double userId;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *avatarUrl;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
