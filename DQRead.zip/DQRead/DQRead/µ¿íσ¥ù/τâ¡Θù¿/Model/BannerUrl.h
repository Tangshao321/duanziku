//
//  BannerUrl.h
//
//  Created by kev  on 2016/12/6
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
@class UrlList;


@interface BannerUrl : NSObject <NSCoding, NSCopying>

@property (nonatomic, assign) double bannerUrlIdentifier;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSArray<UrlList *> *urlList;
@property (nonatomic, assign) double height;
@property (nonatomic, strong) NSString *uri;
@property (nonatomic, assign) double width;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
