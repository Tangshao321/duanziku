//
//  DQHotListViewController.m
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQHotListViewController.h"
#import "NHRequestManager+HOT.h"
#import "DataModels.h"
#import "DQHotListTableViewCell.h"
#import "DQSubscrilbeViewController.h"
#import "DQBannerCollectionViewCell.h"

@interface DQHotListViewController ()<UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic ,strong) UICollectionView  *collectionView;
@property (nonatomic ,strong) RefreshLoadMoreTableView *tableView;

@property (nonatomic ,strong) DQBaseClass  *baseClass;
@property (nonatomic ,strong) NSArray *categoryList;
@property (nonatomic ,strong) NSMutableArray<Banners *>  *banners;
@end

/**
 *  标识符
 */
static NSString *const kCellIndentifier = @"kCellIndentifier";
static NSString *const kCollectionIdentifier = @"kCollectionIdentifier";
@implementation DQHotListViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self initUI];
    [self initData];
    
}
#pragma mark -  初始化
/*!
 *   初始化UI
 */
- (void)initUI
{
    self .tableView.tableHeaderView = self.collectionView;
    [self.view addSubview:self.tableView];
}

/*!
 *   初始化数据
 */
- (void)initData
{
    [NHRequestManager getHotListWithSuccess:^(id responseObject) {
        self.baseClass = [DQBaseClass modelObjectWithDictionary:responseObject[@"data"]];
        self.banners = self.baseClass.rotateBanner.banners.mutableCopy;
        
        self.categoryList = responseObject[@"data"][@"categories"][@"category_list"];
        [self.tableView reloadData];
        [self.collectionView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

#pragma mark - 协议
#pragma mark - <UITableViewDelegate,UITableViewDataSource>
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.baseClass.categories.categoryList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DQHotListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIndentifier];
    cell.categoryList = self.baseClass.categories.categoryList[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    //  用于订阅上传订阅数据
    cell.dict = self.categoryList[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DQSubscrilbeViewController *vc = [[DQSubscrilbeViewController alloc] init];
    vc.categoryId = self.baseClass.categories.categoryList[indexPath.row].categoryListIdentifier;
    [self.navigationController pushViewController:vc animated:YES];
   }

#pragma mark - UICollectionViewDelegate,UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return  self.banners.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    DQBannerCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCollectionIdentifier forIndexPath:indexPath];
     [cell.bannerIamge sd_setImageWithURL:[NSURL URLWithString:self.banners[indexPath.row].bannerUrl.urlList[0].url] placeholderImage:nil];
    return cell;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    //  判断是哪个视图控件滚动
    if([scrollView isKindOfClass:[UICollectionView class]]){
        if (scrollView.contentOffset.x> SCREEN_WIDTH) {
            Banners *firstBanners = self.banners[self.banners.count%2];
            [self.banners addObject:firstBanners];
            [self.collectionView insertItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.banners.count - 1 inSection:0]]];
        }
    }else{
    }
}
#pragma mark - 懒加载
- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        CGFloat height = SCREEN_WIDTH/640 * 250;
        //  间距
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.itemSize = CGSizeMake(SCREEN_WIDTH,height );
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 0;
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, height) collectionViewLayout:layout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor clearColor];
        _collectionView.pagingEnabled = YES;
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.showsHorizontalScrollIndicator = NO;
        
        [_collectionView registerClass:[DQBannerCollectionViewCell class] forCellWithReuseIdentifier:kCollectionIdentifier];
    }
    return _collectionView;
}

- (RefreshLoadMoreTableView *)tableView
{
    if (!_tableView) {
        _tableView = [[RefreshLoadMoreTableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,SCREEN_HEIGHT - 108) style:UITableViewStylePlain withTag:10001 withDelegate:self withCellName:@"DQHotListTableViewCell" withRowHeight:DQAdaption(140) withReuseIndentifier:kCellIndentifier withRefreshBlock:nil withLoadMoreBlock:nil];
    }
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    return _tableView;
}
@end
