//
//  DQImageViewDetailViewController.h
//  DQRead
//
//  Created by rimi on 2016/12/5.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQBaseViewController.h"
#import "DataModels.h"

@interface DQImageViewDetailViewController : DQBaseViewController

/*!
 *  多张图片的url
 */
@property (nonatomic ,strong)NSArray <LargeImageList*> *largeImageLists;

/*!
 *  单张图片url
 */
@property (nonatomic ,strong) LargeImage *largeImageUrl;


/*!
 *  判断点击的图片是那张
 */
@property (nonatomic ,assign)NSInteger imagePageNumber;
@end
