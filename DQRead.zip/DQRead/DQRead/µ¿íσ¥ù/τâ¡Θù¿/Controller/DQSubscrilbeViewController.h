//
//  DQTaleViewController.h
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQBaseViewController.h"

@interface DQSubscrilbeViewController : DQBaseViewController
@property (nonatomic ,assign) NSInteger categoryId;
@end
