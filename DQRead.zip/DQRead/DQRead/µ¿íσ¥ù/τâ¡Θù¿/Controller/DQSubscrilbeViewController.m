//
//  DQTaleViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQSubscrilbeViewController.h"
#import "NHRequestManager+HOT.h"
#import "DataModels.h"
#import "DQSubscribeTableViewCell.h"
#import "DQImageViewDetailViewController.h"
#import "TransitionAnimation.h"

@interface DQSubscrilbeViewController ()<UITableViewDelegate,UITableViewDataSource,UITableViewCellImageTapDelegate>

@property (nonatomic ,strong) UICollectionViewFlowLayout *layout;
@property (nonatomic,strong) RefreshLoadMoreTableView *tableView;

@property (nonatomic ,strong) NSMutableArray<BaseClass *>   *dataSource;/**< 数据源 */
@end

/**
 *  标识符
 */
static NSString *const kCellIndentifier = @"kCellIndentifier";

@implementation DQSubscrilbeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initUI];
    [self initData];
    
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //  隐藏标签栏
    [self.tabBarController.tabBar setHidden:YES];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self .tabBarController.tabBar setHidden:NO];
}
#pragma mark -  初始化
/*!
 *   初始化UI
 */
- (void)initUI
{
    [self.view setBackgroundColor:[UIColor colorWithRed:0.94 green:0.94 blue:0.94 alpha:1.00]];
    [self.view addSubview:self.tableView];
}

/*!
 *   初始化数据
 */
- (void)initData
{
    self.dataSource = [NSMutableArray array];
     //列表详情
    [NHRequestManager getHotDetailInfoWithCategoryId:[NSString stringWithFormat:@"%@",@(_categoryId)] success:^(id responseObject) {
        for (NSMutableDictionary *dict in responseObject[@"data"][@"data"]){
            BaseClass *baseClass = [BaseClass modelObjectWithDictionary:dict];
            //  判断是否为广告
            if (baseClass.ad.isAd == 0) {
                [self.dataSource addObject:baseClass];
            }
        }
        NSLog(@"%@",self.dataSource);
        [self.tableView reloadData];
    } failure:^(NSError * error) {
        NSLog(@"%@",error);
    }];
    
//    [NHRequestManager GET:@"http://lf.snssdk.com/neihan/stream/category/data/v2/" parameters:params responseSeializerType:NHResponseSeializerTypeJSON success:^(id responseObject) {
//        NSLog(@"%@",responseObject);
//    } failure:^(NSError *error) {
//        
//    }];
}
#pragma mark - 协议
#pragma mark -UITableViewDelegate,UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DQSubscribeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIndentifier];
    cell.baseClass = self.dataSource[indexPath.section];
    cell.delegate = self;
    cell.indexPath = indexPath;
    
    self.dataSource[indexPath.section].CellHeight =  cell.cellHeight;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return self.dataSource[indexPath.section].CellHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return DQAdaption(18);
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *sectionView = [[UIView alloc]init];
    sectionView.backgroundColor = [UIColor clearColor];
    return sectionView;
}



#pragma mark - UITableViewCellImageTapDelegate
- (void)ImageView:(UIImageView *)imageView tapedIndexPath:(NSIndexPath *)indexPath currnetTapImagTag:(NSInteger)ImageTag
{
     DQImageViewDetailViewController *imageDetail = [[DQImageViewDetailViewController alloc] init];
    //  判断图片是否是单张
    if (ImageTag != 11) {
       
        imageDetail.largeImageLists = self.dataSource[indexPath.section].group.largeImageList;
        imageDetail.imagePageNumber = ImageTag;
       
    }else{
        imageDetail.largeImageUrl = self.dataSource[indexPath.section].group.largeImage;
    }
    //  添加过度动画
    [[UIApplication sharedApplication].keyWindow.layer addAnimation:[TransitionAnimation transitionAnimation] forKey:nil];
    [self presentViewController:imageDetail animated:YES completion:nil];
}


#pragma mark - 懒加载

- (RefreshLoadMoreTableView *)tableView
{
    if (!_tableView) {
        _tableView = [[RefreshLoadMoreTableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,SCREEN_HEIGHT) style:UITableViewStylePlain withTag:10001 withDelegate:self withCellName:@"DQSubscribeTableViewCell"withRowHeight:DQAdaption(500) withReuseIndentifier:kCellIndentifier withRefreshBlock:nil withLoadMoreBlock:nil];
    }
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    return _tableView;
}
@end
