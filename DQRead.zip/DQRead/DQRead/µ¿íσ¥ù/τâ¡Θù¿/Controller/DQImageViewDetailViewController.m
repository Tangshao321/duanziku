//
//  DQImageViewDetailViewController.m
//  DQRead
//
//  Created by rimi on 2016/12/5.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQImageViewDetailViewController.h"
#import "DQImageDetailCollectionViewCell.h"

@interface DQImageViewDetailViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic ,strong) UICollectionView  *collectionView;
@property (nonatomic ,strong) UILabel  *currentPageNumber;
@end


static NSString *const kCollectionIdentifier = @"kCollectionIdentifier";
@implementation DQImageViewDetailViewController

#pragma mark -  视图生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor blackColor]];
    [self.view addSubview:self.collectionView];
    //  滚动到指定位置
    [self.collectionView setContentOffset:CGPointMake(SCREEN_WIDTH * self.imagePageNumber, 0)];
    [self.view addSubview:self.currentPageNumber];
    
}
#pragma mark -  UICollectionViewDelegate,UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if(self.largeImageUrl){
        return 1;
    }
    return self.largeImageLists.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    DQImageDetailCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCollectionIdentifier forIndexPath:indexPath];
    cell.lastVC = self;
    //  判断是否为单张图片
    if(self.largeImageUrl){
        [self.currentPageNumber setText:[NSString stringWithFormat:@"1/1"]];
        cell.largeImage = self.largeImageUrl;
        return cell;
    }
    
    NSInteger pageNumber = collectionView.contentOffset.x / SCREEN_WIDTH;
    [self.currentPageNumber setText:[NSString stringWithFormat:@"%ld/%ld",pageNumber + 1,self.largeImageLists.count]];
    cell.largeImageList = self.largeImageLists[indexPath.row];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(nonnull UICollectionViewCell *)cell forItemAtIndexPath:(nonnull NSIndexPath *)indexPath{
    //  隐藏cell时还原cell图片原来的大小
    ((DQImageDetailCollectionViewCell *)cell).aImageView.transform = CGAffineTransformMakeScale(1.0, 1.0);
}
#pragma mark - 懒加载
- (UICollectionView *)collectionView{
    if (!_collectionView) {
        //  间距
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.itemSize = CGSizeMake(SCREEN_WIDTH,SCREEN_HEIGHT);
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 0;
        _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor clearColor];
        _collectionView.pagingEnabled = YES;
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.showsHorizontalScrollIndicator = NO;
        
        [_collectionView registerClass:[DQImageDetailCollectionViewCell class] forCellWithReuseIdentifier:kCollectionIdentifier];
    }
    return _collectionView;
}

- (UILabel *)currentPageNumber{
    if (!_currentPageNumber) {
        _currentPageNumber = [[UILabel alloc] initWithFrame:CGRectMake(0, DQAdaption(100), SCREEN_WIDTH, 30)];
        _currentPageNumber.textColor = [UIColor whiteColor];
        _currentPageNumber.textAlignment = NSTextAlignmentCenter;
        _currentPageNumber.font = DQAFont(30);
    }
    return _currentPageNumber;
}

@end
