//
//  DQHotListViewController.h
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQBaseViewController.h"

@interface DQHotListViewController : DQBaseViewController

@end
