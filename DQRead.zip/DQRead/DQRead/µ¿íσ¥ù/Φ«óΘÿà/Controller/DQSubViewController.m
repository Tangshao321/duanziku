//
//  DQSubViewController.m
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQSubViewController.h"
#import "NHRequestManager+HOT.h"
#import "DataModels.h"
#import "DQSubTableViewCell.h"
#import "DQSubscrilbeViewController.h"
#import "DQBannerCollectionViewCell.h"
#import "TakeList.h"
#import "TakeNetWorking.h"
#import "DQLoginViewController.h"

@interface DQSubViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic ,strong) RefreshLoadMoreTableView *tableView;
@property (nonatomic,strong) UIImageView *backgroundImageView;

@property (nonatomic ,strong) DQBaseClass  *baseClass;
@property (nonatomic ,strong) NSMutableArray<Banners *>  *banners;
@property (nonatomic ,strong) NSMutableArray<CategoryList *> *resultsAry;
@end

/**
 *  标识符
 */
static NSString *const kCellIndentifier = @"kCellIndentifier";

@implementation DQSubViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.resultsAry = nil;
    [self.tableView reloadData];
    if ([UserInfo sharedUserInfo].objectId.length ==  0) {
        [TjxCustomView showMessageWithTitle:@"提示" content:@"请登录后再订阅" actionTitle:@"确定" compeletedHandle:^{
            self.tabBarController.selectedIndex = 3;
        }];
        [self setBackground];
    }
    else{
        [self initUI];
    }
}

#pragma mark -  初始化
/*!
 *   初始化UI
 */
- (void)initUI
{
    if (self.resultsAry.count == 0) {
        [_backgroundImageView removeFromSuperview];
        _backgroundImageView = nil;
        [self initData];
        [self.view addSubview:self.tableView];
    }
}

- (void)setBackground{
    
    if (!_backgroundImageView) {
        [self.tableView removeFromSuperview];
        self.resultsAry = nil;
        _backgroundImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 115)];
        _backgroundImageView.image = [UIImage imageNamed:@"subBackground"];
        [self.view addSubview:_backgroundImageView];
    }
}

/*!
 *   初始化数据
 */
- (void)initData
{
    self.resultsAry = [NSMutableArray array];
    
    //  查询订阅的信息
    [TakeNetWorking takeListWithParam:@[[UserInfo sharedUserInfo].objectId] block:^(BQLQueryResult *result, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        }else{
            for (BmobObject  *bObject in result.resultsAry) {
              [self.resultsAry addObject:  [CategoryList modelObjectWithDictionary:[bObject objectForKey:[TakeList sharedTakeList].keyUserTakeCategoryList]]];
                }
                //  如果没有数据就显示默认背景图片
                if (self.resultsAry.count ==0 ){
                    [TjxCustomView showMessageAutoDismissWithTitle:@"温馨提示" content:@"暂未订阅" disMissTime:1.5];
                    [self setBackground];
                }
            
                [self.tableView reloadData];
            
        }
   }];
}

#pragma mark - 协议
#pragma mark - <UITableViewDelegate,UITableViewDataSource>
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.resultsAry.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DQSubTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIndentifier];
 
    cell.categoryList = self.resultsAry[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DQSubscrilbeViewController *vc = [[DQSubscrilbeViewController alloc] init];
    vc.categoryId = self.resultsAry[indexPath.row].categoryListIdentifier;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 懒加载
- (RefreshLoadMoreTableView *)tableView
{
    if (!_tableView) {
        _tableView = [[RefreshLoadMoreTableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,SCREEN_HEIGHT - 108) style:UITableViewStylePlain withTag:10001 withDelegate:self withCellName:@"DQSubTableViewCell" withRowHeight:DQAdaption(140) withReuseIndentifier:kCellIndentifier withRefreshBlock:^(UITableView *sender) {
            //  刷新数据
            [self initData];
            [self.tableView.mj_header endRefreshing];
        } withLoadMoreBlock:nil];
    }
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    return _tableView;
}
@end

