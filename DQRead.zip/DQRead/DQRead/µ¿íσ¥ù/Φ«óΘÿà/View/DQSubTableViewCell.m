//
//  DQSubTableViewCell.m
//  DQRead
//
//  Created by rimi on 2016/12/8.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQSubTableViewCell.h"


//  间隔宽度
#define spaceWidth   DQAdaption(35)

@implementation DQSubTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        CGFloat headPortraitWidth = DQAdaption(82);
        //  头像
        _headPortrait  = [[UIImageView alloc] initWithFrame:CGRectMake(spaceWidth, DQAdaption(25), headPortraitWidth, headPortraitWidth)];
        _headPortrait.layer.cornerRadius = 3;
        _headPortrait.layer.masksToBounds = YES;
        
        [self.contentView addSubview:_headPortrait];
        
        
        //  昵称
        _nickname = [[UILabel alloc] initWithFrame:DQAdaptionRect(138, spaceWidth, 400, 30)];
        _nickname.font = DQAFont(30);
        [self.contentView addSubview:self.nickname];
        
        //  标题
        _aContent = [[UILabel alloc] initWithFrame:DQAdaptionRect(138, 70, 400, 30)];
        _aContent.font = DQAFont(22);
        _aContent.textColor = [UIColor colorWithRed:0.62 green:0.62 blue:0.62 alpha:1.00];
        [self.contentView addSubview:self.aContent];
        
        CGFloat takeButtonWitdh = DQAdaption(120);
        //  订阅按钮
        self.takeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.takeButton.frame = CGRectMake(SCREEN_WIDTH - takeButtonWitdh - DQAdaption(30) , DQAdaption(20), takeButtonWitdh, DQAdaption(60));
        [self.takeButton setTitle:@"订阅" forState:UIControlStateNormal];
        [self.takeButton setTitleColor:ThemeColor];
        [self.contentView addSubview:self.takeButton];
        
        UILabel *lineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, DQAdaption(140) - 1, SCREEN_WIDTH, 1)];
        lineLabel.backgroundColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1.00];
        [self.contentView addSubview:lineLabel];
    }
    return self;
}

- (void)setCellConten:(CategoryList *)categoryList{
    [self.headPortrait sd_setImageWithURL:[NSURL URLWithString:categoryList.smallIconUrl]];
    [self.nickname setText:categoryList.name];
    [self.aContent setText:categoryList.placeholder];
}


@end
