//
//  RefreshLoadMoreTableView.h
//  THMM2
//
//  Created by rimi on 2016/11/11.
//  Copyright © 2016年 zhengbing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RefreshLoadMoreTableView : UITableView

typedef void(^RefreshLoadMoreBlock)(UITableView *sender);

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style
                      withTag:(NSInteger)tag
                 withDelegate:(id)delegate
                 withCellName:(NSString *)cellName
                withRowHeight:(CGFloat)rowHeight
         withReuseIndentifier:(NSString *)reuseIndentifier
             withRefreshBlock:(RefreshLoadMoreBlock)refresh
            withLoadMoreBlock:(RefreshLoadMoreBlock)loadMore;

@end
