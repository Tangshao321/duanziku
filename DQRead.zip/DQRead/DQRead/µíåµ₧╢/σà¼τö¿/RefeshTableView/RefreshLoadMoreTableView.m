//
//  RefreshLoadMoreTableView.m
//  THMM2
//
//  Created by rimi on 2016/11/11.
//  Copyright © 2016年 zhengbing. All rights reserved.
//

#import "RefreshLoadMoreTableView.h"

@implementation RefreshLoadMoreTableView

/*
 
 1.需要两个Block参数进行刷新和加载更多的事件回调
 2.cell的name,ReuserIdentifier,rowHeight,delegate
 
 */
- (instancetype)initWithFrame:(CGRect)frame
                        style:(UITableViewStyle)style
                      withTag:(NSInteger)tag
                 withDelegate:(id)delegate
                 withCellName:(NSString *)cellName
                 withRowHeight:(CGFloat)rowHeight
         withReuseIndentifier:(NSString *)reuseIndentifier
             withRefreshBlock:(RefreshLoadMoreBlock)refresh
            withLoadMoreBlock:(RefreshLoadMoreBlock)loadMore{
    
    // self 必须调用父类进行初始化，不然self为空
    self = [super initWithFrame:frame style:style];
    if (self) {
        // if 语句里面对除开父类参数以外参数的使用
        self.tag = tag;
        self.dataSource = delegate;
        self.delegate = delegate;
        [self registerClass:NSClassFromString(cellName) forCellReuseIdentifier:reuseIndentifier];
        self.rowHeight = rowHeight;
        self.estimatedRowHeight = 10;
        if (refresh) {
            
            MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingBlock:^{
                refresh(self);
            }];
            
            header.gifView.backgroundColor = [UIColor colorWithRed:234 / 255.0 green:241 / 255.0 blue:243 / 255.0 alpha:1];
            [header setImages:@[[UIImage imageNamed:@"pika1.png"]] forState:MJRefreshStateIdle];
            NSMutableArray *array = [[NSMutableArray alloc] init];
            
            for (NSInteger index = 2; index < 9; index ++) {
                
                [array addObject:[UIImage imageNamed:[NSString stringWithFormat:@"pika%ld.png",index]]];
            }
            [header setImages:array duration:0.5 forState:MJRefreshStateRefreshing];
            header.lastUpdatedTimeLabel.hidden = YES;
            header.stateLabel.hidden = YES;
            self.mj_header = header;
//            self.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
//                refresh(self);
//            }];
        }
        
        if (loadMore) {
            
//            self.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
//                loadMore(self);
//            }];
            MJRefreshAutoGifFooter *footer = [MJRefreshAutoGifFooter footerWithRefreshingBlock:^{
                loadMore(self);
            }];
            
            NSMutableArray *array = [[NSMutableArray alloc] init];
            for (NSInteger index = 1; index < 9; index ++) {
                
                [array addObject:[UIImage imageNamed:[NSString stringWithFormat:@"pika%ld.png",index]]];
            }
            [footer setImages:array duration:0.5 forState:MJRefreshStateRefreshing];
            footer.refreshingTitleHidden = YES;
            self.mj_footer = footer;
        }
    }
    
    return self;
}



@end
