//
//  LoadingView.m
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "LoadingView.h"
#import <UIImage+GIF.h>

@implementation LoadingView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        //半透明视图
        UIView *bgview = [[UIView alloc]initWithFrame:frame];
        bgview.backgroundColor = [UIColor blackColor];
        bgview.alpha = 0.5;
        bgview.layer.cornerRadius = DQAdaption(20);
        [self addSubview:bgview];
        //放图片的视图
        UIView *cview = [[UIView alloc]initWithFrame:frame];
        [self addSubview:cview];
        //图片视图
        UIImageView *imgView = [[UIImageView alloc]initWithFrame:DQAdaptionRectFromFrame(CGRectMake(0, 0, 200, 150))];
        imgView.image = [UIImage sd_animatedGIFNamed:@"pika2"];
        [cview addSubview:imgView];
    }
    return self;
}

@end
