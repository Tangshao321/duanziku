//
//  UIView+XUGestureRecognizer.m
//  绵阳师范
//
//  Created by rimi on 16/10/22.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "UIView+XUGestureRecognizer.h"

@implementation UIView (XUGestureRecognizer)

/*!
 @brief 为视图添加点击手势
 @param target 要指向的类,就是在那个类中执行
 @param action 为手势添加动作
 */
- (void)addTapGestureRecognizerWithTarget:(nullable id)target
                                   action:(nullable SEL)action {
    /*! 点击手势 */
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:target action:action];
    self.userInteractionEnabled = YES;
    [self addGestureRecognizer:tapGesture];
}

/*!
 @brief 为视图添加滑动手势
 @param target 要指向的类,就是在那个类中执行
 @param action 为手势添加动作
 */
- (void)addPanGestureRecognizerWithTarget:(nullable id)target
                                   action:(nullable SEL)action{
    /*! 滑动手势 */
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:target action:action];
    self.userInteractionEnabled = YES;
    [self addGestureRecognizer:panGesture];
}

/*!
 @brief 为视图添加放大手势
 @param target 要指向的类,就是在那个类中执行
 @param action 为手势添加动作
 */
- (void)addPinchGestureRecognizerWithTarget:(nullable id)target
                                action:(nullable SEL)action{
    UIPinchGestureRecognizer *pinchGesTure = [[UIPinchGestureRecognizer alloc] initWithTarget:target action:action];
    self.userInteractionEnabled = YES;
    [self addGestureRecognizer:pinchGesTure];
}
@end
