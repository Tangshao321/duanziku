//
//  TjxCustomView.m
//  MAMA
//
//  Created by rimi on 2016/11/19.
//  Copyright © 2016年 Qzhang. All rights reserved.
//

#import "TjxCustomView.h"
#import <AVFoundation/AVFoundation.h>

@implementation TjxCustomView

// 带按钮的弹出框

+ (void)showMessageWithTitle:(NSString *)title content:(NSString *)content actionTitle:(NSString *)actionTitle compeletedHandle:(void (^)())handle{
    if (title == nil) {
        title = @"";
    }
    UIViewController *currentVc = [self keyViewController];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:content preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDestructive handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:actionTitle style:UIAlertActionStyleDefault handler:handle]];
    [currentVc presentViewController:alert animated:YES completion:nil];
}


// 自动消失弹出框
+ (void)showMessageAutoDismissWithTitle:(NSString *)title content:(NSString *)content disMissTime:(NSTimeInterval)time{
    if (title == nil) {
        title = @"";
    }
    UIViewController *currentVc = [self keyViewController];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:content preferredStyle:UIAlertControllerStyleAlert];
    [currentVc presentViewController:alert animated:YES completion:nil];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(time * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [alert dismissViewControllerAnimated:YES completion:nil];
    });
}

// 灰色视图
+ (UIView *)showGrayLineViewWithRect:(CGRect)rect{
    UIView *view = [[UIView alloc] initWithFrame:rect];
    view.backgroundColor = ThemeColor;
    return view;
}

// 获取当前控制器
+ (UIViewController *)keyViewController {
    UIViewController * vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (vc.presentedViewController) {
        vc = vc.presentedViewController;
    }
    return vc;
}

// 获取当前时间
+ (NSString *)getRealTime{
    NSDate *date = [NSDate date]; // 获得时间对象
    NSDateFormatter *forMatter = [[NSDateFormatter alloc] init];
    [forMatter setDateFormat:@"HH:mm:ss"];
    NSString *dateStr = [forMatter stringFromDate:date];
    return dateStr;
}

+ (NSString *)getTime{
    NSDate *date = [NSDate date]; // 获得时间对象
    NSDateFormatter *forMatter = [[NSDateFormatter alloc] init];
    [forMatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateStr = [forMatter stringFromDate:date];
    return dateStr;
}
// 获取星期几
+ (NSString *)getWeekDay{
    NSDate *date = [NSDate date]; // 获得时间对象
    NSDateFormatter *forMatter = [[NSDateFormatter alloc] init];
    [forMatter setDateFormat:@"EEEE"];
    NSString *dateStr = [forMatter stringFromDate:date];
    return dateStr;
}

// 将秒转换为日期
+ (NSString *)dateChangeSecondString:(NSString *)second{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:second.doubleValue];
    return [formatter stringFromDate:date];
}


// 将数组值转化为String类型
+ (NSMutableArray *)valuesForamtToStringWithArray:(NSArray *)array {
    NSMutableArray * newArray = [NSMutableArray array];
    for (id obj in array) {
        id newObj;
        if ([obj isKindOfClass:[NSNumber class]]) {
            newObj = [NSString stringWithFormat:@"%@",obj];
        }else if ([obj isKindOfClass:[NSDictionary class]]) {
            newObj = [self valuesForamtToStringWithDict:obj];
        }else if ([obj isKindOfClass:[NSArray class]]){
            newObj = [self valuesForamtToStringWithArray:obj];
        }else if ([obj isKindOfClass:[NSNull class]]){
            newObj = @"";
        }else {
            newObj = obj;
        }
        [newArray addObject:newObj];
    }
    return newArray;
}

// 将字典值转化为String类型
+ (NSMutableDictionary *)valuesForamtToStringWithDict:(NSDictionary *)dict {
    __block NSMutableDictionary * newDict = [NSMutableDictionary dictionary];
    [dict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSString *newKey = [NSString stringWithFormat:@"%@",key];
        id newObj;
        if ([obj isKindOfClass:[NSNumber class]]) {
            newObj = [NSString stringWithFormat:@"%@",obj];
        }else if ([obj isKindOfClass:[NSDictionary class]]) {
            newObj = [self valuesForamtToStringWithDict:obj];
        }else if ([obj isKindOfClass:[NSArray class]]){
            newObj = [self valuesForamtToStringWithArray:obj];
        }else if ([obj isKindOfClass:[NSNull class]]){
            newObj = @"";
        }else {
            newObj = obj;
        }
        newDict[newKey] = newObj;
    }];
    return newDict;
}


+ (BOOL)isBlankString:(NSString *)string {
    if (string == nil || string == NULL) {
        return YES;
    }
    if ([string isKindOfClass:[NSNull class]]) {
        return YES;
    }
    if ([[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0) {
        return YES;
    }
    return NO;
}


// 根据内容多少，返回rect
+ (CGRect)updateMessageSize:(NSString *)content{
    CGRect rect = [content boundingRectWithSize:CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading | NSStringDrawingTruncatesLastVisibleLine attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:15]} context:nil];
    return rect;
}


// 动画设计
+ (CAKeyframeAnimation *)getFillButtonAnimatioinWithDuration:(CFTimeInterval)duration{
    CAKeyframeAnimation * animation;
    animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = duration;// 动画持续时间
    animation.removedOnCompletion = NO;// 是否移除动画
    animation.fillMode = kCAFillModeForwards;
    NSMutableArray *values = [NSMutableArray array];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.1, 1.1, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.2, 1.2, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.1, 1.1, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    animation.values = values;
    animation.timingFunction = [CAMediaTimingFunction functionWithName: @"easeInEaseOut"];
    return animation;
}

+ (UIImage*) thumbnailImageForVideo:(NSURL *)videoURL {
    
    AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:videoURL options:nil];
    
    AVAssetImageGenerator *gen = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    
    gen.appliesPreferredTrackTransform = YES;
    
    CMTime time = CMTimeMakeWithSeconds(2.0, 600);
    
    NSError *error = nil;
    
    CMTime actualTime;
    
    CGImageRef image = [gen copyCGImageAtTime:time actualTime:&actualTime error:&error];
    
    UIImage *thumbImg = [[UIImage alloc] initWithCGImage:image];
    
    return thumbImg;
    
}


+ (NSString *)noWhiteSpaceString:(NSString *)newString {
//    NSString *newString = self;
    //    newString = [newString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];  //去除掉首尾的空白字符和换行字符
    newString = [newString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    newString = [newString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    newString = [newString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];  //去除掉首尾的空白字符和换行字符使用
    newString = [newString stringByReplacingOccurrencesOfString:@" " withString:@""];
    //    可以去掉空格，注意此时生成的strUrl是autorelease属性的，所以不必对strUrl进行release操作！
    //    newString = [newString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    return newString;
}

+ (void)configImageInObject:(id)object {
    
//    NSString *url = [[NSUserDefaults standardUserDefaults] objectForKey:@"headUrl"];
    NSString *url = [UserInfo sharedUserInfo].headUrl;

    UIImage * image = [TjxCustomView getLocaHeadImage];
    
    if (image == nil && url.length == 0) {
        [self setImageWith:[TjxCustomView customImage] inObject:object];
    }else if (image != nil){
        [self setImageWith:image inObject:object];
    }else {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
            UIImage *loadImage = [UIImage imageWithData:data];
            [TjxCustomView saveHeadImageData:data];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self setImageWith:loadImage inObject:object];
            });
        });
    }
    
}
+ (void)setImageWith:(UIImage *)image inObject:(id)object {
    if ([object isKindOfClass:[UIButton class]]) {
        UIButton * btn = object;
        [btn setBackgroundImage:image forState:UIControlStateNormal];
    }else {

        UIImageView * imageView = object;
        //  先加载默认头像
        imageView.image = [self customImage];
        
        imageView.image = image;
    }
}
+ (UIImage *)customImage {
//    BOOL isMan = [[CustomUserInfo shareUserInfo].staffSex isEqualToString:@"男"];
//    NSString *imageName = isMan ? @"默认头像男" : @"默认头像女";
    UIImage * coustomImage = [UIImage imageNamed:@"默认头像"];
    return coustomImage;
}
+ (UIImage *)getLocaHeadImage {
//    NSString *objId = [[NSUserDefaults standardUserDefaults] objectForKey:@"objectId"];
    NSString *objId = [UserInfo sharedUserInfo].objectId;
    
    if (objId.length != 0) {
        NSData *data = [[NSUserDefaults standardUserDefaults] valueForKey:objId];
        return [UIImage imageWithData:data];
    }
    else{
        return nil;
    }
    
}
+ (void)saveHeadImageData:(NSData *)imageData {
//    NSString *objId = [[NSUserDefaults standardUserDefaults] objectForKey:@"objectId"];
     NSString *objId = [UserInfo sharedUserInfo].objectId;
    
    [[NSUserDefaults standardUserDefaults] setObject:imageData forKey:objId];
    [[NSUserDefaults standardUserDefaults] synchronize];
}



@end
