//
//  UIViewController+TTPlayerRotation.h
//  testPlayerDemo
//
//  Created by rimi on 2016/12/14.
//  Copyright © 2016年 TJX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (TTPlayerRotation)

@end
