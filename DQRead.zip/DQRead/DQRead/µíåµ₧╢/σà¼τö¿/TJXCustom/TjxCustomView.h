//
//  TjxCustomView.h
//  MAMA
//
//  Created by rimi on 2016/11/19.
//  Copyright © 2016年 Qzhang. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^ButtonClickWithSender)(id sender);

@interface TjxCustomView : NSObject

+ (void)showMessageWithTitle:(NSString *)title content:(NSString *)content actionTitle:(NSString *)actionTitle compeletedHandle:(void (^)())handle;/**< 带按钮的弹出框 */

+ (void)showMessageAutoDismissWithTitle:(NSString *)title content:(NSString *)content disMissTime:(NSTimeInterval)time;/**< 自动消失的提示框 */

+ (UIView *)showGrayLineViewWithRect:(CGRect)rect;/**< 灰色的视图 */

+ (NSString *)getRealTime;/**< 获取系统当前时间 */

+ (NSString *)getTime;/**< 获取时间 */

+ (NSString *)getWeekDay;/**< 获取星期几 */

+ (NSString *)dateChangeSecondString:(NSString *)second;/**< 秒转换为日期 */

// 将数组值转化为String类型
+ (NSMutableArray *)valuesForamtToStringWithArray:(NSArray *)array;

// 将字典值转化为String类型
+ (NSMutableDictionary *)valuesForamtToStringWithDict:(NSDictionary *)dict;

// 判断字符串是否为空
+ (BOOL)isBlankString:(NSString *)string;

// 获取当前控制器
+ (UIViewController *)keyViewController;

// 根据内容多少，返回rect
+ (CGRect)updateMessageSize:(NSString *)content;


+ (CAKeyframeAnimation *)getFillButtonAnimatioinWithDuration:(CFTimeInterval)duration;/**< 按钮动画 */

+ (UIImage*) thumbnailImageForVideo:(NSURL *)videoURL;/**< 获取视频帧 */


+ (NSString *)noWhiteSpaceString:(NSString *)newString;/**< 去除空白字符 */



/**  在控件上配置头像 */
+ (void)configImageInObject:(id)object;
///**  获取本地头像 */
+ (UIImage *)getLocaHeadImage;
///**  默认头像 */
+ (UIImage *)customImage;
/**  保存头像 */
+ (void)saveHeadImageData:(NSData *)imageData;

@end
