//
//  TransitionAnimation.m
//  DQRead
//
//  Created by rimi on 2016/12/6.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "TransitionAnimation.h"

@implementation TransitionAnimation

//  过渡动画
+ (CATransition *)transitionAnimation
{
    //创建动画
    CATransition *animation = [CATransition animation];
    //设置运动轨迹的速度
    animation.timingFunction = UIViewAnimationCurveEaseInOut;
    //设置动画类型为立方体动画
    animation.type = kCATransitionReveal;
    //设置动画时长
    animation.duration =0.7f;
    //设置运动的方向
    animation.subtype = kCATransitionPush;
    
    return animation;
}


@end
