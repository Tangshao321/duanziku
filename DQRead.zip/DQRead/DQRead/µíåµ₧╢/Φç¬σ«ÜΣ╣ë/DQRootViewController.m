//
//  DQRootViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQRootViewController.h"
#import "DQTabBarViewController.h"
#import "DQLuanchViewController.h"
#import "LoadingView.h"



@interface DQRootViewController ()

@property (nonatomic,strong) LoadingView *load;

@end

@implementation DQRootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showLoading) name:@"showLoading" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hiddenLoading) name:@"hiddenLoading" object:nil];
    [self addTabBarViewController];
    [self addLuanchViewController];
}

- (void)addLuanchViewController{
    DQLuanchViewController *Luanch = [[DQLuanchViewController alloc] init];
    [self addChildViewController:Luanch];
    [self.view addSubview:Luanch.view];
}

- (void)addTabBarViewController{
    DQTabBarViewController *tababrVC = [[DQTabBarViewController alloc] init];
    [self addChildViewController:tababrVC];
    [self.view addSubview:tababrVC.view];
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                [self notNetwork];
                break;
            case AFNetworkReachabilityStatusNotReachable:
                [self notNetwork];
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                [self yesNetwork];
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                [self yesNetwork];
                break;
                
            default:
                break;
        }
    }];
    [manager startMonitoring];
    _load = [[LoadingView alloc]initWithFrame:DQAdaptionRect((750 - 200) / 4, (1334 - 200) / 5, 200, 200)];;
    _load.hidden = YES;
    [self.view addSubview:_load];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (void)showLoading{
    _load.hidden = NO;
}

- (void)hiddenLoading{
    _load.hidden = YES;
}

- (void)yesNetwork{
    NSLog(@"连接网络中");
    [[NSUserDefaults standardUserDefaults] setObject:@(YES) forKey:@"isNetwork"];
}

- (void)notNetwork{
    NSLog(@"没有网络");
    [[NSUserDefaults standardUserDefaults] setObject:@(NO) forKey:@"isNetwork"];
}



@end
