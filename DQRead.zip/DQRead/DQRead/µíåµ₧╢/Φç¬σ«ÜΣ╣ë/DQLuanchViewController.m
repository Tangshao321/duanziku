//
//  DQLuanchViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQLuanchViewController.h"

@interface DQLuanchViewController ()

@property (nonatomic,strong) NSTimer *timer;

@end

@implementation DQLuanchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *luanchView = [[UIImageView alloc] initWithFrame:self.view.frame];
    luanchView.image = [UIImage imageNamed:@"luanch"];
    [self.view addSubview:luanchView];
    
    [self performSelector:@selector(dismissLuanch) withObject:nil afterDelay:3.0];
}

- (void)dismissLuanch{
    [self.view removeFromSuperview];
    [self removeFromParentViewController];
}


@end
