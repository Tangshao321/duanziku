//
//  DQTabBarViewController.h
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DQTabBarViewController : UITabBarController

@end
