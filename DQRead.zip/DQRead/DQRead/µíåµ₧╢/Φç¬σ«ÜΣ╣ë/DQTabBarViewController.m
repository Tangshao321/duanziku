//
//  DQTabBarViewController.m
//  DQRead
//
//  Created by rimi on 2016/11/30.
//  Copyright © 2016年 徐青松. All rights reserved.
//

#import "DQTabBarViewController.h"

@interface DQTabBarViewController ()
@property (nonatomic ,strong) NSMutableArray<UIViewController *>  *childViews;
@end

@implementation DQTabBarViewController
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.tabBar.tintColor = [UIColor colorWithRed:0.47 green:0.63 blue:0.31 alpha:1.00];
        self.tabBar.barTintColor = [UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1.00];
        self.tabBar.alpha = 0.8;
        self.tabBar.opaque = YES;
        self.tabBar.translucent = NO;
        
        self.childViews = [NSMutableArray array];
        [self addChildViewUI];
        
    }
    return self;
}

//  添加子视图的UI
- (void)addChildViewUI{
    NSArray *vcArr = @[@"DQCrossTalkViewController",@"DQHotListViewController",@"DQSubViewController",@"DQUserViewController"];
    NSArray *titleArray = @[@"段子",@"热门",@"订阅",@"个人"];
    
    NSArray *imageArray = @[@"搞笑段子",@"热门",@"订阅",@"个人"];
    
    for (NSInteger index =  0; index < vcArr.count; index ++) {
        [self addChildViewControllerWithTitle:titleArray[index] className:vcArr[index] imageName:imageArray[index] selectedImageName:imageArray[index]];
    }
    
}

- (void)addChildViewControllerWithTitle:(NSString *) title
                              className:(NSString *)className
                              imageName:(NSString *)imageName
                      selectedImageName:(NSString *)selectedName{
    UIViewController *vc = [[NSClassFromString(className) alloc] init];
    vc.tabBarItem = [[UITabBarItem alloc] initWithTitle:title image:[UIImage imageNamed:imageName] selectedImage:[UIImage imageNamed:selectedName]];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    nav.navigationBar.translucent = NO;
    nav.navigationBar.barTintColor = ThemeColor;
    nav.navigationBar.tintColor = [UIColor whiteColor];
    [nav.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:0.95f green:0.95f blue:0.95f alpha:1]}];
    vc.title = title;
    
    [self.childViews addObject:nav];
    self.viewControllers = self.childViews;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
